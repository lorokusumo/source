<?
include("include/config.php");

$site = mysql_query("SELECT * FROM `site_info`");
$array = mysql_fetch_array($site);

if(isset($_GET['id']) && is_numeric($_GET['id'])){
$query = mysql_query("SELECT * FROM `exploits` WHERE `id`='".$_GET['id']."';");
$row = mysql_fetch_array($query);
if($row){
header('Content-type: application/octetstream');
header('Content-Disposition: attachment; filename='.$row["id"].'.txt;');
echo $row['exploit'];
echo "\n\n# ".$array['site_name']." [".$row['date']."]";
}
}
?>