	<br><b>[ <a href="dos.php" target=_self>dos / poc</a> ]</b>
	<table width="597" align="center" border="0">
	<tbody>
	<tr class="style1">
		<td class="style1">-::DATE</td>
		<td class="style1">-::DESCRIPTION</td>
		<td class="style1" width="40">-::HITS</td>
		<td class="style1" width="9"></td>
		<td class="style1" width="9"></td>
		<td class="style1" width="9"></td>
		<td>-::AUTHOR</td>
	</tr>
<?
$dospoc = mysql_query("SELECT * FROM `exploits` WHERE `type`='dos' ORDER BY `id` DESC LIMIT 6");
while ($dos_array = mysql_fetch_array($dospoc)){
?>
	<tr class="submit">
		<td class="style1" nowrap="nowrap" width="62"><? echo $dos_array['date']; ?></td>
		<td nowrap="nowrap" width="375"><a href="exploits.php?id=<? echo $dos_array['id']; ?>" target="_blank" class="<? if($dos_array['date'] == date("Y-m-d")){echo "style2";}else{echo "style1";}?>"><? echo $dos_array['title']; ?></a></td>
		<td nowrap="nowrap" width=40 align="left"><? echo $dos_array['hits']; ?></td>
		<td nowrap="nowrap" width="9" valign="middle" align="center"><a href="related.php?program=<? echo $dos_array['r']; ?>" class="style16" title="related releases">R</a></td><td nowrap="nowrap" width="9" valign="middle" align="center"></td>
		<td nowrap="nowrap" width="9" valign="middle" align="center"><a href="download.php?id=<? echo $dos_array['id']; ?>" class="style16" title="download">D</a></td>
		<td nowrap="nowrap" width="135"><a href="author.php?name=<? echo $dos_array['author']; ?>"><? echo $dos_array['author']; ?></a></td>
	</tr>
<?}?>
	</tbody>
	</table>