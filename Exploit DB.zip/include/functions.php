﻿<?
@include('config.php');

function SiteInfo($info){
$query = mysql_query("SELECT * FROM `site_info`");
$array = mysql_fetch_array($query);
return $array[$info];
}

function Statistics($type){
$query = mysql_query("SELECT * FROM `exploits` WHERE `type`='".$type."'");
$num = mysql_num_rows($query);
return $num;
}

function Statistics_total(){
$query = mysql_query("SELECT * FROM `exploits`");
$num = mysql_num_rows($query);
return $num;
}

function Statistics_links(){
$query = mysql_query("SELECT * FROM `links`");
$num = mysql_num_rows($query);
return $num;
}

function Statistics_authors(){
$query = mysql_query("SELECT * FROM `authors`");
$num = mysql_num_rows($query);
return $num;
}

function Statistics_visitors(){
$query = mysql_query("SELECT * FROM `visitors`");
$num = mysql_num_rows($query);
return $num;
}

function Page($s,$alg,$cjp_dz,$limit){
$cj = $s + 1;
$cjp = $s - 1;

if ($cjp_dz > 10){

if ($s == 1) {

$dz = 1;
$son = 10;

for ($i=$dz;$i<=$son;$i++){
if ($i == $s) echo '['.$i.'] ';
else echo '<a href="'.$PHP_SELF.'?page='.$i.'">'.$i.'</a> ';
}

echo '<a href="'.$PHP_SELF.'?page='.$cj.'" class="style1">Next »</a>&nbsp;';

} elseif ($s < 6){

$dz = 1;
$son = 10;

echo '<a href="'.$PHP_SELF.'?page='.$cjp.'" class="style1">« Prev</a>&nbsp;';

for ($i=$dz;$i<=$son;$i++){
if ($i == $s) echo '['.$i.'] ';
else echo '<a href="'.$PHP_SELF.'?page='.$i.'">'.$i.'</a> ';
}

echo '<a href="'.$PHP_SELF.'?page='.$cj.'" class="style1">Next »</a>&nbsp;';

} elseif ($s == $cjp_dz){

$dz = $s - 10;
$son = $cjp_dz;

echo '<a href="'.$PHP_SELF.'?page='.$cjp.'" class="style1">« Prev</a>&nbsp;';

for ($i=$dz;$i<=$son;$i++){
if ($i == $s) echo '['.$i.'] ';
else echo '<a href="'.$PHP_SELF.'?page='.$i.'">'.$i.'</a> ';
}

} elseif ($s > $cjp_dz-5){

$dz = $cjp_dz - 10;
$son = $cjp_dz;

echo '<a href="'.$PHP_SELF.'?page='.$cjp.'" class="style1">« Prev</a>&nbsp;';

for ($i=$dz;$i<=$son;$i++){
if ($i == $s) echo '['.$i.'] ';
else echo '<a href="'.$PHP_SELF.'?page='.$i.'">'.$i.'</a> ';
}

echo '<a href="'.$PHP_SELF.'?page='.$cj.'" class="style1">Next »</a>&nbsp;';

} else {

$dz = $s - 5;
$son = $s + 5;

echo '<a href="'.$PHP_SELF.'?page='.$cjp.'" class="style1">« Prev</a>&nbsp;';

for ($i=$dz;$i<=$son;$i++){
if ($i == $s) echo '['.$i.'] ';
else echo '<a href="'.$PHP_SELF.'?page='.$i.'">'.$i.'</a> ';
}

echo '<a href="'.$PHP_SELF.'?page='.$cj.'" class="style1">Next »</a>&nbsp;';

}

} else {

if ($cjp_dz > 1){
if ($s == 1){

for ($i=1;$i<=$cjp_dz;$i++){
if ($i == $s) echo '['.$i.'] ';
else echo '<a href="'.$PHP_SELF.'?page='.$i.'">'.$i.'</a> ';
}

echo '<a href="'.$PHP_SELF.'?page='.$cj.'" class="style1">Next »</a>&nbsp;';

} elseif ($s == $cjp_dz) {

echo '<a href="'.$PHP_SELF.'?page='.$cjp.'" class="style1">« Prev</a>&nbsp;';

for ($i=1;$i<=$cjp_dz;$i++){
if ($i == $s) echo '['.$i.'] ';
else echo '<a href="'.$PHP_SELF.'?page='.$i.'">'.$i.'</a> ';
}

} else {

echo '<a href="'.$PHP_SELF.'?page='.$cjp.'" class="style1">« Prev</a>&nbsp;';

for ($i=1;$i<=$cjp_dz;$i++){
if ($i == $s) echo '['.$i.'] ';
else echo '<a href="'.$PHP_SELF.'?page='.$i.'">'.$i.'</a> ';
}

echo '<a href="'.$PHP_SELF.'?page='.$cj.'" class="style1">Next »</a>&nbsp;';

}

} else {

for ($i=1;$i<=$cjp_dz;$i++){
if ($i == $s) echo '['.$i.'] ';
else echo '<a href="'.$PHP_SELF.'?page='.$i.'">'.$i.'</a> ';
}

}

}

return $s;
return $alg;
return $cjp_dz;
return $limit;
}


function backup_tables($host,$user,$pass,$name,$tables = 'authors,exploits,links,site_info')
{
	
	$link = mysql_connect($host,$user,$pass);
	mysql_select_db($name,$link);
	

	if($tables == '*')
	{
		$tables = array();
		$result = mysql_query('SHOW TABLES');
		while($row = mysql_fetch_row($result))
		{
			$tables[] = $row[0];
		}
	}
	else
	{
		$tables = is_array($tables) ? $tables : explode(',',$tables);
	}
	

	foreach($tables as $table)
	{
		$result = mysql_query('SELECT * FROM '.$table);
		$num_fields = mysql_num_fields($result);
		
		$return.= 'DROP TABLE '.$table.';';
		$row2 = mysql_fetch_row(mysql_query('SHOW CREATE TABLE '.$table));
		$return.= "\n\n".$row2[1].";\n\n";
		
		for ($i = 0; $i < $num_fields; $i++) 
		{
			while($row = mysql_fetch_row($result))
			{
				$return.= 'INSERT INTO '.$table.' VALUES(';
				for($j=0; $j<$num_fields; $j++) 
				{
					$row[$j] = addslashes($row[$j]);
					$row[$j] = ereg_replace("\n","\\n",$row[$j]);
					if (isset($row[$j])) { $return.= '"'.$row[$j].'"' ; } else { $return.= '""'; }
					if ($j<($num_fields-1)) { $return.= ','; }
				}
				$return.= ");\n";
			}
		}
		$return.="\n\n\n";
	}
	

	$handle = fopen('backup/backup-'.date("Y-m-d").'.sql','w+');
	fwrite($handle,$return);
	fclose($handle);
}
?>