	<br><b>[ <a href="locals.php" target=_self>local</a> ]</b>
	<table width="597" align="center" border="0">
	<tbody>
	<tr class="style1">
		<td class="style1">-::DATE</td>
		<td class="style1">-::DESCRIPTION</td>
		<td class="style1" width="40">-::HITS</td>
		<td class="style1" width="9"></td>
		<td class="style1" width="9"></td>
		<td class="style1" width="9"></td>
		<td>-::AUTHOR</td>
	</tr>
<?
$local = mysql_query("SELECT * FROM `exploits` WHERE `type`='local' ORDER BY `id` DESC LIMIT 6");
while ($loc_array = mysql_fetch_array($local)){
?>
	<tr class="submit">
		<td class="style1" nowrap="nowrap" width="62"><? echo $loc_array['date']; ?></td>
		<td nowrap="nowrap" width="375"><a href="exploits.php?id=<? echo $loc_array['id']; ?>" target="_blank" class="<? if($loc_array['date'] == date("Y-m-d")){echo "style2";}else{echo "style1";}?>"><? echo $loc_array['title']; ?></a></td>
		<td nowrap="nowrap" width=40 align="left"><? echo $loc_array['hits']; ?></td>
		<td nowrap="nowrap" width="9" valign="middle" align="center"><a href="related.php?program=<? echo $loc_array['r']; ?>" class="style16" title="related releases">R</a></td><td nowrap="nowrap" width="9" valign="middle" align="center"></td>
		<td nowrap="nowrap" width="9" valign="middle" align="center"><a href="download.php?id=<? echo $loc_array['id']; ?>" class="style16" title="download">D</a></td>
		<td nowrap="nowrap" width="135"><a href="author.php?name=<? echo $loc_array['author']; ?>"><? echo $loc_array['author']; ?></a></td>
	</tr>
<?}?>
	</tbody>
	</table>