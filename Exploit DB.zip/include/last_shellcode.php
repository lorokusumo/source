	<br><b>[ <a href="shellcodes.php" target=_self>shellcode</a> ]</b>
	<table width="597" align="center" border="0">
	<tbody>
	<tr class="style1">
		<td class="style1">-::DATE</td>
		<td class="style1">-::DESCRIPTION</td>
		<td class="style1" width="40">-::HITS</td>
		<td class="style1" width="9"></td>
		<td class="style1" width="9"></td>
		<td class="style1" width="9"></td>
		<td>-::AUTHOR</td>
	</tr>
<?
$shellcode = mysql_query("SELECT * FROM `exploits` WHERE `type`='shellcode' ORDER BY `id` DESC LIMIT 6");
while ($she_array = mysql_fetch_array($shellcode)){
?>
	<tr class="submit">
		<td class="style1" nowrap="nowrap" width="62"><? echo $she_array['date']; ?></td>
		<td nowrap="nowrap" width="375"><a href="exploits.php?id=<? echo $she_array['id']; ?>" target="_blank" class="<? if($she_array['date'] == date("Y-m-d")){echo "style2";}else{echo "style1";}?>"><? echo $she_array['title']; ?></a></td>
		<td nowrap="nowrap" width=40 align="left"><? echo $she_array['hits']; ?></td>
		<td nowrap="nowrap" width="9" valign="middle" align="center"><a href="related.php?program=<? echo $she_array['r']; ?>" class="style16" title="related releases">R</a></td><td nowrap="nowrap" width="9" valign="middle" align="center"></td>
		<td nowrap="nowrap" width="9" valign="middle" align="center"><a href="download.php?id=<? echo $she_array['id']; ?>" class="style16" title="download">D</a></td>
		<td nowrap="nowrap" width="135"><a href="author.php?name=<? echo $she_array['author']; ?>"><? echo $she_array['author']; ?></a></td>
	</tr>
<?}?>
	</tbody>
	</table>