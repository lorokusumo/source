	<br><b>[ <a href="videos.php" target=_self>videos</a> ]</b>
	<table width="597" align="center" border="0">
	<tbody>
	<tr class="style1">
		<td class="style1">-::DATE</td>
		<td class="style1">-::DESCRIPTION</td>
		<td class="style1" width="40">-::HITS</td>
		<td class="style1" width="9"></td>
		<td class="style1" width="9"></td>
		<td class="style1" width="9"></td>
		<td>-::AUTHOR</td>
	</tr>
<?
$videos = mysql_query("SELECT * FROM `exploits` WHERE `type`='videos' ORDER BY `id` DESC LIMIT 6");
while ($vid_array = mysql_fetch_array($videos)){
?>
	<tr class="submit">
		<td class="style1" nowrap="nowrap" width="62"><? echo $vid_array['date']; ?></td>
		<td nowrap="nowrap" width="375"><a href="exploits.php?id=<? echo $vid_array['id']; ?>" target="_blank" class="<? if($vid_array['date'] == date("Y-m-d")){echo "style2";}else{echo "style1";}?>"><? echo $vid_array['title']; ?></a></td>
		<td nowrap="nowrap" width=40 align="left"><? echo $vid_array['hits']; ?></td>
		<td nowrap="nowrap" width="9" valign="middle" align="center"></td><td nowrap="nowrap" width="9" valign="middle" align="center"></td>
		<td nowrap="nowrap" width="9" valign="middle" align="center"></td>
		<td nowrap="nowrap" width="135"><a href="author.php?name=<? echo $vid_array['author']; ?>"><? echo $vid_array['author']; ?></a></td>
	</tr>
<?}?>
	</tbody>
	</table>