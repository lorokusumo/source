<?
if(isset($_POST['ok'])){
if(empty($_POST['SERVER_NAME']) or empty($_POST['SERVER_USER']) or empty($_POST['SERVER_PASS']) or empty($_POST['SERVER_DB'])){
echo "<script language='javascript'>alert('Please ensure that you complete all the fields fully.');</script>";
}else{
$connect = @mysql_connect($_POST['SERVER_NAME'],$_POST['SERVER_USER'],$_POST['SERVER_PASS']);
if($connect){
$db = @mysql_select_db($_POST['SERVER_DB']);
if($db){
echo '<meta http-equiv="refresh" content="0; url=step2.php">';
$message = '<?
define("SERVER_NAME", "'.$_POST['SERVER_NAME'].'");
define("SERVER_USER", "'.$_POST['SERVER_USER'].'");
define("SERVER_PASS", "'.$_POST['SERVER_PASS'].'");
define("SERVER_DB", "'.$_POST['SERVER_DB'].'");

@mysql_connect(SERVER_NAME,SERVER_USER,SERVER_PASS) or die(mysql_error());
@mysql_select_db(SERVER_DB) or die(mysql_error());
?>';
$file = @fopen("../include/config.php","w");
@fwrite($file,$message);
@fclose($file);
}else{
echo "<script language='javascript'>alert('Please select the right database.');</script>";
}
}else{
echo "<script language='javascript'>alert('We cant connect to this serveur.');</script>";
}
}
}
?>
<html>
<head>
<title>Script Instalation.</title>
<meta name="keywords" content="exploits code, exploit code, exploits, 0-day, 0day, 0days, exploit, zero day, poc, exploit, local exploits, remote exploits, root exploits, windows, linux, new exploits, latest exploits, shellcode, Zero-day, zeroday, security articles, ezines, zines, security papers">
<link type="text/css" rel="stylesheet" href="../index_files/style.css">
<link rel="Shortcut Icon" href="../favicon.ico" type="image/x-icon">
<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
</head>
<body dir="ltr" alink="#00ff00" background="../index_files/dot.gif" bgcolor="#000000" link="#00c000" text="#008000" vlink="#00c000">
<center>
<table width="384" height="530" border="0" cellpadding="3" cellspacing="3" class="main">
  <td>
<center>
<form method="POST" action="step1.php">
<center><b>MySQL Database Connect Information</b><br><br>
	<table border="0">
		<tr>
			<td nowrap="nowrap">
				Server:
			</td>
			<td nowrap="nowrap">
				<input type="text" name="SERVER_NAME" value="<? echo $_POST['SERVER_NAME']; ?>"><input type="hidden" name="ok">
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap">
				User:
			</td>
			<td nowrap="nowrap">
				<input type="text" name="SERVER_USER" value="<? echo $_POST['SERVER_USER']; ?>">
			</td>
		</tr>
		
		<tr>
			<td nowrap="nowrap">
				Password:
			</td>
			<td nowrap="nowrap">
				<input type="text" name="SERVER_PASS" value="<? echo $_POST['SERVER_PASS']; ?>">
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap">
				Database:
			</td>
			<td nowrap="nowrap">
				<input type="text" name="SERVER_DB" value="<? echo $_POST['SERVER_DB']; ?>">
			</td>
		</tr>
	</table>
<br>
<input type="submit" value="Next »">
</center>
</form>
</center>
<p><font style="FONT-SIZE: 10px; FONT-FAMILY: 'courier new'">
<br>Coded By &copy; <a href="http://iamine.com">iAm[i]nE</a></font></p>
</td>
</tr>
</table>
</center>
</body>
</html>