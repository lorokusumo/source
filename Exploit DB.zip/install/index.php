<html>
<head>
<title>Script Instalation.</title>
<meta name="keywords" content="exploits code, exploit code, exploits, 0-day, 0day, 0days, exploit, zero day, poc, exploit, local exploits, remote exploits, root exploits, windows, linux, new exploits, latest exploits, shellcode, Zero-day, zeroday, security articles, ezines, zines, security papers">
<link type="text/css" rel="stylesheet" href="../index_files/style.css">
<link rel="Shortcut Icon" href="../favicon.ico" type="image/x-icon">
<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
</head>
<body dir="ltr" alink="#00ff00" background="../index_files/dot.gif" bgcolor="#000000" link="#00c000" text="#008000" vlink="#00c000">
<center>
<table width="384" height="530" border="0" cellpadding="3" cellspacing="3" class="main">
  <td>
<form method="POST" action="step1.php">
  <center>
  <font size="5">Milw0rm Clone Script v1.0</font><br><br>
  <h4>You have no rights to edit copyright notices or/and claim this script as your own</h4><br>
  <h4>Please report any bug you find it in the script</h4><br><br>
  <input type="submit" value="Next »"><br><br>
  </center>
</form>
<p><font style="FONT-SIZE: 10px; FONT-FAMILY: 'courier new'">
<br>Coded By &copy; <a href="http://iamine.com">iAm[i]nE</a></font></p>
</td>
</tr>
</table>
</center>
</body>
</html>