<?
if(isset($_POST['ok'])){
if(empty($_POST['site_name']) or empty($_POST['adm_usr']) or empty($_POST['adm_pwd']) or empty($_POST['adm_email']) or empty($_POST['submit_email']) or empty($_POST['site_menu']) or empty($_POST['site_url'])){
echo "<script language='javascript'>alert('Please ensure that you complete all the fields fully.');</script>";
}else{
include('../include/functions.php');

@mysql_query("CREATE TABLE `authors` (`id` int(15) NOT NULL auto_increment,`name` varchar(20) NOT NULL,`email` varchar(50) NOT NULL,`home` varchar(50) NOT NULL,PRIMARY KEY  (`id`)) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;") or die(mysql_error());  
@mysql_query('INSERT INTO authors VALUES("1","iAm[i]nE","ovi@hotmail.com","http://iamine.com");');

@mysql_query("CREATE TABLE `exploits` (`id` int(15) NOT NULL auto_increment,`title` varchar(50) NOT NULL,`exploit` text NOT NULL,`author` varchar(20) NOT NULL,`date` date NOT NULL,`hits` varchar(20) NOT NULL,`r` varchar(50) NOT NULL,`type` varchar(15) NOT NULL,PRIMARY KEY  (`id`)) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;") or die(mysql_error());  
@mysql_query('INSERT INTO exploits VALUES("1","Test of the script","Milw0rm Clone Script v1.0","iAm[i]nE","2011-07-01","1","iAm[i]nE","remote");');
@mysql_query('INSERT INTO exploits VALUES("2","Test of the script","Milw0rm Clone Script v1.0","iAm[i]nE","2011-07-01","1","iAm[i]nE","local");');
@mysql_query('INSERT INTO exploits VALUES("3","Test of the script","Milw0rm Clone Script v1.0","iAm[i]nE","2011-07-01","1","iAm[i]nE","webapps");');
@mysql_query('INSERT INTO exploits VALUES("4","Test of the script","Milw0rm Clone Script v1.0","iAm[i]nE","2011-07-01","1","iAm[i]nE","dos");');
@mysql_query('INSERT INTO exploits VALUES("5","Test of the script","Milw0rm Clone Script v1.0","iAm[i]nE","2011-07-01","1","iAm[i]nE","shellcode");');
@mysql_query('INSERT INTO exploits VALUES("6","Test of the script","Milw0rm Clone Script v1.0","iAm[i]nE","2011-07-01","1","iAm[i]nE","papers");');
@mysql_query('INSERT INTO exploits VALUES("7","Test of the script","Milw0rm Clone Script v1.0","iAm[i]nE","2011-07-01","1","iAm[i]nE","videos");');

@mysql_query("CREATE TABLE `links` (`id` int(15) NOT NULL auto_increment,`link` varchar(100) NOT NULL,`site` varchar(50) NOT NULL,`bnr` varchar(100) NOT NULL,PRIMARY KEY  (`id`)) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;") or die(mysql_error());  
@mysql_query('INSERT INTO links VALUES("1","http://iamine.com","Coder Website","http://localhost/milw0rm/index_files/banner.jpg");');

@mysql_query("CREATE TABLE `site_info` (`site_url` varchar(50) NOT NULL,`site_name` varchar(50) NOT NULL,`site_menu` text NOT NULL,`submit_email` varchar(50) NOT NULL,`adm_usr` varchar(50) NOT NULL,`adm_pwd` varchar(32) NOT NULL,`adm_email` varchar(50) NOT NULL) ENGINE=MyISAM DEFAULT CHARSET=utf8;") or die(mysql_error());  
@mysql_query('INSERT INTO site_info VALUES("'.$_POST['site_url'].'","'.$_POST['site_name'].'","'.$_POST['site_menu'].'","'.$_POST['submit_email'].'","'.$_POST['adm_usr'].'","'.md5($_POST['adm_pwd']).'","'.$_POST['adm_email'].'");');

@mysql_query("CREATE TABLE `visitors` (`id` int(15) NOT NULL auto_increment,`ip` text NOT NULL,`time` text NOT NULL,PRIMARY KEY  (`id`)) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;") or die(mysql_error());
@mysql_query('INSERT INTO visitors VALUES("1","127.0.0.1","00000");');
echo "<script language='javascript'>alert('The Script was installed Successfully');</script>";
echo '<meta http-equiv="refresh" content="0; url=../index.php">';
}
}
?>
<html>
<head>
<title>Script Instalation.</title>
<meta name="keywords" content="exploits code, exploit code, exploits, 0-day, 0day, 0days, exploit, zero day, poc, exploit, local exploits, remote exploits, root exploits, windows, linux, new exploits, latest exploits, shellcode, Zero-day, zeroday, security articles, ezines, zines, security papers">
<link type="text/css" rel="stylesheet" href="../index_files/style.css">
<link rel="Shortcut Icon" href="../favicon.ico" type="image/x-icon">
<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
</head>
<body dir="ltr" alink="#00ff00" background="../index_files/dot.gif" bgcolor="#000000" link="#00c000" text="#008000" vlink="#00c000">
<center>
<table width="384" height="530" border="0" cellpadding="3" cellspacing="3" class="main">
  <td>
<center>
<form method="POST" action="step2.php">
<center><b>Website Information</b><br><br>
	<table border="0">
		<tr>
			<td nowrap="nowrap">
				Site Name:
			</td>
			<td nowrap="nowrap">
				<input type="text" name="site_name" value="<? echo $_POST['site_name']; ?>"><input type="hidden" name="ok">
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap">
				Admin Username:
			</td>
			<td nowrap="nowrap">
				<input type="text" name="adm_usr" value="<? echo $_POST['adm_usr']; ?>">
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap">
				Admin Password:
			</td>
			<td nowrap="nowrap">
				<input type="text" name="adm_pwd" value="<? echo $_POST['adm_pwd']; ?>">
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap">
				Admin Email:
			</td>
			<td nowrap="nowrap">
				<input type="text" name="adm_email" value="<? echo $_POST['adm_email']; ?>">
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap">
				Submit Email:
			</td>
			<td nowrap="nowrap">
				<input type="text" name="submit_email" value="<? echo $_POST['submit_email']; ?>">
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap">
				Site Menu:<br><br><em>Edit the file menu.html<br> and copy/past it here</em>
			</td>
			<td nowrap="nowrap" width="250" height="250">
				<textarea style="width:250px;height:250px;" name="site_menu"><? echo $_POST['site_menu']; ?></textarea>
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap">
				Site Url:
			</td>
			<td nowrap="nowrap">
				<input type="text" maxlength="30" size="30" name="site_url" value="http://<? echo $_POST['site_url']; ?>">
			</td>
		</tr>
	</table>
<br>
<input type="submit" value="Install.">
</center>
</form>
</center>
<p><font style="FONT-SIZE: 10px; FONT-FAMILY: 'courier new'">
<br>Coded By &copy; <a href="http://iamine.com">iAm[i]nE</a></font></p>
</td>
</tr>
</table>
</center>
</body>
</html>