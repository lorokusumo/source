#Milw0rm Clone Script v1.0
Created By iAm[i]nE on 2008 relased on 2011

I create this project on 2008 and i don't have time to Fix it and release it.

#Installation:
1.Upload all file to your Website.
2.Go to index.php or install/
3.Make sure that this script can creat the config.php in include/

#Credit:
I get the idea from Milw0rm.com (str0ke).

for more information contact:www.iamine.com

Greetz:Big_mouh/Dj.zaki/Chou/All my friends