<?
include('include/functions.php');
?>
<html>
<head>
<title><? echo SiteInfo('site_name');?> - exploits : vulnerabilities : videos : papers : shellcode</title>
<meta name="description" content="<? echo SiteInfo('site_name');?> exploits and 0day exploits database">
<meta name="keywords" content="exploits code, exploit code, exploits, 0-day, 0day, 0days, exploit, zero day, poc, exploit, local exploits, remote exploits, root exploits, windows, linux, new exploits, latest exploits, shellcode, Zero-day, zeroday, security articles, ezines, zines, security papers">
<link type="text/css" rel="stylesheet" href="index_files/style.css">
<link rel="alternate" type="text/xml" title="<? echo SiteInfo('site_name');?> - RSS Feed" href="/rss.php">
<link rel="Shortcut Icon" href="index_files/favicon.ico" type="image/x-icon">
<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
</head>
<body dir="ltr" alink="#00ff00" background="index_files/dot.gif" bgcolor="#000000" link="#00c000" text="#008000" vlink="#00c000">
<center>
<table border="0">
	<tr>
		<td nowrap="nowrap">
			<? echo SiteInfo('site_menu');?>
		</td>
    </tr>
 </table>

<table width="668" border="0" cellpadding="3" cellspacing="3" class="main">
  <tr><td><img src="index_files/banner.jpg" alt="milw0rm"></td></tr>
  <tr>
  <td>
	<br><b>[ <a href="links.php" target=_self>Links</a> ]</b><br><br>
	<table width="597" align="center" border="0">
	<tbody>
	<tr class="style1">
		<td class="td" align="center">-::Site Name</td>
		<td class="td" align="center">-::Link</td>
		<td class="td" align="center">-::Banner</td>
	</tr>
<?
$links = mysql_query("SELECT * FROM `links`");
while ($link_array = mysql_fetch_array($links)){
?>
	<tr class="">
		<td class="td" align="center"><b><? echo $link_array['site']; ?></b></td>
		<td class="td" align="center"><b><a href="<? echo $link_array['link']; ?>"><? echo $link_array['link']; ?></a></b></td>
		<td class="td" align="center"><a href="<? echo $link_array['link']; ?>"><img src="<? echo $link_array['bnr']; ?>" width="90" height="30" border="0"></a></td>
	</tr>
<?}?>
	</tbody>
	</table><br>
<p><font style="FONT-SIZE: 10px; FONT-FAMILY: 'courier new'">send all submissions to 
<a href="mailto:<? echo SiteInfo('submit_email');?>"><? echo SiteInfo('submit_email');?></a>
<br>Coded By &copy; <a href="http://iamine.com">iAm[i]nE</a> <a href="<? echo SiteInfo('site_url');?>"><br><? echo SiteInfo('site_name');?></a> </font></p>
	</td>
	</tr>
</table>
</center>
</body>
</html>