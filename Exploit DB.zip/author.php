<?
include("include/functions.php");

$author = htmlspecialchars(trim($_GET['name']));

$query = mysql_query("SELECT * FROM `exploits` WHERE `author`='".$author."'");
$row = mysql_num_rows($query);
if($row){
$authors = mysql_query("SELECT * FROM `authors` WHERE `name`='".$author."'");
$result = mysql_fetch_array($authors);
?>
<html>
<head>
<title><? echo SiteInfo('site_name');?> - exploits : vulnerabilities : videos : papers : shellcode</title>
<meta name="description" content="<? echo SiteInfo('site_name');?> exploits and 0day exploits database">
<meta name="keywords" content="exploits code, exploit code, exploits, 0-day, 0day, 0days, exploit, zero day, poc, exploit, local exploits, remote exploits, root exploits, windows, linux, new exploits, latest exploits, shellcode, Zero-day, zeroday, security articles, ezines, zines, security papers">
<link type="text/css" rel="stylesheet" href="index_files/style.css">
<link rel="alternate" type="text/xml" title="<? echo SiteInfo('site_name');?> - RSS Feed" href="/rss.php">
<link rel="Shortcut Icon" href="index_files/favicon.ico" type="image/x-icon">
<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
</head>
<body dir="ltr" alink="#00ff00" background="index_files/dot.gif" bgcolor="#000000" link="#00c000" text="#008000" vlink="#00c000">
<center>
<table border="0">
	<tr>
		<td nowrap="nowrap">
			<? echo SiteInfo('site_menu');?>
		</td>
    </tr>
 </table>

<table width="668" border="0" cellpadding="3" cellspacing="3" class="main">
  <tr><td><img src="index_files/banner.jpg" alt="milw0rm"></td></tr>
  <tr>
  <td><br>
	<table align="center" border="0" bordercolor="#333333" cellpadding="0" cellspacing="0" width="597">
		<tbody>
			<tr>
				<td width="75"><strong>Author: </strong></td>
				<td><p style="font-size: 11px;"><? echo $author; ?></p></td>
				<td align="left"><img src="emailimage.php?email=<? echo $result['email']; ?>"></td>
			</tr>
		</tbody>
	</table>
	<table align="center" border="0" bordercolor="#333333" cellpadding="0" cellspacing="0" width="597">
		<tbody>
			<tr>
				<td width="75"><strong>Homepage:</strong></td>
				<td><a href="<? echo $result['home']; ?>" target="_blank"><? echo $result['home']; ?></a></td>
			</tr>
		</tbody>
	</table>

	<br><b class="style1">[ <? echo $author; ?> ]</b>
	<table width="597" align="center" border="0">
	<tbody>
	<tr class="style1">
		<td class="style1">-::DATE</td>
		<td class="style1">-::DESCRIPTION</td>
		<td class="style1" width="40">-::HITS</td>
		<td class="style1" width="9"></td>
		<td class="style1" width="9"></td>
		<td class="style1" width="9"></td>
		<td>-::AUTHOR</td>
	</tr>
<?
while ($auth = mysql_fetch_array($query)){
?>
	<tr class="submit">
		<td class="style1" nowrap="nowrap" width="62"><? echo $auth['date']; ?></td>
		<td nowrap="nowrap" width="375"><a href="exploits.php?id=<? echo $auth['id']; ?>" target="_blank" class="<? if($auth['date'] == date("Y-m-d")){echo "style2";}else{echo "style1";}?>"><? echo $auth['title']; ?></a></td>
		<td nowrap="nowrap" width=40 align="left"><? echo $auth['hits']; ?></td>
		<td nowrap="nowrap" width="9" valign="middle" align="center"></td><td nowrap="nowrap" width="9" valign="middle" align="center"></td>
		<td nowrap="nowrap" width="9" valign="middle" align="center"><? if($auth['type'] !== 'videos'){echo '<a href="download.php?id='.$auth['id'].'" class="style16" title="download">D</a></td>';}else{echo '';}?>
		<td nowrap="nowrap" width="135"><a href="author.php?name=<? echo $auth['author']; ?>"><? echo $auth['author']; ?></a></td>
	</tr>
<?}?>
	</tbody>
	</table>
<p><font style="FONT-SIZE: 10px; FONT-FAMILY: 'courier new'">send all submissions to 
<a href="mailto:<? echo SiteInfo('submit_email');?>"><? echo SiteInfo('submit_email');?></a>
<br>Coded By &copy; <a href="http://iamine.com">iAm[i]nE</a> <a href="<? echo SiteInfo('site_url');?>"><br><? echo SiteInfo('site_name');?></a> </font></p>
	</td>
	</tr>
</table>
</center>
</body>
</html>
<? }else{
echo ' ';
}
?>