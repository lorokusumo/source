<?
function Email_Image() {
 $email = $_GET["email"];;
 if ($email) {
  $resim  = ImageCreate(300,15);
  $beyaz  = ImageColorAllocate($resim, 0, 100, 0);
  $rand   = ImageColorAllocate($resim, 0, 0, 0);
  ImageFill($resim, 0, 0, $rand);
  ImageString($resim, 2, 0, 0, $email, $beyaz);
  header("Content,type: image/png");
  ImagePng($resim);
  ImageDestroy($resim);
 }
}
Email_Image();
?>