<?php
include('include/functions.php');

$xml = '<?xml version="1.0" encoding="iso-8859-1"?><rss version="2.0">';
$xml .= '<channel>'; 
$xml .= '<title>'.SiteInfo("site_name").'</title>';
$xml .= '<link>'.SiteInfo("site_url").'</link>';
$xml .= '<description>'.SiteInfo("site_url").' RSS</description>';

$res = mysql_query("SELECT * FROM `exploits` ORDER BY `id` DESC LIMIT 10");


while( $tab = mysql_fetch_array($res)){

	$xml .= '<item>';
	$xml .= '<title>'.$tab["title"].'</title>';
	$xml .= '<link>'.SiteInfo("site_url").'/exploit.php?id='.$tab["id"].'</link>';
	$xml .= '<pubDate>'.date("D, j M Y H:i").' +0000 </pubDate>'; 
	$xml .= '</item>';	
}

$xml .= '</channel>';
$xml .= '</rss>';

$fp = fopen("flux.xml", 'w+');
fputs($fp, $xml);
fclose($fp);

$filename = "flux.xml";
$handle = fopen($filename, "r");
$contents = fread($handle, filesize($filename));
echo $contents;
?>