<?
include("include/functions.php");
?>
<html>
<head>
<title><? echo SiteInfo('site_name');?> - exploits : vulnerabilities : videos : papers : shellcode</title>
<meta name="description" content="<? echo SiteInfo('site_name');?> exploits and 0day exploits database">
<meta name="keywords" content="exploits code, exploit code, exploits, 0-day, 0day, 0days, exploit, zero day, poc, exploit, local exploits, remote exploits, root exploits, windows, linux, new exploits, latest exploits, shellcode, Zero-day, zeroday, security articles, ezines, zines, security papers">
<link type="text/css" rel="stylesheet" href="index_files/style.css">
<link rel="alternate" type="text/xml" title="<? echo SiteInfo('site_name');?> - RSS Feed" href="/rss.php">
<link rel="Shortcut Icon" href="index_files/favicon.ico" type="image/x-icon">
<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
</head>
<body dir="ltr" alink="#00ff00" background="index_files/dot.gif" bgcolor="#000000" link="#00c000" text="#008000" vlink="#00c000">
<center>
<table border="0">
	<tr>
		<td nowrap="nowrap">
			<? echo SiteInfo('site_menu');?>
		</td>
    </tr>
 </table>

<table width="668" border="0" cellpadding="3" cellspacing="3" class="main">
  <tr><td><img src="index_files/banner.jpg" alt="milw0rm"></td></tr>
  <tr>
  <td>
<?
$page = $_GET['page'];
if (!isset($_GET['page'])){
$page = 1;
}

$limit = '20';
$dz = $limit*($page-1);
$papers_al = mysql_query("SELECT * FROM `exploits` WHERE `type`='papers'");
$cjp = mysql_num_rows($papers_al);
$paperss = mysql_query("SELECT * FROM `exploits` WHERE `type`='papers' ORDER BY `id` DESC LIMIT $dz,$limit");
$pages = ceil($cjp/$limit);

if ($page < 1 || $page > $pages){
echo '<meta http-equiv="refresh" content="0; url=papers.php">';
}
?>

	<br><b>[ <a href="papers.php" target=_self>papers</a> ]</b>
	<table width="597" align="center" border="0">
	<tbody>
	<tr class="style1">
		<td class="style1">-::DATE</td>
		<td class="style1">-::DESCRIPTION</td>
		<td class="style1" width="40">-::HITS</td>
		<td class="style1" width="9"></td>
		<td class="style1" width="9"></td>
		<td class="style1" width="9"></td>
		<td>-::AUTHOR</td>
	</tr>
<?
while ($pap_array = mysql_fetch_array($paperss)){
?>
	<tr class="submit">
		<td class="style1" nowrap="nowrap" width="62"><? echo $pap_array['date']; ?></td>
		<td nowrap="nowrap" width="375"><a href="exploits.php?id=<? echo $pap_array['id']; ?>" target="_blank" class="<? if($pap_array['date'] == date("Y-m-d")){echo "style2";}else{echo "style1";}?>"><? echo $pap_array['title']; ?></a></td>
		<td nowrap="nowrap" width=40 align="left"><? echo $pap_array['hits']; ?></td>
		<td nowrap="nowrap" width="9" valign="middle" align="center"></td><td nowrap="nowrap" width="9" valign="middle" align="center"></td>
		<td nowrap="nowrap" width="9" valign="middle" align="center"><a href="download.php?id=<? echo $pap_array['id']; ?>" class="style16" title="download">D</a></td>
		<td nowrap="nowrap" width="135"><a href="author.php?name=<? echo $pap_array['author']; ?>"><? echo $pap_array['author']; ?></a></td>
	</tr>
<?}?>
	</tbody>
	</table>
	<br>
<? Page($page,$cjp,$pages,$limit); ?>
<p><font style="FONT-SIZE: 10px; FONT-FAMILY: 'courier new'">send all submissions to 
<a href="mailto:<? echo SiteInfo('submit_email');?>"><? echo SiteInfo('submit_email');?></a>
<br>Coded By &copy; <a href="http://iamine.com">iAm[i]nE</a> <a href="<? echo SiteInfo('site_url');?>"><br><? echo SiteInfo('site_name');?></a> </font></p>
	</td>
	</tr>
</table>
</center>
</body>
</html>