<?
include ("session.php");
include('../include/functions.php');

if($_GET['action'] == 'send'){
if(empty($_POST['email']) or empty($_POST['subject']) or empty($_POST['msg'])){
echo "<script language='javascript'>alert('Please ensure that you complete all the fields fully.');</script>";
}else{
@mail($_POST['email'],$_POST['sebject'],$_POST['msg'],"From: ".SiteInfo('site_name')."<".SiteInfo('adm_email').">");
$msg = 'Your Message Was Sent Successfully.';
}
}
?>
<html>
<head>
<title><? echo SiteInfo('site_name');?> - exploits : vulnerabilities : videos : papers : shellcode</title>
<meta name="description" content="<? echo SiteInfo('site_name');?> exploits and 0day exploits database">
<meta name="keywords" content="exploits code, exploit code, exploits, 0-day, 0day, 0days, exploit, zero day, poc, exploit, local exploits, remote exploits, root exploits, windows, linux, new exploits, latest exploits, shellcode, Zero-day, zeroday, security articles, ezines, zines, security papers">
<link type="text/css" rel="stylesheet" href="../index_files/style.css">
<link rel="alternate" type="text/xml" title="<? echo SiteInfo('site_name');?> - RSS Feed" href="/rss.php">
<link rel="Shortcut Icon" href="../index_files/favicon.ico" type="image/x-icon">
<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
</head>
<body dir="ltr" alink="#00ff00" background="../index_files/dot.gif" bgcolor="#000000" link="#00c000" text="#008000" vlink="#00c000">
<center>
<table width="350" height="400" border="0" cellpadding="3" cellspacing="3" class="main">
  <td>
<center><? echo $msg;?>
<form method="POST" action="mail.php?action=send">
<br><br>
<center>
	<table border="0">
		<tr>
			<td nowrap="nowrap">
				Email:
			</td>
			<td nowrap="nowrap">
				<input type="text" name="email" size="25" value="<? echo $_POST['email'];?>">
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap">
				Subject:
			</td>
			<td nowrap="nowrap">
				<input type="text" name="subject" size="25" value="<? echo $_POST['subject'];?>">
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap">
				Message:
			</td>
			<td nowrap="nowrap" width="150" height="150">
				<textarea style="width:180px;height:180px;" name="msg"><? echo $_POST['msg'];?></textarea>
			</td>
		</tr>
	</table>
<br>
<input type="submit" value="SEND">  <input type="submit" value="CLOSE" onClick="javascript:window.close();">
</center>
</form>
</center>
<p><font style="FONT-SIZE: 10px; FONT-FAMILY: 'courier new'">
<br>Coded By &copy; <a href="http://iamine.com">iAm[i]nE</a> <a href="<? echo SiteInfo('site_url');?>"><br><? echo SiteInfo('site_name');?></a> </font></p>
</td>
</tr>
</table>
</center>
</body>
</html>