<?
include ("session.php");
include('../include/functions.php');

if($_GET['action'] == 'add'){
if(empty($_POST['site']) or empty($_POST['link']) or empty($_POST['bnr'])){
echo "<script language='javascript'>alert('Please ensure that you complete all the fields fully.');</script>";
}else{
$sql = mysql_query("INSERT INTO `links` VALUES ('', '".$_POST['link']."', '".$_POST['site']."', '".$_POST['bnr']."'); ");
if($sql){
echo "<script language='javascript'>alert('Done...!');</script>";
}else{
echo "<script language='javascript'>alert('Oups...!');</javascript>";
}
}
}

if($_GET['action'] == 'del'){
if(isset($_GET['id']) && is_numeric($_GET['id'])){
$del = mysql_query("DELETE FROM `links` WHERE id = '".$_GET['id']."';");
echo "<script language='javascript'>alert('Done...!');</script>";
}
}

$res = mysql_query("SELECT * FROM `links` ORDER BY `id`");
?>
<html>
<head>
<title><? echo SiteInfo('site_name');?> - exploits : vulnerabilities : videos : papers : shellcode</title>
<meta name="description" content="<? echo SiteInfo('site_name');?> exploits and 0day exploits database">
<meta name="keywords" content="exploits code, exploit code, exploits, 0-day, 0day, 0days, exploit, zero day, poc, exploit, local exploits, remote exploits, root exploits, windows, linux, new exploits, latest exploits, shellcode, Zero-day, zeroday, security articles, ezines, zines, security papers">
<link type="text/css" rel="stylesheet" href="../index_files/style.css">
<link rel="alternate" type="text/xml" title="<? echo SiteInfo('site_name');?> - RSS Feed" href="/rss.php">
<link rel="Shortcut Icon" href="../index_files/favicon.ico" type="image/x-icon">
<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
</head>
<body dir="ltr" alink="#00ff00" background="../index_files/dot.gif" bgcolor="#000000" link="#00c000" text="#008000" vlink="#00c000">
<center>
<table width="350" height="220" border="0" cellpadding="3" cellspacing="3" class="main">
  <td>
<center>
<form method="POST" action="links.php?action=add">
<center>
	<table border="0">
		<tr>
			<td nowrap="nowrap" width="140" class="td" align="center">
				<b>Site Name :</b>
			</td>
			<td nowrap="nowrap" width="140" class="td" align="center">
				<b>Link :<em>(with http://)</em></b>
			</td>
			<td nowrap="nowrap" width="140" class="td" align="center">
				<b>Bnr : <em>(Image Link 90x30)</em></b>
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap" width="140" class="td" align="center">
				<input type="text" name="site">
			</td>
			<td nowrap="nowrap" width="140" class="td" align="center">
				<input type="text" name="link" value="http://">
			</td>
			<td nowrap="nowrap" width="140" class="td" align="center">
				<input type="text" name="bnr" value="http://">
			</td>
		</tr>
	</table>
<br>
<input type="submit" value="ADD">
<br>__________________________________________<br><br><br>
	<table border="0">
		<tr>
			<td nowrap="nowrap" width="170" class="td" align="center">
				<b>Site Name :</b>
			</td>
			<td nowrap="nowrap" width="170" class="td" align="center">
				<b>Link :</b>
			</td>
			<td nowrap="nowrap" width="50" class="td" align="center">
				<b>Delete :</b>
			</td>
		</tr>
<?
while( $tab = mysql_fetch_array($res)){
echo '

		<tr>
			<td nowrap="nowrap" width="170" class="td" align="center">
				<b>'.$tab["site"].'</b>
			</td>
			<td nowrap="nowrap" width="170" class="td" align="center">
				<b><a href="'.$tab["link"].'">'.$tab["link"].'<a/></b>
			</td>
			<td nowrap="nowrap" width="50" class="td" align="center">
				<a href="links.php?action=del&id='.$tab["id"].'" border="0"><img src="img/del.gif"></a>
			</td>
		</tr>';
}
?>
	</table>
<br><input type="submit" value="CLOSE" onClick="javascript:window.close();">
</center>
</form>
</center>
<p><font style="FONT-SIZE: 10px; FONT-FAMILY: 'courier new'">
<br>Coded By &copy; <a href="http://iamine.com">iAm[i]nE</a> <a href="<? echo SiteInfo('site_url');?>"><br><? echo SiteInfo('site_name');?></a> </font></p>
</td>
</tr>
</table>
</center>
</body>
</html>