<?
include ("session.php");
include('../include/functions.php');

$res = mysql_query("SELECT * FROM `visitors` ORDER BY `id` DESC LIMIT 10");
?>
<html>
<head>
<title><? echo SiteInfo('site_name');?> - exploits : vulnerabilities : videos : papers : shellcode</title>
<meta name="description" content="<? echo SiteInfo('site_name');?> exploits and 0day exploits database">
<meta name="keywords" content="exploits code, exploit code, exploits, 0-day, 0day, 0days, exploit, zero day, poc, exploit, local exploits, remote exploits, root exploits, windows, linux, new exploits, latest exploits, shellcode, Zero-day, zeroday, security articles, ezines, zines, security papers">
<link type="text/css" rel="stylesheet" href="../index_files/style.css">
<link rel="alternate" type="text/xml" title="<? echo SiteInfo('site_name');?> - RSS Feed" href="/rss.php">
<link rel="Shortcut Icon" href="../index_files/favicon.ico" type="image/x-icon">
<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
</head>
<body dir="ltr" alink="#00ff00" background="../index_files/dot.gif" bgcolor="#000000" link="#00c000" text="#008000" vlink="#00c000">
<center>
<table width="350" height="220" border="0" cellpadding="3" cellspacing="3" class="main">
  <td>
<center>
<form method="POST" action="settings.php">
<center>
	<table border="0">
		<tr>
			<td nowrap="nowrap" width="140" class="td" align="center">
				<b>IP :</b>
			</td>
			<td nowrap="nowrap" width="140" class="td" align="center">
				<b>Time :</b>
			</td>
		</tr>
<?
while( $tab = mysql_fetch_array($res)){
echo '
		<tr>
			<td nowrap="nowrap" width="140" class="td" align="center">
				<b>'.$tab["ip"].'</b>
			</td>
			<td nowrap="nowrap" width="140" class="td" align="center">
				<b><em>'.date('d/m/Y H:i',$tab['time']).'</em></b>
			</td>
		</tr>';
}
?>
	</table>
<br>
<input type="submit" value="CLOSE" onClick="javascript:window.close();">
</center>
</form>
</center>
<p><font style="FONT-SIZE: 10px; FONT-FAMILY: 'courier new'">
<br>Coded By &copy; <a href="http://iamine.com">iAm[i]nE</a> <a href="<? echo SiteInfo('site_url');?>"><br><? echo SiteInfo('site_name');?></a> </font></p>
</td>
</tr>
</table>
</center>
</body>
</html>