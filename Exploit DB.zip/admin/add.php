<?
include ("session.php");
include('../include/functions.php');

if($_GET['action'] == 'add_exploit'){
if(empty($_POST['dsc']) or empty($_POST['type']) or empty($_POST['author']) or empty($_POST['r']) or empty($_POST['source'])){
echo "<script language='javascript'>alert('Please ensure that you complete all the fields fully.');</script>";
}else{
$auth = mysql_query("SELECT * FROM `authors` WHERE `name` = '".$_POST['author']."'");
$row = mysql_num_rows($auth);
if($row){
@mysql_query("INSERT INTO `exploits` VALUES ('', '".$_POST['dsc']."', '".$_POST['source']."', '".$_POST['author']."', '".date("Y-m-d")."', '1', '".$_POST['r']."', '".$_POST['type']."');");
echo "<script language='javascript'>alert('Done...!');</script>";
}else{
echo '<meta http-equiv="refresh" content="0; url=add.php?action=add_author&name='.$_POST['author'].'">';
}
}
}
if($_GET['action'] == 'add'){
@mysql_query("INSERT INTO `authors` VALUES ('', '".$_POST['name']."', '".$_POST['email']."', '".$_POST['home']."');");
echo "<script language='javascript'>alert('Done...!');</script>";
echo '<meta http-equiv="refresh" content="0; url=add.php">';
}
?>
<html>
<head>
<title><? echo SiteInfo('site_name');?> - exploits : vulnerabilities : videos : papers : shellcode</title>
<meta name="description" content="<? echo SiteInfo('site_name');?> exploits and 0day exploits database">
<meta name="keywords" content="exploits code, exploit code, exploits, 0-day, 0day, 0days, exploit, zero day, poc, exploit, local exploits, remote exploits, root exploits, windows, linux, new exploits, latest exploits, shellcode, Zero-day, zeroday, security articles, ezines, zines, security papers">
<link type="text/css" rel="stylesheet" href="../index_files/style.css">
<link rel="alternate" type="text/xml" title="<? echo SiteInfo('site_name');?> - RSS Feed" href="/rss.php">
<link rel="Shortcut Icon" href="../index_files/favicon.ico" type="image/x-icon">
<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
</head>
<body dir="ltr" alink="#00ff00" background="../index_files/dot.gif" bgcolor="#000000" link="#00c000" text="#008000" vlink="#00c000">
<center>
<table width="384" border="0" cellpadding="3" cellspacing="3" class="main">
  <td>
<center>
<?
if($_GET['action'] == 'add_author'){
?>
<form method="POST" action="add.php?action=add">
<center>
<br><br><br><br><b>Please Add the Author Information before you add this Exploit..!</b><br><br>
	<table border="0">
		<tr>
			<td nowrap="nowrap">
				Author Name:
			</td>
			<td nowrap="nowrap">
				<input type="text" name="name" maxlength="20" size="30" value="<? echo $_GET['name']; ?>">
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap">
				Author Email:
			</td>
			<td nowrap="nowrap">
				<input type="text" name="email" maxlength="50" size="30" value="@">
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap">
				Author Home:
			</td>
			<td nowrap="nowrap">
				<input type="text" name="home" maxlength="50" size="30" value="http://">
			</td>
		</tr>
	</table>
<br>
<input type="submit" value="SUBMIT">  <input type="submit" value="CLOSE" onClick="javascript:window.close();">
<br><br><br><br>
</center>
</form>
<?}else{?>
<form method="POST" action="add.php?action=add_exploit">
<center>
	<table border="0">
		<tr>
			<td nowrap="nowrap">
				DESCRIPTION:
			</td>
			<td nowrap="nowrap">
				<input type="text" name="dsc" maxlength="50" size="30">
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap">
				TYPE:
			</td>
			<td nowrap="nowrap">
				<select name="type">
					<option value="remote" selected>Remote</option>
					<option value="local">Local</option>
					<option value="webapps" >Web apps</option>
					<option value="dos">Dos / poc</option>
					<option value="shellcode">Shellcode</option>
					<option value="papers">Papers</option>
					<option value="videos">Videos</option>
				</select>
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap">
				AUTHOR:
			</td>
			<td nowrap="nowrap">
				<input type="text" name="author" maxlength="20">
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap">
				RELATED:
			</td>
			<td nowrap="nowrap">
				<input type="text" name="r">
			</td>
		</tr>
		<tr width="200" height="200">
			<td nowrap="nowrap">
				SOURCE:
			</td>
			<td nowrap="nowrap">
				<textarea style="width:230;height:200" name="source"></textarea>
			</td>
		</tr>
	</table>
<br>
<input type="submit" value="SUBMIT">  <input type="submit" value="CLOSE" onClick="javascript:window.close();">
</center>
</form>
<? } ?>
</center>
<p><font style="FONT-SIZE: 10px; FONT-FAMILY: 'courier new'">
<br>Coded By &copy; <a href="http://iamine.com">iAm[i]nE</a> <a href="<? echo SiteInfo('site_url');?>"><br><? echo SiteInfo('site_name');?></a> </font></p>
</td>
</tr>
</table>
</center>
</body>
</html>