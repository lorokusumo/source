<?
session_start();
unset($_SESSION["admin_user"]);
unset($_SESSION["admin_pass"]);
echo '<meta http-equiv="refresh" content="0;url=login.php">';
?>