<?
include ("session.php");
include('../include/functions.php');
?>
<html>
<head>
<title><? echo SiteInfo('site_name');?> - exploits : vulnerabilities : videos : papers : shellcode</title>
<meta name="description" content="<? echo SiteInfo('site_name');?> exploits and 0day exploits database">
<meta name="keywords" content="exploits code, exploit code, exploits, 0-day, 0day, 0days, exploit, zero day, poc, exploit, local exploits, remote exploits, root exploits, windows, linux, new exploits, latest exploits, shellcode, Zero-day, zeroday, security articles, ezines, zines, security papers">
<link type="text/css" rel="stylesheet" href="../index_files/style.css">
<link rel="alternate" type="text/xml" title="<? echo SiteInfo('site_name');?> - RSS Feed" href="/rss.php">
<link rel="Shortcut Icon" href="../index_files/favicon.ico" type="image/x-icon">
<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
</head>
<body dir="ltr" alink="#00ff00" background="../index_files/dot.gif" bgcolor="#000000" link="#00c000" text="#008000" vlink="#00c000">
<center>
<table width="350" height="220" border="0" cellpadding="3" cellspacing="3" class="main">
  <td>
<center>
<form method="POST" action="settings.php">
<center>
	<table border="0">
		<tr>
			<td nowrap="nowrap" width="200" class="td">
				Remotes :
			</td>
			<td nowrap="nowrap" class="td" align="center">
				<b><? echo Statistics('remote'); ?></b>
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap" width="200" class="td">
				Locals :
			</td>
			<td nowrap="nowrap" class="td" align="center">
				<b><? echo Statistics('local'); ?></b>
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap" width="200" class="td">
				Webapps :
			</td>
			<td nowrap="nowrap" class="td" align="center">
				<b><? echo Statistics('webapps'); ?></b>
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap" width="200" class="td">
				Dos / poc :
			</td>
			<td nowrap="nowrap" class="td" align="center">
				<b><? echo Statistics('dos'); ?></b>
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap" width="200" class="td">
				Shellcodes :
			</td>
			<td nowrap="nowrap" class="td" align="center">
				<b><? echo Statistics('shellcode'); ?></b>
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap" width="200" class="td">
				Papers :
			</td>
			<td nowrap="nowrap" class="td" align="center">
				<b><? echo Statistics('papers'); ?></b>
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap" width="200" class="td">
				Videos :
			</td>
			<td nowrap="nowrap" class="td" align="center">
				<b><? echo Statistics('videos'); ?></b>
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap" width="200" class="td">
				Links :
			</td>
			<td nowrap="nowrap" class="td" align="center">
				<b><? echo Statistics_links(); ?></b>
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap" width="200" class="td">
				Authors :
			</td>
			<td nowrap="nowrap" class="td" align="center">
				<b><? echo Statistics_authors(); ?></b>
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap" width="200" class="td">
				Total Exploits :
			</td>
			<td nowrap="nowrap" class="td" align="center">
				<b><? echo Statistics_total(); ?></b>
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap" width="200" class="td">
				<a href="visitors.php">Visitors</a> : <em> Click to see the last 10. </em>
			</td>
			<td nowrap="nowrap" class="td" align="center">
				<b><? echo Statistics_visitors(); ?></b>
			</td>
		</tr>
	</table>
<br>
<input type="submit" value="CLOSE" onClick="javascript:window.close();">
</center>
</form>
</center>
<p><font style="FONT-SIZE: 10px; FONT-FAMILY: 'courier new'">
<br>Coded By &copy; <a href="http://iamine.com">iAm[i]nE</a> <a href="<? echo SiteInfo('site_url');?>"><br><? echo SiteInfo('site_name');?></a> </font></p>
</td>
</tr>
</table>
</center>
</body>
</html>