<?
include ("session.php");
include('../include/functions.php');
?>
<html>
<head>
<title><? echo SiteInfo('site_name');?> - exploits : vulnerabilities : videos : papers : shellcode</title>
<meta name="description" content="<? echo SiteInfo('site_name');?> exploits and 0day exploits database">
<meta name="keywords" content="exploits code, exploit code, exploits, 0-day, 0day, 0days, exploit, zero day, poc, exploit, local exploits, remote exploits, root exploits, windows, linux, new exploits, latest exploits, shellcode, Zero-day, zeroday, security articles, ezines, zines, security papers">
<link type="text/css" rel="stylesheet" href="../index_files/style.css">
<link rel="alternate" type="text/xml" title="<? echo SiteInfo('site_name');?> - RSS Feed" href="/rss.php">
<link rel="Shortcut Icon" href="../index_files/favicon.ico" type="image/x-icon">
<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
</head>
<body dir="ltr" alink="#00ff00" background="../index_files/dot.gif" bgcolor="#000000" link="#00c000" text="#008000" vlink="#00c000">
<center>
<table width="384" height="530" border="0" cellpadding="3" cellspacing="3" class="main">
  <td>
<?
if(isset($_GET['id']) && is_numeric($_GET['id'])){
$query = mysql_query("SELECT * FROM `exploits` WHERE `id`='".$_GET['id']."';");
$row = mysql_fetch_array($query);
?>
<form method="POST" action="update.php">
<center>
	<table border="0">
		<tr>
			<td nowrap="nowrap">
				DESCRIPTION:
			</td>
			<td nowrap="nowrap">
				<input type="text" name="dsc" maxlength="50" size="30" value="<? echo $row['title']; ?>"><input type="hidden" name="id" value="<? echo $_GET['id']; ?>"
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap">
				TYPE:
			</td>
			<td nowrap="nowrap">
				<select name="type">
					<option value="remote" <?if($row['type']=='remote'){echo 'selected';}?>>Remote</option>
					<option value="local" <?if($row['type']=='local'){echo 'selected';}?>>Local</option>
					<option value="webapps" <?if($row['type']=='webapps'){echo 'selected';}?>>Web apps</option>
					<option value="dos" <?if($row['type']=='dos'){echo 'selected';}?>>Dos / poc</option>
					<option value="shellcode" <?if($row['type']=='shellcode'){echo 'selected';}?>>Shellcode</option>
					<option value="papers" <?if($row['type']=='papers'){echo 'selected';}?>>Papers</option>
					<option value="videos" <?if($row['type']=='videos'){echo 'selected';}?>>Videos</option>
				</select>
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap">
				AUTHOR:
			</td>
			<td nowrap="nowrap">
				<span class="submit"> <? echo $row['author']; ?> </span>
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap">
				RELATED:
			</td>
			<td nowrap="nowrap">
				<input type="text" name="r" value="<? echo $row['r']; ?>">
			</td>
		</tr>
		<tr width="200" height="200">
			<td nowrap="nowrap">
				SOURCE:
			</td>
			<td nowrap="nowrap">
				<textarea style="width:230;height:200" name="source"><? echo $row['exploit']; ?></textarea>
			</td>
		</tr>
	</table>
<br>
<input type="submit" value="SUBMIT">  <input type="submit" value="CLOSE" onClick="javascript:window.close();">
</center>
</form>
<?
}else{
$query = mysql_query("SELECT * FROM `exploits` ORDER BY `id` DESC LIMIT 10");
?>
<center>
<b>Last 10 Exploits</b><br><br>
	<table border="0">
		<tr class="style1">
			<td class="style1">-::DATE</td>
			<td class="style1">-::DESCRIPTION</td>
			<td class="style1" width="9">-::AUTHOR</td>
			<td class="style1" width="9">-::TYPE</td>
			<td class="style1" width="9"></td>
		</tr>
<?
while ($exp_array = mysql_fetch_array($query)){
?>
		<tr class="submit">
			<td class="style1" nowrap="nowrap" width="62"><? echo $exp_array['date']; ?></td>
			<td nowrap="nowrap" width="375"><a href="../exploits.php?id=<? echo $exp_array['id']; ?>" target="_blank" class="<? if($exp_array['date'] == date("Y-m-d")){echo "style2";}else{echo "style1";}?>"><? echo $exp_array['title']; ?></a></td>
			<td nowrap="nowrap" width="80"><a href="../author.php?name=<? echo $exp_array['author']; ?>"><? echo $exp_array['author']; ?></a></td>
			<td nowrap="nowrap" width="80" align="center"><? echo $exp_array['type']; ?></a></td>
			<td nowrap="nowrap" width="9" valign="middle" align="center"><a href="edit.php?id=<? echo $exp_array['id']; ?>" onclick="if(parseInt(navigator.appVersion)>3)top.resizeTo(420,640)"><img src="img/editz.gif"></a></td>
		</tr>
<? }?>
	</table>
	<br>
<input type="submit" value="CLOSE" onClick="javascript:window.close();">
</form>
</center>
<? }?>
<p><font style="FONT-SIZE: 10px; FONT-FAMILY: 'courier new'">
<br>Coded By &copy; <a href="http://iamine.com">iAm[i]nE</a> <a href="<? echo SiteInfo('site_url');?>"><br><? echo SiteInfo('site_name');?></a> </font></p>
</td>
</tr>
</table>
</center>
</body>
</html>