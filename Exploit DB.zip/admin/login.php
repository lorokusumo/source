<?
ob_start();
include('../include/functions.php');

if($_GET['action'] == 'rest'){
$pass = rand(10000,99999);
$message = "USER :".SiteInfo('adm_usr')."\n";
$message .= "PASSWORD :".$pass."\n";
@mail(SiteInfo('adm_email'),'Your New Login Information',$message,"From: ".SiteInfo('site_name')."<".SiteInfo('adm_email').">");
@mysql_query("UPDATE `site_info` SET `adm_pwd` = '".md5($pass)."' WHERE `adm_usr`='".SiteInfo('adm_usr')."';");
echo "<script language='javascript'>alert('The new password was sent to your admin email...!');</script>";
}

$usr = htmlspecialchars(trim($_POST['usr']));
$pwd = htmlspecialchars(trim($_POST['pwd']));
if($usr && $pwd){
$login = mysql_query("SELECT * FROM `site_info` WHERE `adm_usr`='".$usr."' AND `adm_pwd`='".md5($pwd)."';");
$row = mysql_num_rows($login);

if($row == 1){
session_start();
$_SESSION["admin_user"] = $_POST['usr'];
$_SESSION["admin_pass"] = $_POST['pwd'];
}else{
$error = "<b>If You Forget Your Information Click <a href='login.php?action=rest'>HERE</a>.</b>";
}
}
?>
<html>
<head>
<title><? echo SiteInfo('site_name');?> - exploits : vulnerabilities : videos : papers : shellcode</title>
<meta name="description" content="<? echo SiteInfo('site_name');?> exploits and 0day exploits database">
<meta name="keywords" content="exploits code, exploit code, exploits, 0-day, 0day, 0days, exploit, zero day, poc, exploit, local exploits, remote exploits, root exploits, windows, linux, new exploits, latest exploits, shellcode, Zero-day, zeroday, security articles, ezines, zines, security papers">
<link type="text/css" rel="stylesheet" href="../index_files/style.css">
<link rel="alternate" type="text/xml" title="<? echo SiteInfo('site_name');?> - RSS Feed" href="/rss.php">
<link rel="Shortcut Icon" href="../index_files/favicon.ico" type="image/x-icon">
<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
</head>
<body dir="ltr" alink="#00ff00" background="../index_files/dot.gif" bgcolor="#000000" link="#00c000" text="#008000" vlink="#00c000">
<center>
<br><br><br>
<table width="668" border="0" cellpadding="3" cellspacing="3" class="main">
  <tr><td><img src="../index_files/banner.jpg" alt="milw0rm"></td></tr>
  <tr>
  <td>
<?
if(isset($_SESSION["admin_user"]) && isset($_SESSION["admin_pass"])){
echo '<br><br><br><font size="5">Welcome Back '.$_SESSION["admin_user"].'</font><br><br><br><br><br>';
echo '<meta http-equiv="refresh" content="3; url=index.php">';
}else{
?>
<br><br><br><font size="5">Admin Panel</font><br><br><br><br><br>
<form method="POST" action="login.php">
<center>
	<table border="0">
		<tr>
			<td nowrap="nowrap">
				UserName:
			</td>
			<td nowrap="nowrap">
				<input type="text" name="usr">
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap">
				Password:
			</td>
			<td nowrap="nowrap">
				<input type="password" name="pwd">
			</td>
		</tr>
	</table>
<br>
<input type="submit" value="Submit">
<br>
<?
if($error){
echo "<br><br>".$error;
}
?>
</center>
</form>
<br><br><br><br><br>
<p><font style="FONT-SIZE: 10px; FONT-FAMILY: 'courier new'">
<br>Coded By &copy; <a href="http://iamine.com">iAm[i]nE</a> <a href="<? echo SiteInfo('site_url');?>"><br><? echo SiteInfo('site_name');?></a> </font></p><br>
	</td>
	</tr>
</table>
</center>
</body>
</html>
<? } ob_end_flush(); ?>