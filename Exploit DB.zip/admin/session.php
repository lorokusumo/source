<?
session_start();
if (!session_is_registered("admin_user") && !session_is_registered("admin_pass") ){
header ("Location: login.php ");
}
?>