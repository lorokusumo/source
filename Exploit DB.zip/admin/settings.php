<?
include ("session.php");
include('../include/functions.php');

$query = mysql_query("SELECT * FROM `site_info`");
$row = mysql_fetch_array($query);

if($_GET['action'] == 'update'){
if(empty($_POST['site_name']) or empty($_POST['adm_email']) or empty($_POST['submit_email']) or empty($_POST['site_menu']) or empty($_POST['site_url'])){
echo "<script language='javascript'>alert('Please ensure that you complete all the fields fully.');</script>";
}else{
@mysql_query("UPDATE `site_info` SET `site_name` = '".$_POST['site_name']."', `adm_email` = '".$_POST['adm_email']."', `submit_email` = '".$_POST['submit_email']."', `site_menu` = '".$_POST['site_menu']."', `site_url` = '".$_POST['site_url']."' ");
echo "<script language='javascript'>alert('UPDATED Successfully.');</script>";
echo '<meta http-equiv="refresh" content="0;url=settings.php">';
}
}
?>
<html>
<head>
<title><? echo SiteInfo('site_name');?> - exploits : vulnerabilities : videos : papers : shellcode</title>
<meta name="description" content="<? echo SiteInfo('site_name');?> exploits and 0day exploits database">
<meta name="keywords" content="exploits code, exploit code, exploits, 0-day, 0day, 0days, exploit, zero day, poc, exploit, local exploits, remote exploits, root exploits, windows, linux, new exploits, latest exploits, shellcode, Zero-day, zeroday, security articles, ezines, zines, security papers">
<link type="text/css" rel="stylesheet" href="../index_files/style.css">
<link rel="alternate" type="text/xml" title="<? echo SiteInfo('site_name');?> - RSS Feed" href="/rss.php">
<link rel="Shortcut Icon" href="../index_files/favicon.ico" type="image/x-icon">
<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
</head>
<body dir="ltr" alink="#00ff00" background="../index_files/dot.gif" bgcolor="#000000" link="#00c000" text="#008000" vlink="#00c000">
<center>
<table width="384" height="530" border="0" cellpadding="3" cellspacing="3" class="main">
  <td>
<center>
<form method="POST" action="settings.php?action=update">
<center>
	<table border="0">
		<tr>
			<td nowrap="nowrap">
				SiteName:
			</td>
			<td nowrap="nowrap">
				<input type="text" name="site_name" value="<? echo $row['site_name']; ?>">
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap">
				Admin Email:
			</td>
			<td nowrap="nowrap">
				<input type="text" name="adm_email" value="<? echo $row['adm_email']; ?>">
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap">
				Submit Email:
			</td>
			<td nowrap="nowrap">
				<input type="text" name="submit_email" value="<? echo $row['submit_email']; ?>">
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap">
				Site Menu:
			</td>
			<td nowrap="nowrap" width="250" height="250">
				<textarea style="width:250px;height:250px;" name="site_menu"><? echo $row['site_menu']; ?></textarea>
			</td>
		</tr>
		<tr>
			<td nowrap="nowrap">
				Site Url:
			</td>
			<td nowrap="nowrap">
				<input type="text" maxlength="30" size="30" name="site_url" value="<? echo $row['site_url']; ?>">
			</td>
		</tr>
	</table>
<br>
<input type="submit" value="UPDATE">  <input type="submit" value="CLOSE" onClick="javascript:window.close();">
</center>
</form>
</center>
<p><font style="FONT-SIZE: 10px; FONT-FAMILY: 'courier new'">
<br>Coded By &copy; <a href="http://iamine.com">iAm[i]nE</a> <a href="<? echo SiteInfo('site_url');?>"><br><? echo SiteInfo('site_name');?></a> </font></p>
</td>
</tr>
</table>
</center>
</body>
</html>