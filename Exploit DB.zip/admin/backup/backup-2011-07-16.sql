DROP TABLE authors;

CREATE TABLE `authors` (
  `id` int(15) NOT NULL auto_increment,
  `name` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `home` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO authors VALUES("1","iAm[i]nE","ovi@hotmail.com","http://iamine.com");



DROP TABLE exploits;

CREATE TABLE `exploits` (
  `id` int(15) NOT NULL auto_increment,
  `title` varchar(50) NOT NULL,
  `exploit` text NOT NULL,
  `author` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `hits` varchar(20) NOT NULL,
  `r` varchar(50) NOT NULL,
  `type` varchar(15) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO exploits VALUES("1","Test of the script","Milw0rm Clone Script v1.0","iAm[i]nE","2011-07-01","1","iAm[i]nE","remote");
INSERT INTO exploits VALUES("2","Test of the script","Milw0rm Clone Script v1.0","iAm[i]nE","2011-07-01","1","iAm[i]nE","local");
INSERT INTO exploits VALUES("3","Test of the script","Milw0rm Clone Script v1.0","iAm[i]nE","2011-07-01","1","iAm[i]nE","webapps");
INSERT INTO exploits VALUES("4","Test of the script","Milw0rm Clone Script v1.0","iAm[i]nE","2011-07-01","1","iAm[i]nE","dos");
INSERT INTO exploits VALUES("5","Test of the script","Milw0rm Clone Script v1.0","iAm[i]nE","2011-07-01","1","iAm[i]nE","shellcode");
INSERT INTO exploits VALUES("6","Test of the script","Milw0rm Clone Script v1.0","iAm[i]nE","2011-07-01","1","iAm[i]nE","papers");
INSERT INTO exploits VALUES("7","Test of the script","Milw0rm Clone Script v1.0","iAm[i]nE","2011-07-01","2","iAm[i]nE","videos");



DROP TABLE links;

CREATE TABLE `links` (
  `id` int(15) NOT NULL auto_increment,
  `link` varchar(100) NOT NULL,
  `site` varchar(50) NOT NULL,
  `bnr` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO links VALUES("1","http://iamine.com","Coder Website","http://localhost/milw0rm/index_files/banner.jpg");



DROP TABLE site_info;

CREATE TABLE `site_info` (
  `site_url` varchar(50) NOT NULL,
  `site_name` varchar(50) NOT NULL,
  `site_menu` text NOT NULL,
  `submit_email` varchar(50) NOT NULL,
  `adm_usr` varchar(50) NOT NULL,
  `adm_pwd` varchar(32) NOT NULL,
  `adm_email` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO site_info VALUES("http://localhost/","Milw0rm Dz","<b>[ <a href=\"index.php\" target=\"_self\">Home</a> ]</b>\n<b>[ <a href=\"remotes.php\" target=\"_self\">Remotes</a> ]</b>\n<b>[ <a href=\"locals.php\" target=\"_self\">Locals</a> ]</b>\n<b>[ <a href=\"webapps.php\" target=\"_self\">Webapps</a> ]</b>\n<b>[ <a href=\"dos.php\" target=\"_self\">Dos / poc</a> ]</b>\n<b>[ <a href=\"shellcodes.php\" target=\"_self\">Shellcodes</a> ]</b>\n<b>[ <a href=\"papers.php\" target=\"_self\">Papers</a> ]</b>\n<b>[ <a href=\"videos.php\" target=\"_self\">Videos</a> ]</b>\n<b>[ <a href=\"links.php\" target=\"_self\">Links</a> ]</b>\n<b>[ <a href=\"rss.php\" target=\"_self\">RSS</a> ]</b>","admin@milw0rm-dz.com","admin","21232f297a57a5a743894a0e4a801fc3","admin@gmail.com");



