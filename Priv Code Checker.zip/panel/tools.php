<?php
require '../lib/config.php';
include 'inc/auth.php';
if(isset($_GET)){
  $id = Filter($_GET['page']);
  if($id == 'List'){
    include 'modules/listTools.php';
  } else if($id == 'Add'){
    include 'modules/addTools.php';
  } else if($id == 'Edit'){
    include 'modules/editTools.php';
  }
}