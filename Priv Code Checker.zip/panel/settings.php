<?php
require '../lib/config.php';
require 'inc/auth.php';
$xcsrf = $_SESSION['xcsrf'] = Xcsrf();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo $setting->description;?>">
    <meta name="author" content="Supian M">
    <meta name="keyword" content="<?php echo $setting->keywords;?>">
    <link rel="shortcut icon" href="<?php echo $setting->img;?>/favicon.png">
    <title><?php echo $setting->title;?> | Settings</title>
    <!-- Bootstrap core CSS -->
    <link href="<?php echo $setting->css;?>/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo $setting->css;?>/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="<?php echo $setting->assets;?>/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <!--right slidebar-->
     <link href="<?php echo $setting->css;?>/slidebars.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="<?php echo $setting->css;?>/style.css" rel="stylesheet">
    <link href="<?php echo $setting->css;?>/style-responsive.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
      <script src="<?php echo $setting->js;?>/html5shiv.js"></script>
      <script src="<?php echo $setting->js;?>/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
  <section id="container" class="">
<?php
include $_SERVER['DOCUMENT_ROOT'].'/'.dir_admin.'/inc/header.inc';
include $_SERVER['DOCUMENT_ROOT'].'/'.dir_admin.'/inc/sidebar.inc';
?>
      <!--sidebar end-->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
              <div class="row">
                  <div class="col-lg-12">
                      <!--breadcrumbs start -->
                      <ul class="breadcrumb">
                          <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
                          <li><a href="#">Admin</a></li>
                          <li class="active">Settings</li>
                      </ul>
                      <?php if($setting->maintenance == 1){ Message(4, 'Website dalam mode Maintenance'); ViewMessage();}?>
                      <!--breadcrumbs end -->
                      <?php ViewMessage();?>
                  </div>
              </div>
              <div class="row">
                  <div class="col-lg-12">
                      <!--tab nav start-->
                      <section class="panel">
                        <header class="panel-heading">
                              Main Settings
                        </header>
                        <form method="POST" action="<?php echo $setting->admin.'/action/settings.php';?>">
                        <div class="panel-body">
                          <div class="col-lg-6">
                            <div class="form-group">
                              <label>Title</label>
                              <input type="text" class="form-control" name="title" value="<?php echo $setting->title;?>">
                            </div>
                            <div class="form-group">
                              <label>Sub Title</label>
                              <input type="text" class="form-control" name="subtitle" value="<?php echo $setting->subtitle;?>">
                            </div>
                            <div class="form-group">
                              <label>Description</label>
                              <input type="text" class="form-control" name="description" value="<?php echo $setting->description;?>">
                            </div>
                            <div class="form-group">
                              <label>Keywords</label>
                              <textarea type="text" class="form-control" name="keywords"><?php echo $setting->keywords;?></textarea>
                            </div>
                            <div class="form-group">
                              <label>Contact</label>
                              <input type="text" class="form-control" name="contact" value="<?php echo $setting->contact;?>">
                            </div>
                          </div>
                          <div class="col-lg-6">
                            <div class="col-lg-6">
                              <label>Security</label>       
                              <div class="row m-bot15">
                                <div class="col-sm-12">
                                  <input type="checkbox" data-toggle="switch" name="security" id="security" value="<?php echo $setting->security;?>" <?php if($setting->security == 1){ echo 'checked'; }?>/>
                                </div>
                              </div> 
                            </div>
                            <div class="col-lg-6">
                              <label>Maintenance</label>       
                              <div class="row m-bot15">
                                <div class="col-sm-12">
                                  <input type="checkbox" data-toggle="switch" name="maintenance" <?php if($setting->maintenance == 1){ echo 'checked'; }?> />
                                </div>
                              </div>
                            </div>
                            <div class="form-group">
                              <label>reCaptcha Public Key</label>
                              <input type="text" class="form-control" name="public" id="public" value="<?php echo $setting->public_key;?>">
                            </div>
                            <div class="form-group">
                              <label>reCaptcha Private Key</label>
                              <input type="text" class="form-control" name="private" id="private" value="<?php echo $setting->private_key;?>">
                            </div>
                            <div class="form-group">
                              <label>Default Priv Coin (¢)</label>
                              <input type="text" class="form-control" name="coin" value="<?php echo $setting->balance;?>">
                            </div>
                            <div class="form-group">
                              <label>Base URL</label>
                              <input type="text" class="form-control" name="url" value="<?php echo $setting->url;?>">
                            </div>
                            <button class="btn btn-danger" id="save" name="save" value="<?php echo $xcsrf;?>">Save</button>
                          </div>
                        </div>
                        </form>
                      </section>
                  </div>
              </div>
            </section>
          </section>
      <!--main content end-->
      <!--footer start-->
      <?php SideFooter($setting, true, true);?>
      <!--footer end-->
  </section>
      <!-- js placed at the end of the document so the pages load faster -->
      <script src="<?php echo $setting->js;?>/jquery.js"></script>
      <script src="<?php echo $setting->js;?>/bootstrap.min.js"></script>
      <script src="<?php echo $setting->js;?>/jquery.scrollTo.min.js"></script>
      <script src="<?php echo $setting->js;?>/jquery.nicescroll.js" type="text/javascript"></script>

      <script src="<?php echo $setting->js;?>/jquery-ui-1.9.2.custom.min.js"></script>
      <script class="include" type="text/javascript" src="<?php echo $setting->js;?>/jquery.dcjqaccordion.2.7.js"></script>

      <!--custom switch-->
      <script src="<?php echo $setting->js;?>/bootstrap-switch.js"></script>
      <!--custom tagsinput-->
      <script src="<?php echo $setting->js;?>/jquery.tagsinput.js"></script>
      <!--custom checkbox & radio-->
      <script type="text/javascript" src="<?php echo $setting->js;?>/ga.js"></script>
      <script src="<?php echo $setting->js;?>/respond.min.js" ></script>
      <!--right slidebar-->
      <script src="<?php echo $setting->js;?>/slidebars.min.js"></script>
      <!--common script for all pages-->
      <script src="<?php echo $setting->js;?>/common-scripts.js"></script>
      <!--script for this page only-->
      <script src="<?php echo $setting->js;?>/form-component.js"></script>
      <script type="text/javascript">
        $(document).ready(function() {
          if($("#security:checked").val()){
            $('#private,#public').attr('disabled', false);
          } else {
            $('#private,#public').attr('disabled', true);
          }
          $("#security").change(function() { 
            if($('#security').is(':checked')) {
              $('#private,#public').attr('disabled', false);
              $("#security").val('1');
            } else {
              $('#private,#public').attr('disabled', true);
              $("#security").val('0')
            }
        })
      });
      </script>
  </body>
</html>