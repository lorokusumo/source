<?php
require '../lib/config.php';
require 'inc/auth.php';?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="<?php echo $setting->charset;?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo $setting->description;?>/">
    <meta name="author" content="M-Supian.ID">
    <meta name="keyword" content="<?php echo $setting->keywords;?>/">
    <link rel="shortcut icon" href="<?php echo $setting->img;?>/favicon.png">
    <title><?php echo $setting->title;?> | File Manager</title>
    <!-- Bootstrap core CSS -->
    <link href="<?php echo $setting->css;?>/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo $setting->css;?>/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="<?php echo $setting->assets;?>/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <!--right slidebar-->
    <link href="<?php echo $setting->css;?>/slidebars.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="<?php echo $setting->css;?>/style.css" rel="stylesheet">
    <link href="<?php echo $setting->css;?>/style-responsive.css" rel="stylesheet" />
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
      <script src="<?php echo $setting->js;?>/html5shiv.js"></script>
      <script src="<?php echo $setting->js;?>/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
  <section id="container" class="">
      <?php include'inc/header.inc';?>
      <?php include'inc/sidebar.inc';?>
      <section id="main-content">
          <section class="wrapper">
              <!-- page start-->
            <div class="row">
                <div class="col-lg-12">
                  <section class="panel">
                    <header class="panel-heading">
                      File Manager
                    </header>
                    <div class="panel-body">
                        <iframe src="plugin/elfinder/index.php" class="filemanager"></iframe>
                    </div>
                  </section>
                </div>
              </div>
          </section>
      </section>
  <?php SideFooter($setting,true,true);?>
  </section>
    <!-- js placed at the end of the document so the pages load faster -->
    <script src="<?php echo $setting->js;?>/jquery.js"></script>
    <script src="<?php echo $setting->js;?>/jquery-ui-1.9.2.custom.min.js"></script>
    <script src="<?php echo $setting->js;?>/jquery-migrate-1.2.1.min.js"></script>
    <script src="<?php echo $setting->js;?>/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="<?php echo $setting->js;?>/jquery.dcjqaccordion.2.7.js"></script>
    <script src="<?php echo $setting->js;?>/jquery.scrollTo.min.js"></script>
    <script src="<?php echo $setting->js;?>/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="<?php echo $setting->js;?>/respond.min.js" ></script>
    <!--right slidebar-->
    <script src="<?php echo $setting->js;?>/slidebars.min.js"></script>
    <!--common script for all pages-->
    <script src="<?php echo $setting->js;?>/common-scripts.js"></script>
  </body>
</html>