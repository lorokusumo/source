<?php
require '../../lib/config.php';
require '../inc/auth.php';
if(isset($_POST['save'])){
	$xcsrf = Filter($_POST['save']);
	if($_SESSION['xcsrf'] != $xcsrf || empty($_SESSION['xcsrf'])) {
		unset($_SESSION['xcsrf']);
		session_destroy();
		session_start();
		Message(3, 'Alasan keamanan');
		Redirect($setting->url.'/signin.html');
	} else {
		$title = Filter($_POST['title']);
		$sub   = Filter($_POST['subtitle']);
		$desc  = Filter($_POST['description']);
		$word  = Filter($_POST['keywords']);
		$contact = Filter($_POST['contact']);
		$coin = Filter($_POST['coin']);
		$url = Filter($_POST['url']);
		
		if(isset($_POST['maintenance'])){
			$maintenance = 1;
		} else {
			$maintenance = 0;
		}

		if(isset($_POST['security'])){
			$security = 1;
			$public = Filter($_POST['public']);
			$priv = Filter($_POST['private']);
			$a = $db->go("UPDATE `settings` SET `title` = '$title',`subtitle`= '$sub', `description` = '$desc', `keywords` = '$word',`default_balance`= '$coin', `security` = '$security', `captcha_public_key` = '$public',`captcha_private_key`= '$priv', `maintenance` = '$maintenance', `base_url`= '$url', `contact` = '$contact'");
		} else {
			$security = 0;
			$a = $db->go("UPDATE `settings` SET `title` = '$title',`subtitle`= '$sub', `description` = '$desc', `keywords` = '$word',`default_balance`= '$coin', `security` = '$security', `maintenance` = '$maintenance', `base_url`= '$url', `contact` = '$contact'");
		}
		if($a){
			Message(1, 'Pengaturan berhasil dirubah');
		} else {
			Message(4, 'Pengaturan gagal dirubah');
		}
	}
}
Redirect($setting->admin.'/settings.html');
