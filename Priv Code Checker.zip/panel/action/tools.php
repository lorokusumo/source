<?php

require'../../lib/config.php';
include '../inc/auth.php';

if(isset($_GET['delete'])){
  if($_GET['delete'] == 1){
    $xcsrf = Filter($_GET['xcsrf']);
    if($_SESSION['xcsrf'] != $xcsrf || empty($_SESSION['xcsrf'])) {
      unset($_SESSION['xcsrf']);
      session_destroy();
      session_start();
      Message(3, 'Alasan keamanan');
      Redirect($setting->url.'/signin.html');
    } else {
     $id = Filter($_GET['id']);
     $db->go("SELECT `title` FROM `tools` WHERE `id` = '$id'");
     $row = $db->fetchArray();
     if($db->numRows() == 0){
      Message(2, 'Tools tidak ditemukan');
     } else {
        $title = $row['title'];
        $query = $db->go("DELETE FROM `tools` WHERE `id` = '$id'");
        if($query){
          Message(1, $title.' berhasil dihapus');
        } else {
          Message(3, 'Gagal menghapus');
        }
      }
    }
  } else {
    Message(2, 'Kesalahan fungsi delete');
  }
  Redirect($setting->admin.'/tools.html');
}

if(isset($_GET['status'])){
    $xcsrf = Filter($_GET['xcsrf']);
    if($_SESSION['xcsrf'] != $xcsrf || empty($_SESSION['xcsrf'])) {
      unset($_SESSION['xcsrf']);
      session_destroy();
      session_start();
      Message(3, 'Alasan keamanan');
      Redirect($setting->url.'/signin.html');
    } else {
      $id = Filter($_GET['id']);
      $status = Filter($_GET['status']);
      $db->go("SELECT `title` FROM `tools` WHERE `id` = '$id'");
      $row = $db->fetchArray();
      if($db->numRows() == 0){
        Message(3, 'Tools tidak ditemukan');
      } else {   
        $query = $db->go("UPDATE `tools` SET `status` = '$status' WHERE `id` = '$id'");
        if($query){
          Message(1, $row['title'].' berhasil dirubah');
        } else {
          Message(4, 'Gagal merubah');
        }
        Redirect($setting->admin.'/tools.html');
      }
   }
}

if (isset($_POST['add'])) {
    $title = Filter($_POST['title']);
    $desc = Filter($_POST['description']);
    $categ = Filter($_POST['category']);
    $url = Filter($_POST['url']);
    $succ = Filter($_POST['success']);
    $fail = Filter($_POST['failed']);
    $date = DateTime();
    $query = $db->go("INSERT INTO `tools`(`id`, `title`, `description`, `type`,`url`, `cost_success`, `cost_failed`, `date_`) VALUES (NULL, '$title', '$desc', '$categ', '$url', '$succ', '$fail', '$date')");
    if ($query) {
        Message(1, $title.' berhasil ditambahkan');
    } else {
        Message(4, 'Gagal menambahkan');
    }
    Redirect($setting->admin.'/tools/add.html');
}

if (isset($_POST['edit'])) {
    $id = Filter($_POST['id']);
    $title = Filter($_POST['title']);
    $desc = Filter($_POST['description']);
    $categ = Filter($_POST['category']);
    $url = Filter($_POST['url']);
    $succ = Filter($_POST['success']);
    $fail = Filter($_POST['failed']);
    $date = DateTime();
    $query = $db->go("UPDATE `tools` SET `title` = '$title', `description` = '$desc', `type` = '$categ',`url` =  '$url', `cost_success` = '$succ', `cost_failed` = '$fail', `date_` = '$date' WHERE `id` = '$id'");
    if ($query) {
        Message(1, $title.' berhasil dirubah');
    } else {
        Message(4, 'Gagal merubah');
    }
    Redirect($setting->admin.'/tools.html');
}
