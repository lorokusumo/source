<?php
require '../../lib/config.php';
include '../inc/auth.php';
if(isset($_POST)){
	$priv = Filter($_POST['coin']);
	$jum = $_POST['amount'];
	if($jum == 0 || $jum == ''){
		$jum = 1;
	}

	for ($i=1; $i < $jum+1; $i++) { 
		$code = ICode();
		$date = DateTime();
		$a = Random(1);
		$b = Random(1);
		$c = rand(1,9);		
		if($priv == 0 || $priv == '') {
			$coin = (int)($a+($b.$c));
		} else {
			$coin = $priv;
		}
		$q = $db->go("INSERT INTO `giftcodes`(`id`, `code`, `coin`, `status`, `usedby`, `date_`) VALUES (NULL,'$code','$coin','1','None','$date') ");
		if($i == $jum && $q){
			Message(1, 'Sukses');
		}
	}
}
Redirect($setting->admin.'/gcode.html');