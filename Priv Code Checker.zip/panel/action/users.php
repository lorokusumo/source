<?php
require '../../lib/config.php';
require '../inc/auth.php';

if(isset($_GET)) {
	$xcsrf = Filter($_GET['xcsrf']);
	$uname = StrToLower(Filter($_GET['uname']));
	if($_SESSION['xcsrf'] != $xcsrf || empty($_SESSION['xcsrf'])) {
		unset($_SESSION['xcsrf']);
		session_destroy();
		session_start();
		Message(3, 'Alasan keamanan');
		Redirect($setting->url.'/signin.html');
	} else {
		if(isset($_GET['banned'])){
			// Fungsi banned
			if($_GET['banned'] == 1) {
				$db->go("UPDATE `users` SET `suspend` = '1' WHERE username = '$uname'");
				Message(1, 'Akun '.ucwords($uname).' berhasil disuspend.');
			} else if($_GET['banned'] == 0) {
				$db->go("UPDATE `users` SET `suspend` = '0' WHERE username = '$uname'");
				Message(1, 'Akun '.ucwords($uname).' berhasil diaktifkan.');
			} else {
				Message(4, 'Kesalahan fungsi Suspend.');
			}
		} else if(isset($_GET['resspw'])) {
			if($_GET['resspw'] == 1){
				$pass = 'PrivCode-'.Random(5);
				$newpw = Encrypt($uname, $pass);
				$db->go("UPDATE `users` SET `password` = '$newpw' WHERE username = '$uname'");
				Message(1, 'Password akun '.ucwords($uname).' berhasil dirubah. Password baru : "'.$pass.'".');
			} else {
				Message(4, 'Kesalahan fungsi Reset Password.');
			}
		} else if(isset($_GET['delete'])) {
			if($_GET['delete'] == 1) {
				$db->go("DELETE FROM `users` WHERE `username` = '$uname'");
				Message(1, 'Akun '.ucwords($uname).' berhasil dihapus.');
			} else {
				Message(4, 'Kesalahan fungsi Delete Account.');
			}
		}
	}
}
Redirect($setting->admin.'/users.html');