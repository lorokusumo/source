<?php
require '../../lib/config.php';
include '../inc/auth.php';


if(isset($_POST)) {
	$user   = Filter($_POST['user']);
	$amount = Filter($_POST['amount']);
	$db->go("SELECT `username` FROM `users` WHERE `username` = '$user' OR `email` = '$user'");
	if($db->numRows() == True) {
		$now = DateTime();
		$db->go("UPDATE `users` SET `priv_coin` = `priv_coin` + '$amount' WHERE `username` = '$user' OR `email` = '$user'");
		$db->go("INSERT INTO `topup_history` (`id`, `to_uname`, `from_uname`, `amount`, `date_`) VALUES (NULL, '$user', 'System', '$amount', '$now')");
		Message(1, 'Topup Priv Coin sebesar '.$amount.' &#162; kepada '.ucwords($user).' berhasil dilakukan.');
		Redirect($setting->admin."/topup.html");
	} else {
		Message(3, $user. ' tidak terdaftar pada sistem.');
		Redirect($setting->admin."/topup.html");
	}
} else {
	Redirect($setting->admin."/topup.html");
}
