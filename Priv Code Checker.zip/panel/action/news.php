<?php
require '../../lib/config.php';
require '../inc/auth.php';

if(isset($_POST['add'])) {
	$xcsrf = Filter($_POST['xcsrf']);
	if($_SESSION['xcsrf'] != $xcsrf || empty($_SESSION['xcsrf'])) {
		unset($_SESSION['xcsrf']);
		session_destroy();
		session_start();
		Message(3, 'Alasan keamanan');
		Redirect($setting->url.'/signin.html');
	} else {
		$title = Filter($_POST['title']);
		$content = $_POST['content'];
		$date = DateTime();
		if($db->go("INSERT INTO `news`(`id`, `writer`, `title`, `content`, `published`, `date_`) VALUES (NULL, '$username', '$title', '$content', '1', '$date')")){
			Message(1, 'Berita berhasil ditambahkan.');
		} else {
			Message(3, 'Gagal');
		}
		Redirect($setting->admin.'/news.html');
	}
}


if(isset($_GET['delete'])){
	$xcsrf = $_GET['xcsrf'];
	$id = (int)Filter($_GET['id']);
	if($_SESSION['xcsrf'] != $xcsrf || empty($_SESSION['xcsrf'])) {
		unset($_SESSION['xcsrf']);
		session_destroy();
		session_start();
		Message(3, 'Alasan keamanan'.$xcsrf);
		Redirect($setting->admin.'/news.html');
		Redirect($setting->url.'/signin.html');
		exit();
	} else {
		$db->go("SELECT `title` FROM `news` WHERE `id` = '$id'");
		$row = $db->fetchArray();
		if($db->go("DELETE FROM `news` WHERE `id` = '$id'")){
			Message(1, $row['title'].' berita berhasil dihapus.');
		} else {
			Message(3, 'Gagal');
		}
	}
	Redirect($setting->admin.'/news.html');
}

if(isset($_GET['published'])){
	$xcsrf = $_GET['xcsrf'];
	$id = Filter($_GET['id']);
	if($_SESSION['xcsrf'] != $xcsrf || empty($_SESSION['xcsrf'])) {
		unset($_SESSION['xcsrf']);
		session_destroy();
		session_start();
		Message(3, 'Alasan keamanan'.$xcsrf);
		Redirect($setting->admin.'/news.html');
		Redirect($setting->url.'/signin.html');
		exit();
	} else {
		if($_GET['published'] == 'No'){
			$db->go("SELECT `title` FROM `news` WHERE `id` = '$id' ");
			$row = $db->fetchArray();
			if($db->go("UPDATE `news` SET `published` = '0' WHERE `id` = '$id' ")){
				Message(1, $row['title'].' berita berhasil disimpan di draft');
			} else {
				Message(3, 'Gagal');
			}
		} else if($_GET['published'] == 'Yes'){
			$db->go("SELECT `title` FROM `news` WHERE `id` = '$id' ");
			$row = $db->fetchArray();
			if($db->go("UPDATE `news` SET `published` = '1' WHERE `id` = '$id' ")){
				Message(1, $row['title'].' berita berhasil disimpan di publikasikan');
			} else {
				Message(3, 'Gagal');
			}
		}
	}
	Redirect($setting->admin.'/news.html');
}
