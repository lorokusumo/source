<?php
require '../../lib/config.php';
require '../inc/auth.php';

if(isset($_GET)) {
	$xcsrf = Filter($_GET['xcsrf']);
	$invoice = Filter($_GET['inv']);
	if($_SESSION['xcsrf'] != $xcsrf || empty($_SESSION['xcsrf'])) {
		unset($_SESSION['xcsrf']);
		session_destroy();
		session_start();
		Message(3, 'Alasan keamanan');
		Redirect($setting->url.'/signin.html');
	} else {
		if(isset($_GET['verf']) && isset($_GET['inv'])){
			// Fungsi banned
			// http://localhost/panel/action/invoice.php?verf=0&inv36731&xcsrf=f961c6c7d64dacf973847c04ba668776
			if($_GET['verf'] == 0) {
				$db->go("SELECT `username`, `count`, `pending` FROM `orders` WHERE `invoice` = '$invoice'");
				$row = $db->fetchArray();
				if($db->numRows() == 0){
					Message(3, 'Invoice nomor #'.$invoice.' tidak ditemukan.');
				} else if($row['pending'] == 0) {
					Message(2, 'Invoice nomor #'.$invoice.' sudah diverifikasi.');
				} else {
					$coin = $row['count'];
					$user = $row['username'];
					if(isset($_GET['ic'])){
					  for ($i=0; $i < $coin ; $i++) { 
					  	$icode = ICode();
						$date = DateTime();
						$db->go("INSERT INTO `invitecodes`(`id`, `code`, `createdby`, `usedby`, `type`, `status`, `date_`) VALUES (NULL,'$icode','$user','None','Reguler','1','$date')");
					  }
					}
					$db->go("UPDATE `orders` SET `pending` = '0' WHERE `invoice` = '$invoice'");
					$db->go("UPDATE `users` SET `priv_coin` = `priv_coin` + '$coin' WHERE `username` = '$user'");
					Message(1, 'Invoice nomor #'.$invoice.' berhasil diverifikasi.');
				}
			} else {
				Message(4, 'Kesalahan fungsi invoice.');
			}
		}
	}
}
Redirect($setting->admin.'/invoice.html');