<?php
$username = $_SESSION['username'];
if(empty($username)) {
	Redirect($setting->url.'/signin.html');
} else {
	$db->go("SELECT `suspend`, `level` FROM `users` WHERE `username` = '$username'");
	$row = $db->fetchArray();
	if($row['suspend'] == 1) {
		Redirect($setting->url.'/logout.html');
	} else if($row['level'] != 'Admin') {
    	Redirect($setting->url.'/logout.html');
  }
}
