<?php require '../lib/config.php'; require 'inc/auth.php';?>
<!DOCTYPE html>
<html lang="en">
	<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo $setting->description;?>">
    <meta name="author" content="Supian M">
    <meta name="keyword" content="<?php echo $setting->keywords;?>">
    <link rel="shortcut icon" href="<?php echo $setting->img;?>/favicon.png">
    <title><?php echo $setting->title;?> | Gift Code</title>
    <link href="<?php echo $setting->css;?>/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo $setting->css;?>/bootstrap-reset.css" rel="stylesheet">
    <link href="<?php echo $setting->assets;?>/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="<?php echo $setting->assets;?>/advanced-datatable/media/css/demo_page.css" rel="stylesheet" />
    <link href="<?php echo $setting->assets;?>/advanced-datatable/media/css/demo_table.css" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo $setting->assets;?>/data-tables/DT_bootstrap.css" />
    <link href="<?php echo $setting->css;?>/slidebars.css" rel="stylesheet">
    <link href="<?php echo $setting->css;?>/style.css" rel="stylesheet">
    <link href="<?php echo $setting->css;?>/style-responsive.css" rel="stylesheet" />
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
      <script src="<?php echo $setting->js;?>/html5shiv.js"></script>
      <script src="<?php echo $setting->js;?>/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
	  <section id="container" class="">
		<?php
			include $_SERVER['DOCUMENT_ROOT'].'/'.dir_admin.'/inc/header.inc';
			include $_SERVER['DOCUMENT_ROOT'].'/'.dir_admin.'/inc/sidebar.inc';
		?>
      <section id="main-content">
        <section class="wrapper">
            <div class="row">
              <div class="col-lg-12">
             <?php ViewMessage(); ?>
            </div>
            <div class="col-sm-12">
              <section class="panel">
                <header class="panel-heading">
                  Generate
                  <span class="tools pull-right">
                    <a href="javascript:;" class="fa fa-chevron-down"></a>
                    <a href="javascript:;" class="fa fa-times"></a>
                  </span>
                </header>
                <form action="<?php echo $setting->admin.'/action/giftcode.php';?>" method="post">
                <div class="panel-body">
                  <div class="form-group">
                    <div class="col-sm-6">
                      <label>Coin</label>
                      <input type="text" name="coin" class="form-control" value="50">
                    </div>
                    <div class="col-sm-6">
                      <label>Amount</label>
                      <input type="text" name="amount" class="form-control" value="1">
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-6">
                      <br>
                      <button class="btn btn-danger">Create</button>
                    </div>
                  </div>
                </div>
                </form>
              </section>
            </div>
              <div class="col-sm-12">
            <section class="panel">
            	<header class="panel-heading">
                List
            		<span class="tools pull-right">
              		<a href="javascript:;" class="fa fa-chevron-down"></a>
              		<a href="javascript:;" class="fa fa-times"></a>
            		</span>
            	</header>
              	<div class="panel-body">
              		<div class="adv-table">
              			<table class="display table table-striped table-bordered" id="dynamic-table">
              				<thead>
              					<tr>
                  				<th width="20%" style="text-align:center;">Code</th>
                  				<th width="15%" style="text-align:center;">Coin</th>
                          <th width="15%" style="text-align:center;">Status</th>
                          <th width="25%" style="text-align:center;">Used By</th>
                  				<th width="25%" style="text-align:center;">Date</th>
                  			</tr>
              				</thead>
              				<tbody>
              			<?php
                      $db->go("SELECT `id`, `code`, `coin`, `status`, `usedby`, `date_` FROM `giftcodes`");
                      while ($row = $db->fetchArray()) {
                        $code   = $row['code'];
                        $coin   = $row['coin'];
                        $status = $row['status'];
                        $usedby = $row['usedby'];
                        $date   = $row['date_'];
                        
                        if($status == 0){
                          $status = '<font style="color:red">Used</font>';
                          $code = '<font style="color:red"><s>'.$code.'</s></font>';
                        } else {
                          $status = '<font style="color:green">Available</font>';
                        }

            				?>
              				<tr>
                  			<td style="text-align:center;"><?php echo $code;?></td>
                  			<td style="text-align:center;"><?php echo '+ '.$coin.' ¢';?></td>
                  			<td style="text-align:center;"><?php echo $status;?></td>
                        <td style="text-align:center;"><?php echo $usedby;?></td>
                        <td style="text-align:center;"><?php echo $date;?></td>
              				</tr>
              				<?php }?>
              			</tbody>
              		</table>
	              </div>
              </div>
            </section>
          </div>
        </div>
      </section>
    </section>
    <?php SideFooter(true, true);?>
  </section>
    <script src="<?php echo $setting->js;?>/jquery.js"></script>
    <script src="<?php echo $setting->js;?>/jquery-ui-1.9.2.custom.min.js"></script>
    <script src="<?php echo $setting->js;?>/jquery-migrate-1.2.1.min.js"></script>
    <script src="<?php echo $setting->js;?>/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="<?php echo $setting->js;?>/jquery.dcjqaccordion.2.7.js"></script>
    <script src="<?php echo $setting->js;?>/jquery.scrollTo.min.js"></script>
    <script src="<?php echo $setting->js;?>/jquery.nicescroll.js" type="text/javascript"></script>
    <script type="text/javascript" language="javascript" src="<?php echo $setting->assets;?>/advanced-datatable/media/js/jquery.dataTables.js"></script>
    <script type="text/javascript" src="<?php echo $setting->assets;?>/data-tables/DT_bootstrap.js"></script>
    <script src="<?php echo $setting->js;?>/respond.min.js" ></script>
    <script src="<?php echo $setting->js;?>/slidebars.min.js"></script>
    <script src="<?php echo $setting->js;?>/dynamic_table_init.js"></script>
    <script src="<?php echo $setting->js;?>/common-scripts.js"></script>
  </body>
</html>