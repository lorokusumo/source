<?php
require '../lib/config.php';
require 'inc/auth.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo $setting->description;?>">
    <meta name="author" content="Supian M">
    <meta name="keyword" content="<?php echo $setting->keywords;?>">
    <link rel="shortcut icon" href="<?php echo $setting->img;?>/favicon.png">
    <title><?php echo $setting->title;?> | Users</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo $setting->css;?>/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo $setting->css;?>/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="<?php echo $setting->assets;?>/font-awesome/css/font-awesome.css" rel="stylesheet" />

    <!--dynamic table-->
    <link href="<?php echo $setting->assets;?>/advanced-datatable/media/css/demo_page.css" rel="stylesheet" />
    <link href="<?php echo $setting->assets;?>/advanced-datatable/media/css/demo_table.css" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo $setting->assets;?>/data-tables/DT_bootstrap.css" />
      <!--right slidebar-->
      <link href="<?php echo $setting->css;?>/slidebars.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="<?php echo $setting->css;?>/style.css" rel="stylesheet">
    <link href="<?php echo $setting->css;?>/style-responsive.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
      <script src="<?php echo $setting->js;?>/html5shiv.js"></script>
      <script src="<?php echo $setting->js;?>/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

  <section id="container" class="">
      <!--header start-->
<?php
include $_SERVER['DOCUMENT_ROOT'].'/'.dir_admin.'/inc/header.inc';
include $_SERVER['DOCUMENT_ROOT'].'/'.dir_admin.'/inc/sidebar.inc';
?>
      <!--sidebar end-->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
              <!-- page start-->
              <div class="row">
                <div class="col-sm-12">
                <?php ViewMessage();?>
              <section class="panel">
              <header class="panel-heading">
                  Users
             <span class="tools pull-right">
                <a href="javascript:;" class="fa fa-chevron-down"></a>
                <a href="javascript:;" class="fa fa-times"></a>
             </span>
              </header>
              <div class="panel-body">
              <div class="adv-table">
              <table class="display table table-striped table-bordered" id="dynamic-table">
              <thead>
              <tr>
                  <th width="20.6666666667%">Name</th>
                  <th width="17.6666666667%">Username</th>
                  <th width="19.6666666667%">E-Mail</th>
                  <th width="9.6666666667%">Coin</th>
                  <th width="11.6666666667%">Status</th>
                  <th width="19.6666666667%">Action</th>
              </tr>
              </thead>
              <tbody>
              <?php
                $xcsrf = $_SESSION['xcsrf'] = Xcsrf();
                $db->go("SELECT `name`, `username`, `email`, `level`, `suspend`, `priv_coin` FROM `users` WHERE `level` != 'Admin'");
                $count = $db->numRows();
                $no = 0;
                while ($row = $db->fetchArray()){
                  $name  = $row['name'];
                  $uname = $row['username'];
                  $email = $row['email'];
                  $level = $row['level'];
                  $coin  = $row['priv_coin'];
                  $suspend = $row['suspend'];
                  if($suspend == 0){
                    $status = '<i style="color:#4E9A06;" class="fa fa-check" title="Active"></i> Active';
                    $act = '<a href="'.$setting->admin.'/action/users.php?banned=1&uname='.$uname.'&xcsrf='.$xcsrf.'" class="btn btn-warning btn-xs">Suspend</a>  <a href="'.$setting->admin.'/action/users.php?resspw=1&uname='.$uname.'&xcsrf='.$xcsrf.'" class="btn btn-info btn-xs">Change Password</a>'; 
                  } else {
                    $status = '<i style="color:#EF2929;" class="fa fa-times" title="Suspended"></i> Suspended';  
                    $act = '<a href="'.$setting->admin.'/action/users.php?banned=0&uname='.$uname.'&xcsrf='.$xcsrf.'" class="btn btn-warning btn-xs">Activate</a>  <a href="'.$setting->admin.'/action/users.php?delete=1&uname='.$uname.'&xcsrf='.$xcsrf.'" class="btn btn-danger btn-xs">Delete</a>';   
                  }
              ?>
              <tr>
                  <td><?php echo $name;?></td>
                  <td><?php echo ucwords($uname);?></td>
                  <td><a href="mailto:<?php echo $email;?>" target="_blank"><?php echo $email;?></a></td>
                  <td><div id="coin<?php echo $no;?>"><?php echo $coin;?></div></td>
                  <td><?php echo $status;?></td>
                  <td><?php echo $act;?></td>
              </tr>
              <?php $no++; }?>
              </tbody>
              </table>

              </div>
              </div>
              </section>
              </div>
              </div>
              <!-- page end-->
          </section>
      </section>
      <!--main content end-->
      <?php SideFooter($setting, true, true);?>
            <!--footer end-->
  </section>

    <!-- js placed at the end of the document so the pages load faster -->

    <script src="<?php echo $setting->js;?>/jquery.js"></script>
    <script src="<?php echo $setting->js;?>/jquery-ui-1.9.2.custom.min.js"></script>
    <script src="<?php echo $setting->js;?>/jquery-migrate-1.2.1.min.js"></script>
    <script src="<?php echo $setting->js;?>/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="<?php echo $setting->js;?>/jquery.dcjqaccordion.2.7.js"></script>
    <script src="<?php echo $setting->js;?>/jquery.scrollTo.min.js"></script>
    <script src="<?php echo $setting->js;?>/jquery.nicescroll.js" type="text/javascript"></script>
    <script type="text/javascript" language="javascript" src="<?php echo $setting->assets;?>/advanced-datatable/media/js/jquery.dataTables.js"></script>
    <script type="text/javascript" src="<?php echo $setting->assets;?>/data-tables/DT_bootstrap.js"></script>
    <script src="<?php echo $setting->js;?>/respond.min.js" ></script>
    <!--right slidebar-->
    <script src="<?php echo $setting->js;?>/slidebars.min.js"></script>
    <!--dynamic table initialization -->
    <script src="<?php echo $setting->js;?>/dynamic_table_init.js"></script>
    <!--common script for all pages-->
    <script src="<?php echo $setting->js;?>/common-scripts.js"></script>
        <script type="text/javascript">
      $(document).ready(function(){
        for (var i = 0; i < <?php echo $count;?>; i++) {
          $("#coin"+i).html(toRp(($('#coin'+i).html())));
        }     
      });
      function toRp(angka){
      var rev     = parseInt(angka, 10).toString().split('').reverse().join('');
      var rev2    = '';
      for(var i = 0; i < rev.length; i++){
        rev2  += rev[i];
        if((i + 1) % 3 === 0 && i !== (rev.length - 1)){
            rev2 += '.';
        }
      }
      return rev2.split('').reverse().join('') + ' &#162;';
    }

    </script>


  </body>
</html>
