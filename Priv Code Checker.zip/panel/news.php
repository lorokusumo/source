<?php
require '../lib/config.php';
include 'inc/auth.php';
if(isset($_GET)){
  $id = Filter($_GET['page']);
  if($id == 'List'){
    include 'modules/listNews.php';
  } else if($id == 'Add'){
    include 'modules/addNews.php';
  } else if($id == 'Edit'){
    include 'modules/editNews.php';
  }
}