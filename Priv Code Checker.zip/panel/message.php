<?php
require '../lib/config.php';
include 'inc/auth.php';
if(isset($_GET)){
  $id = Filter($_GET['page']);
  if($id == 'List'){
    include 'modules/listMessage.php';
  } else if($id == 'Add'){
    include 'modules/addMessage.php';
  } else if($id == 'Edit'){
    include 'modules/editMessage.php';
  }
}