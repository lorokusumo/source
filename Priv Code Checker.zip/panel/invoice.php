<?php
require '../lib/config.php';
require 'inc/auth.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo $setting->description;?>">
    <meta name="author" content="Supian M">
    <meta name="keyword" content="<?php echo $setting->keywords;?>">
    <link rel="shortcut icon" href="<?php echo $setting->img;?>/favicon.png">
    <title><?php echo $setting->title;?> | Invoice</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo $setting->css;?>/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo $setting->css;?>/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="<?php echo $setting->assets;?>/font-awesome/css/font-awesome.css" rel="stylesheet" />

    <!--dynamic table-->
    <link href="<?php echo $setting->assets;?>/advanced-datatable/media/css/demo_page.css" rel="stylesheet" />
    <link href="<?php echo $setting->assets;?>/advanced-datatable/media/css/demo_table.css" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo $setting->assets;?>/data-tables/DT_bootstrap.css" />
      <!--right slidebar-->
      <link href="<?php echo $setting->css;?>/slidebars.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="<?php echo $setting->css;?>/style.css" rel="stylesheet">
    <link href="<?php echo $setting->css;?>/style-responsive.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
      <script src="<?php echo $setting->js;?>/html5shiv.js"></script>
      <script src="<?php echo $setting->js;?>/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

  <section id="container" class="">
      <!--header start-->
<?php
include $_SERVER['DOCUMENT_ROOT'].'/'.dir_admin.'/inc/header.inc';
include $_SERVER['DOCUMENT_ROOT'].'/'.dir_admin.'/inc/sidebar.inc';
?>
      <!--sidebar end-->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
              <!-- page start-->
              <div class="row">
                <div class="col-sm-12">
                <?php ViewMessage();?>
              <section class="panel">
              <header class="panel-heading">
                  Invoice History
             <span class="tools pull-right">
                <a href="javascript:;" class="fa fa-chevron-down"></a>
                <a href="javascript:;" class="fa fa-times"></a>
             </span>
              </header>
              <div class="panel-body">
              <div class="adv-table">
              <table class="display table table-striped table-bordered" id="dynamic-table">
              <thead>
              <tr>
                  <th width="9.5%">Invoice</th>
                  <th width="12.5%">Username</th>
                  <th width="9.5%">Item</th>
                  <th width="10%">Quantity</th>
                  <th width="12%">Cost</th>
                  <th width="10.5%">Payment</th>
                  <th width="10.5%">Status</th>
                  <th width="14.5%">Date</th>
                  <th width="10%">Action</th>
              </tr>
              </thead>
              <tbody>
              <?php
                $xcsrf = $_SESSION['xcsrf'] = Xcsrf();
                $db->go("SELECT  `username`, `item`, `count`, `cost`, `payment`, `invoice`, `pending`, `date_` FROM `orders` WHERE `pending` = '1' ORDER BY date_");
                $no = 0;
                $abc = $db->numRows();
                while ($row = $db->fetchArray()){
                  $invoice = $row['invoice'];
                  $inv = '<a href="'.$setting->url.'/invoice/'.$invoice.'.html" target="_blank">#'.$invoice.'</a>';
                  $type = $row['item'];
                  $uname = $row['username'];
                  if($type == 'Priv Coin'){
                    $qty = $row['count'].' &#162;';  
                  } else {
                    $qty = $row['count'];
                  }
                  $payment = $row['payment'];
                  $date = $row['date_'];//substr($row['date_'],9,20);
                  $cost = $row['cost'];
                  if($row['pending'] == 0){
                    $act = '<a href="#" class="btn btn-danger btn-xs"><i class="fa fa-check"></i> No Action</a>';
                    $status = '<i style="color:#4E9A06;" class="fa fa-check" title="Verified"></i> Verified';
                  } else {
                    $status = '<i style="color:#EF2929;" class="fa fa-times" title="Pending"></i> Pending';    
                    if($type == 'Invite Code') {
                      $act = '<a href="'.$setting->admin.'/action/invoice.php?verf=0&ic=1&inv='.$invoice.'&xcsrf='.$xcsrf.'" class="btn btn-info btn-xs" onclick="konf('.$invoice.');"><i class="fa fa-check"></i> Verification</a>';
                    } else {
                      $act = '<a href="'.$setting->admin.'/action/invoice.php?verf=0&inv='.$invoice.'&xcsrf='.$xcsrf.'" class="btn btn-info btn-xs" onclick="konf('.$invoice.');"><i class="fa fa-check"></i> Verification</a>';
                    }

                  }
                  if($payment == 'Priv Coin'){
                    $cos = "<div id='co$no'>$cost</div>";
                  } else {
                    $cos = "<div id='cost$no'>$cost</div>";
                  }
              ?>
              <tr>
                  <td><?php echo $inv;?></td>
                  <td><?php echo ucwords($uname);?></td>
                  <td><?php echo $type;?></td>
                  <td><?php echo $qty;?></td>
                  <td><?php echo $cos;?></td>
                  <td><?php echo $payment;?></td>
                  <td><?php echo $status;?></td>
                  <td><?php echo $date;?></td>
                  <td><?php echo $act;?></td>
              </tr>
              <?php $no++;}?>
              </tbody>
              </table>

              </div>
              </div>
              </section>
              </div>
              </div>
              <!-- page end-->
          </section>
      </section>
      <!--main content end-->
      <?php SideFooter($setting, true, true);?>
            <!--footer end-->
  </section>

    <!-- js placed at the end of the document so the pages load faster -->

    <script src="<?php echo $setting->js;?>/jquery.js"></script>
    <script src="<?php echo $setting->js;?>/jquery-ui-1.9.2.custom.min.js"></script>
    <script src="<?php echo $setting->js;?>/jquery-migrate-1.2.1.min.js"></script>
    <script src="<?php echo $setting->js;?>/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="<?php echo $setting->js;?>/jquery.dcjqaccordion.2.7.js"></script>
    <script src="<?php echo $setting->js;?>/jquery.scrollTo.min.js"></script>
    <script src="<?php echo $setting->js;?>/jquery.nicescroll.js" type="text/javascript"></script>
    <script type="text/javascript" language="javascript" src="<?php echo $setting->assets;?>/advanced-datatable/media/js/jquery.dataTables.js"></script>
    <script type="text/javascript" src="<?php echo $setting->assets;?>/data-tables/DT_bootstrap.js"></script>
    <script src="<?php echo $setting->js;?>/respond.min.js" ></script>
    <!--right slidebar-->
    <script src="<?php echo $setting->js;?>/slidebars.min.js"></script>
    <!--dynamic table initialization -->
    <script src="<?php echo $setting->js;?>/dynamic_table_init.js"></script>
    <!--common script for all pages-->
    <script src="<?php echo $setting->js;?>/common-scripts.js"></script>
        <script type="text/javascript">
      $(document).ready(function(){
        for (var i = 0; i < <?php echo $abc;?>; i++) {
          if($('#co'+i).html()){
            $("#co"+i).html(toCoin(($('#co'+i).html())));
          } else if($('#cost'+i).html()){
            $("#cost"+i).html(toRp(($('#cost'+i).html())));
          }
        }     
      });
      function toRp(angka){
      var rev     = parseInt(angka, 10).toString().split('').reverse().join('');
      var rev2    = '';
      for(var i = 0; i < rev.length; i++){
        rev2  += rev[i];
        if((i + 1) % 3 === 0 && i !== (rev.length - 1)){
            rev2 += '.';
        }
      }
      return 'Rp. ' + rev2.split('').reverse().join('') + ',00';
      }
      function toCoin(angka){
      var rev     = parseInt(angka, 10).toString().split('').reverse().join('');
      var rev2    = '';
      for(var i = 0; i < rev.length; i++){
        rev2  += rev[i];
        if((i + 1) % 3 === 0 && i !== (rev.length - 1)){
            rev2 += '.';
        }
      }
      return rev2.split('').reverse().join('') + ' ¢';
      }

    function konf(a) {
      return confirm('Invoice  nomor #'+a+' akan diverifkasi');
    }

    </script>


  </body>
</html>
