<?php
require '../lib/config.php';
require 'inc/auth.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo $setting->description;?>">
    <meta name="author" content="Supian M">
    <meta name="keyword" content="<?php echo $setting->keywords;?>">
    <link rel="shortcut icon" href="<?php echo $setting->img;?>/favicon.png">
    <title><?php echo $setting->title;?> | <?php echo $setting->subtitle;?></title>
    <!-- Bootstrap core CSS -->
    <link href="<?php echo $setting->css;?>/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo $setting->css;?>/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="<?php echo $setting->assets;?>/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <!--dynamic table-->
    <link href="<?php echo $setting->assets;?>/advanced-datatable/media/css/demo_page.css" rel="stylesheet" />
    <link href="<?php echo $setting->assets;?>/advanced-datatable/media/css/demo_table.css" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo $setting->assets;?>/data-tables/DT_bootstrap.css" />
    <link rel="stylesheet" href="<?php echo $setting->css;?>/owl.carousel.css" type="text/css">
    <!--right slidebar-->
    <link href="<?php echo $setting->css;?>/slidebars.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="<?php echo $setting->css;?>/style.css" rel="stylesheet">
    <link href="<?php echo $setting->css;?>/style-responsive.css" rel="stylesheet" />
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
      <script src="<?php echo $setting->js;?>/html5shiv.js"></script>
      <script src="<?php echo $setting->js;?>/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
  <section id="container" >
<?php
include $_SERVER['DOCUMENT_ROOT'].'/'.dir_admin.'/inc/header.inc';
include $_SERVER['DOCUMENT_ROOT'].'/'.dir_admin.'/inc/sidebar.inc';
?>
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
              <!--state overview start-->
              <div class="row state-overview">
                  <div class="col-lg-3 col-sm-6">
                      <section class="panel">
                          <div class="symbol terques">
                              <i class="fa fa-cogs"></i>
                          </div>
                          <div class="value">
                              <h1 class=" count">
                                  0
                              </h1>
                              <p>Tools</p>
                          </div>
                      </section>
                  </div>
                  <div class="col-lg-3 col-sm-6">
                      <section class="panel">
                          <div class="symbol red">
                              <i class="fa fa-users"></i>
                          </div>
                          <div class="value">
                              <h1 class=" count2">
                                  0
                              </h1>
                              <p>Users</p>
                          </div>
                      </section>
                  </div>
                  <div class="col-lg-3 col-sm-6">
                      <section class="panel">
                          <div class="symbol yellow">
                              <i class="fa fa-shopping-cart"></i>
                          </div>
                          <div class="value">
                              <h1 class=" count3">
                                  0
                              </h1>
                              <p>Orders</p>
                          </div>
                      </section>
                  </div>
                  <div class="col-lg-3 col-sm-6">
                      <section class="panel">
                          <div class="symbol blue">
                              <i class="fa fa-fire"></i>
                          </div>
                          <div class="value">
                              <h1 class=" count4">
                                  0
                              </h1>
                              <p>API Live</p>
                          </div>
                      </section>
                  </div>
              </div>
              <!--state overview end-->

          </section>
      </section>
      <!--main content end-->
	<?php SideFooter(true,true);?>
  </section>

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="<?php echo $setting->js;?>/jquery.js"></script>
    <script src="<?php echo $setting->js;?>/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="<?php echo $setting->js;?>/jquery.dcjqaccordion.2.7.js"></script>
    <script src="<?php echo $setting->js;?>/jquery.scrollTo.min.js"></script>
    <script src="<?php echo $setting->js;?>/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="<?php echo $setting->js;?>/jquery.sparkline.js" type="text/javascript"></script>
    <script src="<?php echo $setting->js;?>/owl.carousel.js" ></script>
    <script src="<?php echo $setting->js;?>/jquery.customSelect.min.js" ></script>
    <script src="<?php echo $setting->js;?>/respond.min.js" ></script>

    <!--right slidebar-->
    <script src="<?php echo $setting->js;?>/slidebars.min.js"></script>
    <!--common script for all pages-->
    <script src="<?php echo $setting->js;?>/common-scripts.js"></script>
    <!--dynamic table initialization -->
    <script src="<?php echo $setting->js;?>/dynamic_table_init.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo $setting->assets;?>/advanced-datatable/media/js/jquery.dataTables.js"></script>
    <script type="text/javascript" src="<?php echo $setting->assets;?>/data-tables/DT_bootstrap.js"></script>
<?php
  // query cek jumlah credit
  $db->go("SELECT `id` FROM `tools`");
  $countTools = $db->numRows();

  // query cek jumlah refferal
  $db->go("SELECT `id` FROM `users` WHERE `level` != 'Admin'");
  $countUsers = $db->numRows();

  // query cek jumlah order
  $db->go("SELECT `id` FROM `orders` WHERE `pending` = '1'");
  $countOrder = $db->numRows();

  // query cek jumlah API Live
  $db->go("SELECT `api` FROM `api_strip` WHERE `status` = '1'");
  $countApi = $db->numRows();

?>
  <script>
  countUp(<?php echo $countTools;?>);
  countUp2(<?php echo $countUsers;?>);
  countUp3(<?php echo $countOrder;?>);
  countUp4(<?php echo $countApi;?>);


      //owl carousel

      $(document).ready(function() {
          $("#owl-demo").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true,
			        autoPlay:true
          });
      });
      //custom select box
      $(function(){
          $('select.styled').customSelect();
      });

      function countUp(count){
        var div_by = 10,
        speed = Math.round(count / div_by),
        $display = $('.count'),
        run_count = 1,
        int_speed = 10;

        var int = setInterval(function() {
          if(run_count < div_by){
            $display.text(speed * run_count);
            run_count++;
          } else if(parseInt($display.text()) < count) {
            var curr_count = parseInt($display.text()) + 1;
            $display.text(curr_count);
          } else {
            clearInterval(int);
          }
        }, int_speed);
      }
      function countUp2(count){
        var div_by = 10,
        speed = Math.round(count / div_by),
        $display = $('.count2'),
        run_count = 1,
        int_speed = 10;

        var int = setInterval(function() {
          if(run_count < div_by){
              $display.text(speed * run_count);
              run_count++;
          } else if(parseInt($display.text()) < count) {
              var curr_count = parseInt($display.text()) + 1;
              $display.text(curr_count);
          } else {
              clearInterval(int);
          }
        }, int_speed);
      }
      function countUp3(count){
        var div_by = 10,
          speed = Math.round(count / div_by),
          $display = $('.count3'),
          run_count = 1,
          int_speed = 10;

        var int = setInterval(function() {
          if(run_count < div_by){
              $display.text(speed * run_count);
              run_count++;
          } else if(parseInt($display.text()) < count) {
              var curr_count = parseInt($display.text()) + 1;
              $display.text(curr_count);
          } else {
              clearInterval(int);
          }
      }, int_speed);
    }
    function countUp4(count){
      var div_by = 10,
          speed = Math.round(count / div_by),
          $display = $('.count4'),
          run_count = 1,
          int_speed = 10;

      var int = setInterval(function() {
          if(run_count < div_by){
              $display.text(speed * run_count);
              run_count++;
          } else if(parseInt($display.text()) < count) {
              var curr_count = parseInt($display.text()) + 1;
              $display.text(curr_count);
          } else {
              clearInterval(int);
          }
      }, int_speed);
    }
  </script>

  </body>
</html>
