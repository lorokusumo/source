<?php require'../lib/config.php'; require'inc/auth.php';?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="<?php echo $setting->charset;?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo $setting->description;?>/">
    <meta name="author" content="M-Supian.ID">
    <meta name="keyword" content="<?php echo $setting->keywords;?>/">
    <link rel="shortcut icon" href="<?php echo $setting->img;?>/favicon.png">
    <title><?php echo $setting->title;?> | Top Up</title>
    <link href="<?php echo $setting->css;?>/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo $setting->css;?>/bootstrap-reset.css" rel="stylesheet">
    <link href="<?php echo $setting->assets;?>/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="<?php echo $setting->assets;?>/advanced-datatable/media/css/demo_page.css" rel="stylesheet" />
    <link href="<?php echo $setting->assets;?>/advanced-datatable/media/css/demo_table.css" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo $setting->assets;?>/data-tables/DT_bootstrap.css" />
    <link href="<?php echo $setting->css;?>/slidebars.css" rel="stylesheet">
    <link href="<?php echo $setting->css;?>/style.css" rel="stylesheet">
    <link href="<?php echo $setting->css;?>/style-responsive.css" rel="stylesheet" />
    <!--[if lt IE 9]>
      <script src="<?php echo $setting->js;?>/html5shiv.js"></script>
      <script src="<?php echo $setting->js;?>/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
    <section id="container" class="">
<?php
include $_SERVER['DOCUMENT_ROOT'].'/'.dir_admin.'/inc/header.inc';
include $_SERVER['DOCUMENT_ROOT'].'/'.dir_admin.'/inc/sidebar.inc';
?>
      <section id="main-content">
          <section class="wrapper">
              <div class="row">
                  <div class="col-lg-12">
                      <?php ViewMessage();?>
                  </div>
              </div>
              <!-- page start-->
            <div class="row">
                <div class="col-lg-12">
                  <section class="panel">
                    <header class="panel-heading">
                      Topup Priv Coin
                    </header>
                    <div class="panel-body">
                    <form method="POST" action="<?php echo $setting->admin;?>/action/topup.php">
                      <div class="form-group col-lg-12">
                        <label>Email/ Username</label>
                        <input type="text" name="user" class="form-control" required="true">
                      </div>
                      <div class="form-group col-lg-12">
                        <label>Amount</label>
                        <input type="number" name="amount" class="form-control" required="">
                      </div>
                      <button class="btn btn-info pull-right" onclick="return confirm('Anda akan mengirim Priv Coin ?');"><i class="fa fa-plus"></i> Top Up</button>
                    </form>
                    </div>
                  </section>
                </div>
                <div class="col-sm-12">
                  <section class="panel">
                    <header class="panel-heading">
                      Top Up History
                    </header>
                    <div class="panel-body adv-table">
                      <table class="display table-striped table-bordered" id="dynamic-table">
                        <thead>
                          <tr>
                            <th>Top Up By</th>
                            <th>To</th>
                            <th>Amount</th>
                            <th>Datetime</th>
                          </tr>
                        </thead>
                        <tbody>
                        <?php
                          $db->go("SELECT `to_uname`, `from_uname`, `amount`, `date_` FROM `topup_history`");
                          while ($row = $db->fetchRows()){
                            $to     = $row[0];
                            $from   = $row[1];
                            $amount = $row[2];
                            $date   = $row[3];
                        ?>
                        <tr>
                          <td><?php echo $from;?></td>
                          <td><?php echo ucwords($to);?></td>
                          <td>+<?php echo $amount;?> &#162;</td>
                          <td><?php echo $date;?></td>
                        </tr>
                        <?php } ?>
                        </tbody>
                      </table>
                    </div>
                  </section>
                </div>
              </div>
          </section>
      </section>
  <?php SideFooter(true,true);?>
  </section>
    <!-- js placed at the end of the document so the pages load faster -->
    <script src="<?php echo $setting->js;?>/jquery.js"></script>
    <script src="<?php echo $setting->js;?>/jquery-ui-1.9.2.custom.min.js"></script>
    <script src="<?php echo $setting->js;?>/jquery-migrate-1.2.1.min.js"></script>
    <script src="<?php echo $setting->js;?>/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="<?php echo $setting->js;?>/jquery.dcjqaccordion.2.7.js"></script>
    <script src="<?php echo $setting->js;?>/jquery.scrollTo.min.js"></script>
    <script src="<?php echo $setting->js;?>/jquery.nicescroll.js" type="text/javascript"></script>
    <script type="text/javascript" language="javascript" src="<?php echo $setting->assets;?>/advanced-datatable/media/js/jquery.dataTables.js"></script>
    <script type="text/javascript" src="<?php echo $setting->assets;?>/data-tables/DT_bootstrap.js"></script>
    <script src="<?php echo $setting->js;?>/respond.min.js" ></script>
    <!--right slidebar-->
    <script src="<?php echo $setting->js;?>/slidebars.min.js"></script>
    <!--dynamic table initialization -->
    <script src="<?php echo $setting->js;?>/dynamic_table_init.js"></script>
    <!--common script for all pages-->
    <script src="<?php echo $setting->js;?>/common-scripts.js"></script>
  </body>
</html>