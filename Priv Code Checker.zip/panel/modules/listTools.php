<!DOCTYPE html>
<html lang="en">
	<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo $setting->description;?>">
    <meta name="author" content="Supian M">
    <meta name="keyword" content="<?php echo $setting->keywords;?>">
    <link rel="shortcut icon" href="<?php echo $setting->img;?>/favicon.png">
    <title><?php echo $setting->title;?> | Tools</title>
    <link href="<?php echo $setting->css;?>/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo $setting->css;?>/bootstrap-reset.css" rel="stylesheet">
    <link href="<?php echo $setting->assets;?>/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="<?php echo $setting->assets;?>/advanced-datatable/media/css/demo_page.css" rel="stylesheet" />
    <link href="<?php echo $setting->assets;?>/advanced-datatable/media/css/demo_table.css" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo $setting->assets;?>/data-tables/DT_bootstrap.css" />
    <link href="<?php echo $setting->css;?>/slidebars.css" rel="stylesheet">
    <link href="<?php echo $setting->css;?>/style.css" rel="stylesheet">
    <link href="<?php echo $setting->css;?>/style-responsive.css" rel="stylesheet" />
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
      <script src="<?php echo $setting->js;?>/html5shiv.js"></script>
      <script src="<?php echo $setting->js;?>/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
	  <section id="container" class="">
		<?php
			include $_SERVER['DOCUMENT_ROOT'].'/'.dir_admin.'/inc/header.inc';
			include $_SERVER['DOCUMENT_ROOT'].'/'.dir_admin.'/inc/sidebar.inc';
		?>
      <section id="main-content">
        <section class="wrapper">
            <div class="row">
              <div class="col-lg-12">
             <?php ViewMessage(); ?>
            </div>
              <div class="col-sm-12">
            <section class="panel">
            	<header class="panel-heading">
                List
            		<span class="tools pull-right">
              		<a href="javascript:;" class="fa fa-chevron-down"></a>
              		<a href="javascript:;" class="fa fa-times"></a>
            		</span>
            	</header>
              	<div class="panel-body">
              		<div class="adv-table">
              			<table class="display table table-striped table-bordered" id="dynamic-table">
              				<thead>
              					<tr>
                  				<th width="23%" style="text-align:center;">Title</th>
                  				<th width="30%" style="text-align:center;">Description</th>
                  				<th width="10%" style="text-align:center;">Type</th>
                  				<th width="6%" style="text-align:center;">Live</th>
                  				<th width="6%" style="text-align:center;">Die</th>
                  				<th width="7%" style="text-align:center;"><i class="fa fa-check" style="color:#4E9A06;"></i> <i style="color:#EF2929;" class="fa fa-times" title="Maintenance"></i></th>
				                  <th width="11%" style="text-align:center;">Action</th>
        					      </tr>
              				</thead>
              				<tbody>
              			<?php
                      $xcsrf = $_SESSION['xcsrf'] = Xcsrf();
                			$db->go("SELECT  `id`, `title`, `description`, `type`, `status`, `url`, `cost_success`, `cost_failed` FROM `tools` ORDER BY `title`");
                			while ($row = $db->fetchArray()){
                  			$id = $row['id'];
                  			$desc = $row['description'];
                  			$die = $row['cost_failed'];
                  			$live = $row['cost_success'];
                  			$type = $row['type'];
                        if($type == 'Social Media'){
                          $urlT = '/tools/socmed/'.$row['url'];
                        } else if($type == 'Checker'){
                          $urlT = '/tools/checker/'.$row['url'];
                        } else if($type == 'Other'){
                          $urlT = '/tools/other/'.$row['url'];
                        }
                 			 	if($row['status'] == 1){
                    			$title  = '<a href="'.$setting->url.'/'.$urlT.'" title="Live">'.$row['title'].'</a>';
                    			$status = '<span style="color:#4E9A06;" class="fa fa-check" title="Live"></span>';
                    			$maintenance = '<a href="'.$setting->admin.'/action/tools.php?id='.$id.'&status=0&xcsrf='.$xcsrf.'" class="btn btn-warning btn-xs" title="Maintenance '.$row['title'].'"><i class="fa fa-wrench"></i></a>';
                  			} else {
                    			$title  =  '<a href="'.$setting->url.'/'.$urlT.'" title="Maintenance"><font style="color:#EF2929;" title="Maintenance">'.$row['title'].'</font></a>';
                    			$status =  '<span style="color:#EF2929;" class="fa fa-times" title="Maintenance"></span>';
                    			$maintenance = '<a href="'.$setting->admin.'/action/tools.php?id='.$id.'&status=1&xcsrf='.$xcsrf.'" class="btn btn-success btn-xs" title="Activate '.$row['title'].'"><i class="fa fa-check-square-o"></i></a>';    
                  			}
                  			if($die > 0){
                    			$die = '<font style="text-align:center;color:#EF2929;">- '.$die.' &#162;</font>';
                  			} else {
                    			$die = '<font style="text-align:center;color:#EF2929;">- '.$die.' &#162;</font>';
                  			}
                  			if($live > 0){
                    			$live = '<font style="text-align:center;color:#EF2929;">- '.$live.' &#162;</font>';
                  			} else {
                    			$live = '<font style="text-align:center;color:#EF2929;">- '.$live.' &#162;</font>';
                  			}
                  			$edit = '<a href="'.$setting->admin.'/tools/edit/'.$id.'.html" class="btn btn-info btn-xs" title="Edit '.$row['title'].'"><i class="fa fa-edit"></i></a>';
			                  $delete = '<a href="'.$setting->admin.'/action/tools.php?id='.$id.'&delete=1&xcsrf='.$xcsrf.'" class="btn btn-danger btn-xs" title="Delete '.$row['title'].'"><i class="fa fa-trash-o"></i></a>';
      			            $action = $edit.' '.$maintenance.' '.$delete;
            				?>
              				<tr>
                  			<td><?php echo $title;?></td>
                  			<td><?php echo $desc;?></td>
                  			<td style="text-align:center;"><?php echo $type;?></td>
                  			<td style="text-align:center;"><?php echo $live;?></td>
                  			<td style="text-align:center;"><?php echo $die;?></td>
                  			<td style="text-align:center;"><?php echo $status;?></td>
                  			<td style="text-align:center;"><?php echo $action;?></td>
              				</tr>
              				<?php }?>
              			</tbody>
              		</table>
	              </div>
              </div>
            </section>
          </div>
        </div>
      </section>
    </section>
    <?php SideFooter(true, true);?>
  </section>
    <script src="<?php echo $setting->js;?>/jquery.js"></script>
    <script src="<?php echo $setting->js;?>/jquery-ui-1.9.2.custom.min.js"></script>
    <script src="<?php echo $setting->js;?>/jquery-migrate-1.2.1.min.js"></script>
    <script src="<?php echo $setting->js;?>/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="<?php echo $setting->js;?>/jquery.dcjqaccordion.2.7.js"></script>
    <script src="<?php echo $setting->js;?>/jquery.scrollTo.min.js"></script>
    <script src="<?php echo $setting->js;?>/jquery.nicescroll.js" type="text/javascript"></script>
    <script type="text/javascript" language="javascript" src="<?php echo $setting->assets;?>/advanced-datatable/media/js/jquery.dataTables.js"></script>
    <script type="text/javascript" src="<?php echo $setting->assets;?>/data-tables/DT_bootstrap.js"></script>
    <script src="<?php echo $setting->js;?>/respond.min.js" ></script>
    <script src="<?php echo $setting->js;?>/slidebars.min.js"></script>
    <script src="<?php echo $setting->js;?>/dynamic_table_init.js"></script>
    <script src="<?php echo $setting->js;?>/common-scripts.js"></script>
  </body>
</html>