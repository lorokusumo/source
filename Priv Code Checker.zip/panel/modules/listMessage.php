<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo $setting->description;?>">
    <meta name="author" content="Supian M">
    <meta name="keyword" content="<?php echo $setting->keywords;?>">
    <link rel="shortcut icon" href="<?php echo $setting->img;?>/favicon.png">
    <title><?php echo $setting->title;?> | Inbox</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo $setting->css;?>/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo $setting->css;?>/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="<?php echo $setting->assets;?>/font-awesome/css/font-awesome.css" rel="stylesheet" />

    <!--dynamic table-->
    <link href="<?php echo $setting->assets;?>/advanced-datatable/media/css/demo_page.css" rel="stylesheet" />
    <link href="<?php echo $setting->assets;?>/advanced-datatable/media/css/demo_table.css" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo $setting->assets;?>/data-tables/DT_bootstrap.css" />
      <!--right slidebar-->
      <link href="<?php echo $setting->css;?>/slidebars.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="<?php echo $setting->css;?>/style.css" rel="stylesheet">
    <link href="<?php echo $setting->css;?>/style-responsive.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
      <script src="<?php echo $setting->js;?>/html5shiv.js"></script>
      <script src="<?php echo $setting->js;?>/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

  <section id="container" class="">
      <!--header start-->
<?php
include $_SERVER['DOCUMENT_ROOT'].'/'.dir_admin.'/inc/header.inc';
include $_SERVER['DOCUMENT_ROOT'].'/'.dir_admin.'/inc/sidebar.inc';
?>
      <!--sidebar end-->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
              <!-- page start-->
              <div class="row">
                <div class="col-sm-12">
                <?php ViewMessage();?>
              <section class="panel">
              <header class="panel-heading">
                  Message
             <span class="tools pull-right">
                <a href="javascript:;" class="fa fa-chevron-down"></a>
                <a href="javascript:;" class="fa fa-times"></a>
             </span>
              </header>
              <div class="panel-body">
              <div class="adv-table">
              <table class="display table table-striped table-bordered" id="dynamic-table">
              <thead>
              <tr>
                  <th width="9.5%">Subject</th>
                  <th width="12.5%">Sender</th>
                  <th width="9.5%">Status</th>
                  <th width="10%">Date</th>
                  <th width="10%">Action</th>
              </tr>
              </thead>
              <tbody>
              <?php
                $xcsrf = $_SESSION['xcsrf'] = Xcsrf();
                $db->go("SELECT `id`, `from_`, `subject`, `status`, `date_` FROM `messages`");
                while ($row = $db->fetchArray()){
                 $from = $row['from_'];
                 $subject = $row['subject'];
                 $status = $row['status'];
                 $date = $row['date_'];
                 if($status == 1){
                  $status = '<font style="color:green;">Open</font>';
                  $act = '<a href="" class="btn btn-info btn-xs">Read</a> <a href="" class="btn btn-success btn-xs">Reply</a> <a href="" class="btn btn-danger btn-xs">Close</a>';
                 } else {
                  $status = '<font style="color:red;">Closed</font>';
                  $act = '<a href="" class="btn btn-info btn-xs">Read</a>';
                 }
                 
              ?>
              <tr>
                  <td><?php echo $subject;?></td>
                  <td><?php echo ucwords($from);?></td>
                  <td><?php echo $status;?></td>
                  <td><?php echo $date;?></td>
                  <td><?php echo $act;?></td>
              </tr>
              <?php }?>
              </tbody>
              </table>

              </div>
              </div>
              </section>
              </div>
              </div>
          </section>
      </section>
      <?php SideFooter($setting, true, true);?>
  </section>

    <script src="<?php echo $setting->js;?>/jquery.js"></script>
    <script src="<?php echo $setting->js;?>/jquery-ui-1.9.2.custom.min.js"></script>
    <script src="<?php echo $setting->js;?>/jquery-migrate-1.2.1.min.js"></script>
    <script src="<?php echo $setting->js;?>/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="<?php echo $setting->js;?>/jquery.dcjqaccordion.2.7.js"></script>
    <script src="<?php echo $setting->js;?>/jquery.scrollTo.min.js"></script>
    <script src="<?php echo $setting->js;?>/jquery.nicescroll.js" type="text/javascript"></script>
    <script type="text/javascript" language="javascript" src="<?php echo $setting->assets;?>/advanced-datatable/media/js/jquery.dataTables.js"></script>
    <script type="text/javascript" src="<?php echo $setting->assets;?>/data-tables/DT_bootstrap.js"></script>
    <script src="<?php echo $setting->js;?>/respond.min.js" ></script>
    <script src="<?php echo $setting->js;?>/slidebars.min.js"></script>
    <script src="<?php echo $setting->js;?>/dynamic_table_init.js"></script>
    <script src="<?php echo $setting->js;?>/common-scripts.js"></script>
  </body>
</html>
