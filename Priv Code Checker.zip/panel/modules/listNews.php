<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="<?php echo $setting->charset;?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo $setting->description;?>/">
    <meta name="author" content="M-Supian.ID">
    <meta name="keyword" content="<?php echo $setting->keywords;?>/">
    <link rel="shortcut icon" href="<?php echo $setting->img;?>/favicon.png">
    <title><?php echo $setting->title;?> | News</title>
    <!-- Bootstrap core CSS -->
    <link href="<?php echo $setting->css;?>/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo $setting->css;?>/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="<?php echo $setting->assets;?>/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <!--dynamic table-->
    <link href="<?php echo $setting->assets;?>/advanced-datatable/media/css/demo_page.css" rel="stylesheet" />
    <link href="<?php echo $setting->assets;?>/advanced-datatable/media/css/demo_table.css" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo $setting->assets;?>/data-tables/DT_bootstrap.css" />
      <!--right slidebar-->
      <link href="<?php echo $setting->css;?>/slidebars.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="<?php echo $setting->css;?>/style.css" rel="stylesheet">
    <link href="<?php echo $setting->css;?>/style-responsive.css" rel="stylesheet" />
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
      <script src="<?php echo $setting->js;?>/html5shiv.js"></script>
      <script src="<?php echo $setting->js;?>/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
  <section id="container" class="">
<?php
include $_SERVER['DOCUMENT_ROOT'].'/'.dir_admin.'/inc/header.inc';
include $_SERVER['DOCUMENT_ROOT'].'/'.dir_admin.'/inc/sidebar.inc';
?>
      <!--sidebar end-->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
              <div class="row">
                  <div class="col-lg-12">
                      <!--breadcrumbs start -->
                      <ul class="breadcrumb">
                          <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
                          <li><a href="#">Admin</a></li>
                          <li class="active">News</li>
                      </ul>
                      <!--breadcrumbs end -->
                      <?php ViewMessage();?>
                  </div>
              </div>
              <!-- page start-->
              <div class="row">
                <div class="col-sm-12">
                  <section class="panel">
                    <header class="panel-heading">
                      News
                    </header>
                    <div class="panel-body adv-table">
                      <table class="display table-striped" id="dynamic-table">
                        <thead>
                          <tr>
                            <th style="text-align:center;">Date</th>
                            <th style="text-align:center;">Title</th>
                            <th width="150" style="text-align:center;">Status</th>
                            <th width="12%" style="text-align:center;">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                        <?php
                        $xcsrf = $_SESSION['xcsrf'] = Xcsrf();
                        $db->go("SELECT `id`, `writer`, `title`, `content`, `published`, `date_` FROM `news` ORDER BY `date_`");
                        while ($row = $db->fetchArray()) {
                            $title = "<a href=\"$setting->url/news/$row[id]\"> $row[title] </a>";
                        if (strlen($row['content']) > 70) {
                            $content = substr($row['content'], 0, 70)."...  <a href=\"$setting->url/news/$row[id]\"> Read More</a>";
                        } else {
                            $content = $row['content'];
                        }
                        $date = $row['date_'];
                        $published = $row['published'];
                        if ($published == 1) {
                              $published = 'Published';
                              $published_act = "<a href=\"$setting->admin/action/news.php?id=$row[id]&published=No&xcsrf=$xcsrf\"><button type=\"button\" class=\"btn btn-warning btn-xs\"> <i class=\"fa fa-ban\"></i></button></a>";
                        } else {
                              $published = '<strike><font color="red">Unpublish</font></strike>';
                              $published_act = "<a href=\"$setting->admin/action/news.php?id=$row[id]&published=Yes&xcsrf=$xcsrf\"><button type=\"button\" class=\"btn btn-info btn-xs\"> <i class=\"fa fa-ban\"></i></button></a>";
                        }

                        $edit = "<a href=\"$setting->admin/news/$row[id]\"><button type=\"button\" class=\"btn btn-primary btn-xs\"> <i class=\"fa fa-file-text\"></i></button></a>";
                        $action = "$edit $published_act <a href=\"$setting->admin/action/news.php?id=$row[id]&delete=True&xcsrf=$xcsrf\"><button type=\"button\" class=\"btn btn-danger btn-xs\"> <i class=\"fa fa-trash-o\"></i></button></a>";?>
                        <tr>
                          <td><?php echo $date;?></td>
                          <td><?php echo $title;?></td>
                          <td><?php echo $published;?></td>
                          <td><?php echo $action;?></td>
                        </tr>
                        <?php }?>
                        </tbody>
                      </table>
                    </div>
                  </section>
                </div>
              </div>
          </section>
      </section>
      <?php SideFooter(true,true);?>
  </section>
    <script src="<?php echo $setting->js;?>/jquery.js"></script>
    <script src="<?php echo $setting->js;?>/jquery-ui-1.9.2.custom.min.js"></script>
    <script src="<?php echo $setting->js;?>/jquery-migrate-1.2.1.min.js"></script>
    <script src="<?php echo $setting->js;?>/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="<?php echo $setting->js;?>/jquery.dcjqaccordion.2.7.js"></script>
    <script src="<?php echo $setting->js;?>/jquery.scrollTo.min.js"></script>
    <script src="<?php echo $setting->js;?>/jquery.nicescroll.js" type="text/javascript"></script>
    <script type="text/javascript" language="javascript" src="<?php echo $setting->assets;?>/advanced-datatable/media/js/jquery.dataTables.js"></script>
    <script type="text/javascript" src="<?php echo $setting->assets;?>/data-tables/DT_bootstrap.js"></script>
    <script src="<?php echo $setting->js;?>/respond.min.js" ></script>
    <script src="<?php echo $setting->js;?>/slidebars.min.js"></script>
    <!--dynamic table initialization -->
    <script src="<?php echo $setting->js;?>/dynamic_table_init.js"></script>
    <!--common script for all pages-->
    <script src="<?php echo $setting->js;?>/common-scripts.js"></script>
  </body>
</html>