<!DOCTYPE html>
<html lang="en">
	<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo $setting->description;?>">
    <meta name="author" content="Supian M">
    <meta name="keyword" content="<?php echo $setting->keywords;?>">
    <link rel="shortcut icon" href="<?php echo $setting->img;?>/favicon.png">
    <title><?php echo $setting->title;?> | Edit</title>
    <link href="<?php echo $setting->css;?>/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo $setting->css;?>/bootstrap-reset.css" rel="stylesheet">
    <link href="<?php echo $setting->assets;?>/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="<?php echo $setting->css;?>/slidebars.css" rel="stylesheet">
    <link href="<?php echo $setting->css;?>/style.css" rel="stylesheet">
    <link href="<?php echo $setting->css;?>/style-responsive.css" rel="stylesheet" />
    <!--[if lt IE 9]>
      <script src="<?php echo $setting->js;?>/html5shiv.js"></script>
      <script src="<?php echo $setting->js;?>/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
  <section id="container" class="">
<?php
include $_SERVER['DOCUMENT_ROOT'].'/'.dir_admin.'/inc/header.inc';
include $_SERVER['DOCUMENT_ROOT'].'/'.dir_admin.'/inc/sidebar.inc';
?>
    <section id="main-content">
      <section class="wrapper">
        <div class="row">
          <div class="col-lg-12">
            <?php ViewMessage();?>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12">
            <section class="panel">
              <header class="panel-heading">
                  Add Tool
              </header>
              <?php 
$id = Filter($_GET['id']);
$db->go("SELECT `title`, `description`,`type`,`url`,`cost_success`,`cost_failed` FROM `tools` WHERE `id` = '$id'");

$row = $db->fetchArray();
if($db->numRows() == 0){
	Redirect($setting->admin.'/tools.html');
}
?>
                <form method="POST" action="<?php echo $setting->admin.'/action/tools.php';?>">
                  <div class="panel-body">
                    <div class="form-group col-lg-12">
                      <label>Title</label>
                      <input type="text" class="form-control" name="title" value="<?php echo $row['title'];?>" >
                      <input type="hidden" name="id" value="<?php echo $id;?>">
                    </div>
                   <div class="form-group col-lg-12">
                      <label>Desciption</label>
                      <textarea type="text" class="form-control" name="description" value="Description"><?php echo $row['description'];?></textarea>
                      </div>
                      <div class="form-group col-lg-12">
                        <label>Category</label>
                        <select class="form-control" name="category">
                          <option value="Checker">Checker</option>
                          <option value="Social Media">Social Media</option>
                          <option value="Other">Others</option>
                        </select> 
                      </div>
                      <div class="form-group col-lg-6">
                        <label>Cost If Success</label>
                        <select class="form-control" name="success">
                          <?php for ($i = 0; $i < 101; ++$i){echo "<option value=\"$i\">$i &#162;</option>";}?>
                        </select> 
                      </div>
                      <div class="form-group col-lg-6">
                        <label>Cost If Failed</label>
                        <select class="form-control" name="failed">
                          <?php for ($i = 0; $i < 101; ++$i){echo "<option value=\"$i\">$i &#162;</option>";}?>
                        </select> 
                      </div>
                      <div class="form-group col-lg-12">
                        <label>URL</label>
                          <input type="text" class="form-control" name="url" value="<?php echo $row['url'];?>" required>
                      </div>
                      <button class="btn btn-danger pull-right" name="edit"><i class="fa fa-plus"></i> Add</button>
                    </div>
                  </form>
                  </section>
                </div>
              </div>
          </section>
      </section>
  <?php SideFooter(true,true);?>
  </section>
    <script src="<?php echo $setting->js;?>/jquery.js"></script>
    <script src="<?php echo $setting->js;?>/jquery-ui-1.9.2.custom.min.js"></script>
    <script src="<?php echo $setting->js;?>/jquery-migrate-1.2.1.min.js"></script>
    <script src="<?php echo $setting->js;?>/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="<?php echo $setting->js;?>/jquery.dcjqaccordion.2.7.js"></script>
    <script src="<?php echo $setting->js;?>/jquery.scrollTo.min.js"></script>
    <script src="<?php echo $setting->js;?>/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="<?php echo $setting->js;?>/respond.min.js" ></script>
    <script src="<?php echo $setting->js;?>/slidebars.min.js"></script>
    <script src="<?php echo $setting->js;?>/common-scripts.js"></script>
  </body>
</html>