<?php require '../lib/config.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo $setting->description;?>">
    <meta name="author" content="Supian M">
    <meta name="keyword" content="<?php echo $setting->keywords;?>">
    <link rel="shortcut icon" href="<?php echo $setting->img;?>/favicon.png">
    <title><?php echo $setting->title;?> | Get Out</title>
    <link href="<?php echo $setting->css;?>/style.css" rel="stylesheet">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
</head>
  <body style="background-color: #f1f2f7; background-image: url(<?php echo $setting->img.'/protect.png';?>);background-position: center;background-attachment: fixed;background-repeat: no-repeat;">
    <div id="loading"></div> 
  </body>
</html>
    <script src="<?php echo $setting->js;?>/jquery-latest.js"></script>
    <script src="<?php echo $setting->js;?>/loading.js"></script>