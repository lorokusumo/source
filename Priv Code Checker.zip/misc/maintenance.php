<?php require '../lib/config.php';?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo $setting->description;?>">
    <meta name="author" content="Supian M">
    <meta name="keyword" content="<?php echo $setting->keywords;?>">
    <link rel="shortcut icon" href="<?php echo $setting->img;?>/favicon.png">
    <title><?php echo $setting->title;?> | Undermaintenance</title>
    <link href="<?php echo $setting->css;?>/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo $setting->css;?>/bootstrap-reset.css" rel="stylesheet">
    <link href="<?php echo $setting->assets;?>/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="<?php echo $setting->css;?>/soon.css" rel="stylesheet">
    <link href="<?php echo $setting->css;?>/style.css" rel="stylesheet">
    <link href="<?php echo $setting->css;?>/style-responsive.css" rel="stylesheet" />
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
</head>
<body class="cs-bg">
    <section id="header">
        <div class="container">
            <header>
                <!-- HEADLINE -->
                <a class="logo floatless" href="<?php echo $setting->url;?>"><img src="<?php echo $setting->img.'/PrivCode-2.png';?>"></a>
                <h2 > Under Maintenance...</h2>
                <br/>
                <p><h4>Sorry for the inconvenience but we’re performing some maintenance at the moment. <br />If you need to you can always <a href="mailto:privcodes@gmail.com">contact us</a>, otherwise we’ll be back online shortly!</h4></p>
            </header>
            <div id="timer" data-animated="FadeIn">
                <p id="message"></p>
                <div id="days" class="timer_box"></div>
                <div id="hours" class="timer_box"></div>
                <div id="minutes" class="timer_box"></div>
                <div id="seconds" class="timer_box"></div>
            </div>
            <div class="col-lg-4 col-lg-offset-4 mt centered">
            	<form class="form-inline" role="form">
				  <div class="form-group">
				    <label class="sr-only" for="exampleInputEmail2">Email address</label>
				    <input type="email" class="form-control" id="exampleInputEmail2" placeholder="Enter email">
				  </div>
				  <button type="submit" class="btn btn-danger">Submit</button>
				</form>            
			</div>
            
        </div>
    </section>
    <script src="<?php echo $setting->js;?>/jquery.js"></script>
    <script type="text/javascript" src="<?php echo $setting->js;?>/modernizr.custom.js"></script>
    <script src="<?php echo $setting->js;?>/bootstrap.min.js"></script>
    <script src="<?php echo $setting->js;?>/soon/plugins.js"></script>
    <script src="<?php echo $setting->js;?>/soon/custom.js"></script>
    <script type="text/javascript">
    (function($) {
    /**
    * Set your date here  (YEAR, MONTH (0 for January/11 for December), DAY, HOUR, MINUTE, SECOND)
    * according to the GMT+0 Timezone
    **/
    var launch  = new Date(<?php echo Date("Y");?>, <?php echo (Date("m")-1);?>, <?php echo (Date("d")+1);?>, 10, 00);
    var message = $('#message');
    var days    = $('#days');
    var hours   = $('#hours');
    var minutes = $('#minutes');
    var seconds = $('#seconds');
    
    setDate();
    function setDate(){
        var now = new Date();
        if( launch < now ){
            days.html('<h1>0</H1><p>Day</p>');
            hours.html('<h1>0</h1><p>Hour</p>');
            minutes.html('<h1>0</h1><p>Minute</p>');
            seconds.html('<h1>0</h1><p>Second</p>');
            message.html('OUR SITE IS NOT READY YET, BUT WE ARE COMING SOON');
        }
        else{
            var s = -now.getTimezoneOffset()*60 + (launch.getTime() - now.getTime())/1000;
            var d = Math.floor(s/86400);
            days.html('<h1>'+d+'</h1><p>Day'+(d>1?'s':''),'</p>');
            s -= d*86400;

            var h = Math.floor(s/3600);
            hours.html('<h1>'+h+'</h1><p>Hour'+(h>1?'s':''),'</p>');
            s -= h*3600;

            var m = Math.floor(s/60);
            minutes.html('<h1>'+m+'</h1><p>Minute'+(m>1?'s':''),'</p>');

            s = Math.floor(s-m*60);
            seconds.html('<h1>'+s+'</h1><p>Second'+(s>1?'s':''),'</p>');
            setTimeout(setDate, 1000);

//            message.html('OUR SITE IS NOT READY YET, BUT WE ARE COMING SOON');
        }
    }
})(jQuery);
    </script>
  </body>
</html>