<?php
class settings {
	public function __construct(){
        global $db;
		$db->go("SELECT * FROM `settings`");
		$row = $db->fetchRows();
		$this->title   	   = $row[0];
    	$this->subtitle    = $row[1];
    	$this->description = $row[2];
    	$this->keywords    = $row[3];
    	$this->balance     = $row[4];
        $this->security    = $row[5];	
    	$this->public_key  = $row[6];
    	$this->private_key = $row[7];
    	$this->maintenance = $row[8];
    	$this->url         = $row[9];
        $this->contact     = $row[10];
    	$this->style       = $this->url.'/'.dir_theme;
        $this->css 		   = $this->style.'/css';
    	$this->js 		   = $this->style.'/js';
    	$this->img 		   = $this->style.'/img';
    	$this->assets 	   = $this->style.'/assets';
        $this->audio       = $this->style.'/audio';
        $this->admin       = $this->url.'/'.dir_admin;
        $this->avatar      = $this->url.'/misc/avatar';
        $this->sticker     = $this->url.'/misc/stickers';
        $this->emoticon    = $this->url.'/misc/emoticons';
   }
    // Default timezone
    public function timezone() {
        return date_default_timezone_set(timezone);
    }
}