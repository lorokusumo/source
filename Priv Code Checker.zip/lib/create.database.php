<?php
$db->go("CREATE TABLE IF NOT EXISTS `api_strip` (
  `id` int(11) NOT NULL,
  `api` varchar(50) NOT NULL,
  `author` varchar(30) NOT NULL,
  `status` int(1) NOT NULL,
  `date_` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

$db->go("CREATE TABLE IF NOT EXISTS `chats` (
  `id` int(11) NOT NULL,
  `nickname` varchar(50) NOT NULL,
  `chat` varchar(250) NOT NULL,
  `date_` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

$db->go("CREATE TABLE IF NOT EXISTS `giftcodes` (
  `id` int(11) NOT NULL,
  `code` varchar(25) NOT NULL,
  `coin` int(9) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `usedby` varchar(35) DEFAULT 'None',
  `date_` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

$db->go("CREATE TABLE IF NOT EXISTS `invitecodes` (
  `id` int(11) NOT NULL,
  `code` varchar(25) NOT NULL,
  `createdby` varchar(50) NOT NULL DEFAULT 'System',
  `usedby` varchar(50) NOT NULL DEFAULT 'None',
  `type` enum('VIP','Reguler') NOT NULL DEFAULT 'Reguler',
  `status` int(1) NOT NULL DEFAULT '1',
  `date_` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

$db->go("CREATE TABLE IF NOT EXISTS `messages` (
  `id` int(11) NOT NULL,
  `from_` varchar(50) NOT NULL,
  `to_` varchar(50) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `read_` enum('1','0') NOT NULL DEFAULT '0',
  `date_` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

$db->go("CREATE TABLE IF NOT EXISTS `news` (
  `id` int(11) NOT NULL,
  `writer` varchar(50) NOT NULL DEFAULT 'Admin',
  `title` varchar(50) NOT NULL,
  `content` text NOT NULL,
  `published` enum('1','0') NOT NULL DEFAULT '1',
  `date_` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

$db->go("CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `item` varchar(100) NOT NULL,
  `count` int(15) NOT NULL,
  `cost` int(15) NOT NULL,
  `payment` varchar(20) NOT NULL,
  `invoice` int(5) NOT NULL,
  `pending` enum('1','0') NOT NULL DEFAULT '0',
  `date_` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

$db->go("CREATE TABLE IF NOT EXISTS `payments` (
  `id` int(11) NOT NULL,
  `payment` enum('BRI','BNI','Telkomsel','IM3') NOT NULL,
  `rate` float NOT NULL,
  `number` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

$db->go("CREATE TABLE IF NOT EXISTS `pricing` (
  `id` int(11) NOT NULL,
  `item` varchar(100) NOT NULL,
  `price` varchar(10) NOT NULL DEFAULT '1',
  `type` enum('IDR','Coin') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

$db->go("CREATE TABLE IF NOT EXISTS `settings` (
  `title` varchar(30) NOT NULL DEFAULT 'Priv Code',
  `subtitle` varchar(20) NOT NULL DEFAULT 'Private Web Service',
  `description` varchar(250) NOT NULL DEFAULT 'Private Web Service',
  `keywords` varchar(300) NOT NULL DEFAULT 'Private Web Service',
  `default_balance` int(9) NOT NULL DEFAULT '50',
  `security` enum('1','0') NOT NULL DEFAULT '1',
  `captcha_public_key` varchar(100) NOT NULL,
  `captcha_private_key` varchar(100) NOT NULL,
  `maintenance` enum('1','0') NOT NULL DEFAULT '0',
  `base_url` varchar(50) NOT NULL,
  `contact` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

$db->go("CREATE TABLE IF NOT EXISTS `tools` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `type` enum('Checker','Other','Social Media') NOT NULL DEFAULT 'Checker',
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `url` varchar(100) NOT NULL,
  `cost_success` int(5) NOT NULL,
  `cost_failed` int(5) NOT NULL,
  `date_` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

$db->go("CREATE TABLE IF NOT EXISTS `topup_history` (
  `id` int(11) NOT NULL,
  `to_uname` varchar(50) NOT NULL,
  `from_uname` varchar(50) NOT NULL,
  `amount` int(11) NOT NULL,
  `date_` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

$db->go("CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(40) NOT NULL,
  `email` varchar(50) NOT NULL,
  `level` enum('Admin','Reseller','Member') NOT NULL DEFAULT 'Member',
  `suspend` enum('1','0') NOT NULL DEFAULT '0',
  `recoverycode` varchar(25) NOT NULL DEFAULT 'Priv Code',
  `registered_date` varchar(50) NOT NULL,
  `last_logged` varchar(50) NOT NULL,
  `ip` varchar(50) NOT NULL,
  `priv_coin` int(9) NOT NULL,
  `avatar` varchar(50) NOT NULL DEFAULT 'default.png',
  `online` enum('1','0') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");


$db->go("ALTER TABLE `api_strip`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `api` (`api`);");

$db->go("ALTER TABLE `chats`
  ADD PRIMARY KEY (`id`);");

$db->go("ALTER TABLE `giftcodes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);");

$db->go("ALTER TABLE `invitecodes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);");

$db->go("ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);");

$db->go("ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);");

$db->go("ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);");

$db->go("ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);");

$db->go("ALTER TABLE `pricing`
  ADD PRIMARY KEY (`id`);");

$db->go("ALTER TABLE `settings`
  ADD PRIMARY KEY (`title`);");

$db->go("ALTER TABLE `tools`
  ADD PRIMARY KEY (`id`);");

$db->go("ALTER TABLE `topup_history`
  ADD PRIMARY KEY (`id`);");

$db->go("ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);");

$db->go("ALTER TABLE `api_strip`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;");

$db->go("ALTER TABLE `chats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;");

$db->go("ALTER TABLE `giftcodes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;");

$db->go("ALTER TABLE `invitecodes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;");

$db->go("ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;");

$db->go("ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;");

$db->go("ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;");

$db->go("ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;");

$db->go("ALTER TABLE `pricing`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;");

$db->go("ALTER TABLE `tools`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;");

$db->go("ALTER TABLE `topup_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;");

$db->go("ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;");

$db->go("CREATE TABLE IF NOT EXISTS `api_strip` (
  `id` int(11) NOT NULL,
  `api` varchar(50) NOT NULL,
  `author` varchar(30) NOT NULL,
  `status` int(1) NOT NULL,
  `date_` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

$db->go("CREATE TABLE IF NOT EXISTS `chats` (
  `id` int(11) NOT NULL,
  `nickname` varchar(50) NOT NULL,
  `chat` varchar(250) NOT NULL,
  `date_` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

$db->go("CREATE TABLE IF NOT EXISTS `giftcodes` (
  `id` int(11) NOT NULL,
  `code` varchar(25) NOT NULL,
  `coin` int(9) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `usedby` varchar(35) DEFAULT 'None',
  `date_` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

$db->go("CREATE TABLE IF NOT EXISTS `invitecodes` (
  `id` int(11) NOT NULL,
  `code` varchar(25) NOT NULL,
  `createdby` varchar(50) NOT NULL DEFAULT 'System',
  `usedby` varchar(50) NOT NULL DEFAULT 'None',
  `type` enum('VIP','Reguler') NOT NULL DEFAULT 'Reguler',
  `status` int(1) NOT NULL DEFAULT '1',
  `date_` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

$db->go("CREATE TABLE IF NOT EXISTS `messages` (
  `id` int(11) NOT NULL,
  `from_` varchar(50) NOT NULL,
  `to_` varchar(50) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `read_` enum('1','0') NOT NULL DEFAULT '0',
  `date_` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

$db->go("CREATE TABLE IF NOT EXISTS `news` (
  `id` int(11) NOT NULL,
  `writer` varchar(50) NOT NULL DEFAULT 'Admin',
  `title` varchar(50) NOT NULL,
  `content` text NOT NULL,
  `published` enum('1','0') NOT NULL DEFAULT '1',
  `date_` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

$db->go("CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `item` varchar(100) NOT NULL,
  `count` int(15) NOT NULL,
  `cost` int(15) NOT NULL,
  `payment` varchar(20) NOT NULL,
  `invoice` int(5) NOT NULL,
  `pending` enum('1','0') NOT NULL DEFAULT '0',
  `date_` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

$db->go("CREATE TABLE IF NOT EXISTS `payments` (
  `id` int(11) NOT NULL,
  `payment` enum('BRI','BNI','Telkomsel','IM3') NOT NULL,
  `rate` float NOT NULL,
  `number` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

$db->go("CREATE TABLE IF NOT EXISTS `pricing` (
  `id` int(11) NOT NULL,
  `item` varchar(100) NOT NULL,
  `price` varchar(10) NOT NULL DEFAULT '1',
  `type` enum('IDR','Coin') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

$db->go("CREATE TABLE IF NOT EXISTS `settings` (
  `title` varchar(30) NOT NULL DEFAULT 'Priv Code',
  `subtitle` varchar(20) NOT NULL DEFAULT 'Private Web Service',
  `description` varchar(250) NOT NULL DEFAULT 'Private Web Service',
  `keywords` varchar(300) NOT NULL DEFAULT 'Private Web Service',
  `default_balance` int(9) NOT NULL DEFAULT '50',
  `security` enum('1','0') NOT NULL DEFAULT '1',
  `captcha_public_key` varchar(100) NOT NULL,
  `captcha_private_key` varchar(100) NOT NULL,
  `maintenance` enum('1','0') NOT NULL DEFAULT '0',
  `base_url` varchar(50) NOT NULL,
  `contact` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

$db->go("CREATE TABLE IF NOT EXISTS `tools` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `type` enum('Checker','Other','Social Media') NOT NULL DEFAULT 'Checker',
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `url` varchar(100) NOT NULL,
  `cost_success` int(5) NOT NULL,
  `cost_failed` int(5) NOT NULL,
  `date_` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

$db->go("CREATE TABLE IF NOT EXISTS `topup_history` (
  `id` int(11) NOT NULL,
  `to_uname` varchar(50) NOT NULL,
  `from_uname` varchar(50) NOT NULL,
  `amount` int(11) NOT NULL,
  `date_` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

$db->go("CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(40) NOT NULL,
  `email` varchar(50) NOT NULL,
  `level` enum('Admin','Reseller','Member') NOT NULL DEFAULT 'Member',
  `suspend` enum('1','0') NOT NULL DEFAULT '0',
  `recoverycode` varchar(25) NOT NULL DEFAULT 'Priv Code',
  `registered_date` varchar(50) NOT NULL,
  `last_logged` varchar(50) NOT NULL,
  `ip` varchar(50) NOT NULL,
  `priv_coin` int(9) NOT NULL,
  `avatar` varchar(50) NOT NULL DEFAULT 'default.png',
  `online` enum('1','0') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");


$db->go("ALTER TABLE `api_strip`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `api` (`api`);");

$db->go("ALTER TABLE `chats`
  ADD PRIMARY KEY (`id`);");

$db->go("ALTER TABLE `giftcodes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);");

$db->go("ALTER TABLE `invitecodes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);");

$db->go("ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);");

$db->go("ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);");

$db->go("ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);");

$db->go("ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);");

$db->go("ALTER TABLE `pricing`
  ADD PRIMARY KEY (`id`);");

$db->go("ALTER TABLE `settings`
  ADD PRIMARY KEY (`title`);");

$db->go("ALTER TABLE `tools`
  ADD PRIMARY KEY (`id`);");

$db->go("ALTER TABLE `topup_history`
  ADD PRIMARY KEY (`id`);");

$db->go("ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);");

$db->go("ALTER TABLE `api_strip`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;");

$db->go("ALTER TABLE `chats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;");

$db->go("ALTER TABLE `giftcodes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;");

$db->go("ALTER TABLE `invitecodes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;");

$db->go("ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;");

$db->go("ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;");

$db->go("ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;");

$db->go("ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;");

$db->go("ALTER TABLE `pricing`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;");

$db->go("ALTER TABLE `tools`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;");

$db->go("ALTER TABLE `topup_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;");

$db->go("ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;");