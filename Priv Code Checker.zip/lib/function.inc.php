<?php
function getExtension($str){
    $i = strrpos($str, '.');
    if (!$i) {
        return '';
    }
    $l = strlen($str) - $i;
    $ext = substr($str, $i + 1, $l);
    return $ext;
}

function inStr($s, $as){
    $s = strtoupper($s);
    if(!is_array($as)) $as=array($as);
    for($i=0;$i<count($as);$i++) if(strpos(($s),strtoupper($as[$i]))!==false) return true;
    return false;
}

function getSock($ip){
    preg_match("/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}[:|-\s\/]\d{1,7}/", $ip,  $s);
    return $s[0];
}

function Result($err, $msg, $cos = '', $cos2 = ''){
	global $setting;
	$supian = '<a href="'.$setting->url.'">'.Supian($setting->title).'</a>';
	$view['error'] = $err;
	if($view['error'] == 0){
		$view['msg'] = $msg;
	} else if($view['error'] == 1){
	    if($cos == '') {
	    	$view['msg'] = '<font style="color:#4E9A06;font-weight:bold;">Live</font> | '.$msg.' | <font style=color:#7D0000;font-weight: bold;>Checked by</font> '.$supian.' <font style=color:#7D0000;font-weight: bold;> at '.DateTime().'</font>';
	    } else {
	    	if($cos2 == '') {
		    	$view['msg'] = '<font style="color:#4E9A06;font-weight:bold;">'.$cos.'</font> | '.$msg.' | <font style=color:#7D0000;font-weight: bold;>Checked by</font> '.$supian.' <font style=color:#7D0000;font-weight: bold;> at '.DateTime().'</font>';
		    } else {
		    	$view['msg'] = '<font style="color:#4E9A06;font-weight:bold;">'.$cos.'</font> | '.$msg.' | <font style=color:#7D0000;font-weight: bold;>'.$cos2.' by</font> '.$supian.' <font style=color:#7D0000;font-weight: bold;> at '.DateTime().'</font>';
		    }
	    }
	} else if($view['error'] == 2){
		if($cos == '') {
	    	$view['msg'] = '<font style="color:#CC0000;font-weight:bold;">Die</font> | '.$msg.' | <font style=color:#7D0000;font-weight: bold;>Checked by</font> '.$supian.' <font style=color:#7D0000;font-weight: bold;> at '.DateTime().'</font>';
	    } else {
	    	if($cos2 == '') {
	    		$view['msg'] = '<font style="color:#CC0000;font-weight:bold;">'.$cos.'</font> | '.$msg.' | <font style=color:#7D0000;font-weight: bold;>Checked by</font> '.$supian.' <font style=color:#7D0000;font-weight: bold;> at '.DateTime().'</font>';
	    	} else {
	    		$view['msg'] = '<font style="color:#CC0000;font-weight:bold;">'.$cos.'</font> | '.$msg.' | <font style=color:#7D0000;font-weight: bold;>'.$cos2.' by</font> '.$supian.' <font style=color:#7D0000;font-weight: bold;> at '.DateTime().'</font>';
	    	}
	    }
	} else if($view['error'] == 3) {
		if($cos == '') {
			$view['msg'] = '<font style="color:#5C3566;font-weight:bold;">Uncheck</font> | '.$msg.' | <font style=color:#7D0000;font-weight: bold;>Checked by</font> '.$supian.' <font style=color:#7D0000;font-weight: bold;> at '.DateTime().'</font>';
		} else {
			if($cos2 == ''){
				$view['msg'] = '<font style="color:#5C3566;font-weight:bold;">'.$cos.'</font> | '.$msg.' | <font style=color:#7D0000;font-weight: bold;>Checked by</font> '.$supian.' <font style=color:#7D0000;font-weight: bold;> at '.DateTime().'</font>';
			} else {
				$view['msg'] = '<font style="color:#5C3566;font-weight:bold;">'.$cos.'</font> | '.$msg.' | <font style=color:#7D0000;font-weight: bold;>'.$cos2.' by</font> '.$supian.' <font style=color:#7D0000;font-weight: bold;> at '.DateTime().'</font>';
			}
		}
	} else if($view['error'] == 4) {
		// sock
		$view['msg'] = '<font style="color:#CC0000;font-weight:bold;">Sock Die</font> | '.$msg.' | <font style=color:#7D0000;font-weight: bold;>Checked by</font> '.$supian.' <font style=color:#7D0000;font-weight: bold;> at '.DateTime().'</font>';
	} else if($err == 5) {
		$view['error'] = 1;
		$view['msg'] = $msg;
	}
	$view['msg'] = str_replace('|', '<font style="color:#CC0000;font-weight:bold;">|</font>', $view['msg']);
	echo json_encode($view);
}

function Supian($title){
    return '<font style="color:#000000;font-weight:bold;">'.substr($title, 0, (strlen($title) - 4)).'</font><font style="color:#CC0000;font-weight:bold;">'.substr($title, (strlen($title) - 4), strlen($title)).'</font>';
}

function getStr($string,$start,$end){
	$string = str_replace("\n", '', $string);
	$string = str_replace("\t", '', $string);
	$str    = explode($start,$string,2);
    $str    = explode($end,$str[1],2);
    return $str[0];
}
function ICode(){
	$string = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $shuffle = substr(str_shuffle($string), 0, 4);
    $random  = substr(str_shuffle($string), 0, 4);
    return 'Priv-Code-'.$shuffle.'-'.$random;
}

function strShuffle($len = 5){
    $string = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    $shuffle = substr(str_shuffle($string), 0, $len);
    return $shuffle;
}

function Random($len = 5){
    $string = '01234567899876543210';
    $shuffle = substr(str_shuffle($string), 0, $len);
    return $shuffle;
}

function Xcsrf(){
	return md5(uniqid().DateTime());
}

function HeadSidebar($a = false, $b = false){
	global $db,$setting,$username,$root,$avatar,$level,$name,$email,$coin;
	if($a == true) { 
		include $root.'/inc/header.inc';
	}
	if($b == true) {
		include $root.'/inc/sidebar.inc';
	}	
}

function SideFooter($a = false, $b = false){
	global $db,$setting,$root;
	if($a == true) { 
		include $root.'/inc/slidebar.inc';
	}
	if($b == true) {
		include $root.'/inc/footer.inc';
	}	
}
//Getting Real IP Address
function Ip(){
    if (getenv('HTTP_CLIENT_IP')) {
        $ipaddress = getenv('HTTP_CLIENT_IP');
    } else if (getenv('HTTP_X_FORWARDED_FOR')) {
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    } else if (getenv('HTTP_X_FORWARDED')) {
        $ipaddress = getenv('HTTP_X_FORWARDED');
    } else if (getenv('HTTP_FORWARDED_FOR')) {
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    } else if (getenv('HTTP_FORWARDED')) {
        $ipaddress = getenv('HTTP_FORWARDED');
    } else if (getenv('REMOTE_ADDR')) {
        $ipaddress = getenv('REMOTE_ADDR');
    } else {
        $ipaddress = 'Unknown';
    }
    return $ipaddress;
}

function DateTime(){
    return Date('H:i:s d M Y', time());
}

function Message($no,$msg = ''){
	if($no == 1){
		$type = 'success';
	} else if($no == 2){
		$type = 'info';
	} else if($no == 3){
		$type = 'warning';
	} else if($no == 4){
		$type = 'danger';
	}
    $_SESSION[$type]['Message'] = !isset($_SESSION[$type]['Message']) ? $msg : $msg.'<br/>'.$_SESSION[$type]['Message'];
}

function ViewMessage(){
	if(isset($_SESSION['success']['Message'])) {
		$type = 'success';
	} else if(isset($_SESSION['info']['Message'])) {
		$type = 'info';
	} else if(isset($_SESSION['warning']['Message'])) {
		$type = 'warning';
	} else if(isset($_SESSION['danger']['Message'])) {
		$type = 'danger';
	}

    if(isset($type)){
    	$msg = trim($_SESSION[$type]['Message']);
    	unset($_SESSION[$type]['Message']);
    	echo'<div class="alert alert-block alert-'.$type.' fade in">
    		 <button data-dismiss="alert" class="close close-sm" type="button">
         	 <i class="fa fa-times"></i>
         	 </button>'.$msg.'</div>';
    }
}

function Encrypt($uname,$pass){
	$salt  = '2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824qazjg';
	$salt .= 'xswedcvfrtgbnhyujm,kiol./;p[\']\=-0987:64321`\'QAZXSWEDCVFRTGBNHYUJM,';
	$salt .= '58756879c05c68dfac9866712fad6a93f8146f337a69afe7dd238f3364946366adwlm';
	$salt  = md5($salt);
	$u     = strtolower($uname);
	$u2    = md5(sha1(md5($u.$salt)));
	$p     = md5(sha1(md5($salt.$pass)));
	$hash  = substr(md5($u2.$p), 0,15);
	return '['.$hash.'][PrivCode]';
}

function Filter($data){
	$block = array('"',"'",';');
	return Sqli(trim(str_replace($block, '', $data)));
}

function Sqli($data){
	global $setting;
	$block = array('concat', 'union', 'base64_decode', 'group_concat', 'tables', 'public_html', '../', 'column', 'cmd', 'cookie', 'from', 'where','exec','shell','wget','axel','curl','truncate','/**/' , '0x3a', 'null', 'bun','s@bun', '%', 'char', 'or%', 'insert', "'='", "'or'");
	$b    = count($block);
	$url  = strtolower($_SERVER['REQUEST_URI']);
	$url2 = strtolower($_SERVER['QUERY_STRING']);
	for ($i=0; $i< $b; $i++) { 
		if(stristr($data, $block[$i]) || stripos($data, $block[$i]) || stristr($url, $block[$i]) || stripos($url, $block[$i]) || stristr($url2, $block[$i]) || stripos($url2, $block[$i])){
			Redirect($setting->url.'/noob.html');
			exit();
		} else {
			return $data;
		}
	}
}

function Redirect($url = '/'){
	header('location:'.$url);
}