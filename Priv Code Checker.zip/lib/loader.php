<?php
session_start();
ob_start();

$databaseFile  = 'database.class.php';
$settingFile   = 'setting.class.php';
$functionFile  = 'function.inc.php';
$curlFile      = 'curl.class.php';

if(dev_mode == false){
	error_reporting(0);
}

if(dir_root == ''){
	$root = $_SERVER['DOCUMENT_ROOT'];
} else{
	$root = $_SERVER['DOCUMENT_ROOT'].'/'.dir_root;
}

if(file_exists($root.'/lib/'.$databaseFile)){
	require $root.'/lib/'.$databaseFile;
	if(file_exists($root.'/lib/'.$settingFile)){
		require $root.'/lib/'.$settingFile;
		if(file_exists($root.'/lib/'.$functionFile)){
			require $root.'/lib/'.$functionFile;
			if(file_exists($root.'/lib/'.$curlFile)){
				require $root.'/lib/'.$curlFile;
			} else {
				die($curlFile. " file does not exist");
			}
		} else {
			die($functionFile. " file does not exist");
		}
	} else {
		die($settingFile. " file does not exist");
	}
} else {
	die($databaseFile. " file does not exist");
}

// Inialize

$db      = new connections();
$setting = new settings();
$setting->timezone();