<?php
#======================================#
#     Author  : Supian M               # 
#     Contact : privcodes@gmail.com    #
#     2016 (c) www.priv-code.com       #
#======================================#

# Connection
define('db_host', 'localhost'); // Host
define('db_user', 'root'); // Username
define('db_pass', '');  // Password
define('db_name', 'privcode'); // Database
# Settings
define('dir_root' , '');
define('dir_admin', 'panel');
define('dir_theme', 'style');
define('timezone' , 'Asia/Makassar');
define('charset'  , 'UTF-8');
define('dev_mode' , true);
# End
require 'loader.php';