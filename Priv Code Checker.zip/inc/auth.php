<?php
$username = $_SESSION['username'];
//$token    = $_SESSION['token'];
if(empty($username) && empty($_SESSION['lockscreen'])){ //|| empty($token)) {
	Redirect($setting->url.'/signin.html');
} else if(!empty($username) && empty($_SESSION['lockscreen'])){
	Redirect($setting->url.'/lockscreen.html');
} else {
	$db->go("SELECT  `name`, `email`, `priv_coin`, `avatar`, `suspend`, `level` FROM `users` WHERE `username` = '$username'");
	$row = $db->fetchArray();
	if($row['suspend'] == 1) {
		Message(3, 'Akun anda disuspend.');
		Redirect($setting->url.'/logout.html');
	} /* else if($token != base64_encode(Ip())) {
		session_destroy();
		Message(2, 'Token tidak valid.');
		Redirect($setting->url.'/logout.html');
	}*/  else if($row['level'] != 'Admin' && $setting->maintenance == '1') {
    	Redirect($setting->url.'/maintenance.html');
  	}
}

//
$avatar = $row['avatar'];
$level  = $row['level'];
$name   = $row['name'];
$email  = $row['email'];
$coin   = $row['priv_coin'];