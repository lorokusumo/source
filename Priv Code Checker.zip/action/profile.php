<?php
require '../lib/config.php';
require '../inc/auth.php';

if(isset($_POST['account'])){
	$nama = Filter($_POST['name']);
	$a = $db->go("UPDATE `users` SET `name` = '$nama' WHERE `username` = '$username'");
	if($a){
		Message(1, 'Nama berhasil dirubah');
	}
}

if(isset($_POST['password'])){
	$old = $_POST['old'];
	$new = $_POST['new'];
	$ret = $_POST['retype'];
	$db->go("SELECT `password` FROM `users` WHERE `username` = '$username'");
	$row = $db->fetchArray();
	if($row['password'] != Encrypt($username, $old)){
		Message(3, 'Password lama salah');
	} else if($new != $ret){
		Message(3, 'Password harus sama');
	} else {
		$password = Encrypt($username,$new);
		$db->go("UPDATE `users` SET `password` = '$password' WHERE `username` = '$username'");
		Message(1, 'Password berhasil diganti');
	}
}
Redirect($setting->url.'/profile.html');