<?php
require '../lib/config.php';
if(isset($_POST)){
	$xcsrf = trim($_POST['xcsrf']);
	if(empty($xcsrf) || strlen($xcsrf) < 32 || strlen($xcsrf) > 32) {
		unset($_SESSION['xcsrf']);
		Redirect($setting->url.'/signin.html');
		exit();
	}
	$name   = ucwords(StrToLower(Filter($_POST['name'])));
	$uname  = StrToLower(Filter($_POST['uname']));
	$email  = StrToLower(Filter($_POST['email']));
	$passwd = Encrypt($uname, $_POST['passwd']);
	$retype = Encrypt($uname, $_POST['retype']);
	$icode  = Filter($_POST['icode']);
	//
	$uname = str_replace(' ', '', $uname);
	$block = array('privcode','hacked','pwned','stamped','tested');
	$donot = array('`', '~', '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '-', '=', '+', '{', '}', '[', ']', "\\", '|', ';', ':', '<', '>', ',', '.', '?', '/');
	foreach ($donot as $value) {
		if(strstr($uname, $value)) {
			Message(3, 'Username tidak boleh mengandung karakter spesial');
			Redirect($setting->url.'/signup.html');
			exit();
		}
	}
	if(strlen($uname) < 5 || strlen($uname) > 15) {
		Message(3, 'Username setidaknya 5 karakter dan maksimal 15 karakter');
	} else if(!strstr($email, '@')) {
		Message(3, 'Email tidak valid');
	} else if($passwd != $retype) {
		Message(3, 'Password harus sama');
	} else if(in_array($uname, $block)) {
		Message(3, 'Username tidak diizinkan');
	} else {
		$db->go("SELECT `username` FROM `users` WHERE `username` = '$uname'");
		$user = $db->numRows();
		$db->go("SELECT `code`, `status` FROM `invitecodes` WHERE `code` = '$icode'");
		$ics = $db->fetchArray();
		$icc = $db->numRows();
		if($user > 0) {
			Message(4, 'Username sudah digunakan');
		} else if($icc != 1) {
			Message(4, 'Invite Code tidak valid ');
		} else if($ics['status'] == 0) {
			Message(4, 'Invite Code sudah digunakan');
		} else {
			$date = DateTime();
			$ip   = Ip();
			$cre  = $setting->balance; 
			// Insert new user
			$i = $db->go("INSERT INTO `users`(`id`, `name`, `username`, `password`, `email`, `priv_coin`, `registered_date`, `last_logged`, `ip`) VALUES 
				   (NULL, '$name', '$uname', '$passwd', '$email', '$cre', '$date', '$date', '$ip') ");
			// update invite code
			$u = $db->go("UPDATE invitecodes SET status = '0', usedby = '$uname' WHERE code = '$icode'");
			if($i && $u){
				Message(1, 'Pendaftaran berhasil');
			} else {
				Message(4, 'Tolong hubungi admin');
			}
		}
	}
}
Redirect($setting->url.'/signup.html');