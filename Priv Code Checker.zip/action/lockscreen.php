<?php
require '../lib/config.php';
require '../inc/auth.php';

unset($_SESSION['lockscreen']);
if(empty($_SESSION['lockscreen'])){
	Redirect($setting->url.'/lockscreen.html');
} else {
	Redirect($setting->url.'/home.html');
}
