<?php
require '../lib/config.php';
require '../inc/auth.php';

$date  = DateTime();
if(isset($_POST)){
	if(isset($_POST['send'])) {
		$pesan = trim(strip_tags($_POST['pesan']));
		if($pesan == ''){
			print "gagal";		
		} else {
			if($db->go("INSERT INTO `chats`(`id`, `nickname`, `chat`, `date_`) VALUES (NULL, '$username', '$pesan', '$date')")){
				print "terkirim";
			} else {
				print "gagal";
			}		
		}
	}
}

function Abuse($str){
	$kasar = array('fuck','anjing', 'goblok', 'asu', 'bodoh', 'ngentot', 'memek', 'pepek', 'kimak', 'shit', 'asshole', 'kutang', 'peler', 'kontol', 'babi', 'cacat', 'saki', 'tolol', 'gila', 'porn', 'porno', 'bokep', 'fvck', 'anjrit', 'bitch');
	return str_replace($kasar, '<font style="color:red;">***</font>', strtolower($str));
}

if(isset($_GET)) {
	if(isset($_GET['view'])) {
		$db->go("SELECT `nickname`, `chat`, `date_`, `avatar`, `name` FROM `chats` INNER JOIN `users` ON users.username = chats.nickname ORDER BY chats.id");
		while ($row = $db->fetchArray()) {
			$pesan = $row['chat'];
			$kode = array('[ayo]','[bisik]','[cubit]','[diam]','[doa]','[elus]','[gagah]','[geram]','[hajar]','[hehe]','[huh]','[kebelet]','[kesal]','[lari]','[malu]','[mantap]','[merinding]','[mikir]','[muncrat]','[nangis]','[ngamuk]','[ngantuk]','[ngikik]','[ninja]','[nungging]','[nyelam]','[nyerah]','[preman]','[puyeng]','[rapper]','[rocker]','[tampar]','[tepuk]','[teriak]','[waspada]');
			$icon = array(
		"<img src='$setting->sticker/ayo.gif' id='img-emot-2' title=\"Ayo\" onClick=\"addemot('[ayo]')\">",
        "<img src='$setting->sticker/bisik.gif' id='img-emot-2' title=\"Bisik\" onClick=\"addemot('[bisik]')\">",
        "<img src='$setting->sticker/cubit.gif' id='img-emot-2' title=\"Cubit\" onClick=\"addemot('[cubit]')\">",
		"<img src='$setting->sticker/diam.gif' id='img-emot-2' title=\"Diam\" onClick=\"addemot('[diam]')\">",
		"<img src='$setting->sticker/doa.gif' id='img-emot-2' title=\"Doa\" onClick=\"addemot('[doa]')\">",
		"<img src='$setting->sticker/elus.gif' id='img-emot-2' title=\"Elus\" onClick=\"addemot('[elus]')\">",
		"<img src='$setting->sticker/gagah.gif' id='img-emot-2' title=\"Gagah\" onClick=\"addemot('[gagah]')\">",
		"<img src='$setting->sticker/geram.gif' id='img-emot-2' title=\"Geram\" onClick=\"addemot('[geram]')\">",
		"<img src='$setting->sticker/hajar.gif' id='img-emot-2' title=\"Hajar\" onClick=\"addemot('[hajar]')\">",
		"<img src='$setting->sticker/hehe.gif' id='img-emot-2' title=\"Hehe\" onClick=\"addemot('[hehe]')\">",
		"<img src='$setting->sticker/huh.gif' id='img-emot-2' title=\"Huh\" onClick=\"addemot('[huh]')\">",
		"<img src='$setting->sticker/kebelet.gif' id='img-emot-2' title=\"Kebelet\" onClick=\"addemot('[kebelet]')\">",
		"<img src='$setting->sticker/kesal.gif' id='img-emot-2' title=\"Kesal\" onClick=\"addemot('[kesal]')\">",
		"<img src='$setting->sticker/lari.gif' id='img-emot-2' title=\"Lari\" onClick=\"addemot('[lari]')\">",
		"<img src='$setting->sticker/malu.gif' id='img-emot-2' title=\"Malu\" onClick=\"addemot('[malu]')\">",
		"<img src='$setting->sticker/mantap.gif' id='img-emot-2' title=\"Mantap\" onClick=\"addemot('[mantap]')\">",
		"<img src='$setting->sticker/merinding.gif' id='img-emot-2' title=\"Merinding\" onClick=\"addemot('[merinding]')\">",
   		"<img src='$setting->sticker/mikir.gif' id='img-emot-2' title=\"Mikir\" onClick=\"addemot('[mikir]')\">",
   		"<img src='$setting->sticker/muncrat.gif' id='img-emot-2' title=\"Muncrat\" onClick=\"addemot('[muncrat]')\">",
   		"<img src='$setting->sticker/nangis.gif' id='img-emot-2' title=\"Nangis\" onClick=\"addemot('[nangis]')\">",
   		"<img src='$setting->sticker/ngamuk.gif' id='img-emot-2' title=\"Ngamuk\" onClick=\"addemot('[ngamuk]')\">",
   		"<img src='$setting->sticker/ngantuk.gif' id='img-emot-2' title=\"Ngantuk\" onClick=\"addemot('[ngantuk]')\">",
   		"<img src='$setting->sticker/ngikik.gif' id='img-emot-2' title=\"Ngikik\" onClick=\"addemot('[ngikik]')\">",
   		"<img src='$setting->sticker/ninja.gif' id='img-emot-2' title=\"Ninja\" onClick=\"addemot('[ninja]')\">",
   		"<img src='$setting->sticker/nungging.gif' id='img-emot-2' title=\"Nungging\" onClick=\"addemot('[nungging]')\">",
   		"<img src='$setting->sticker/nyelam.gif' id='img-emot-2' title=\"Nyelam\" onClick=\"addemot('[nyelam]')\">",
   		"<img src='$setting->sticker/nyerah.gif' id='img-emot-2' title=\"Nyerah\" onClick=\"addemot('[nyerah]')\">",
   		"<img src='$setting->sticker/preman.gif' id='img-emot-2' title=\"Preman\" onClick=\"addemot('[preman]')\">",
   		"<img src='$setting->sticker/puyeng.gif' id='img-emot-2' title=\"Puyeng\" onClick=\"addemot('[puyeng]')\">",
   		"<img src='$setting->sticker/rapper.gif' id='img-emot-2' title=\"Rapper\" onClick=\"addemot('[rapper]')\">",
   		"<img src='$setting->sticker/rocker.gif' id='img-emot-2' title=\"Rocker\" onClick=\"addemot('[rocker]')\">",
   		"<img src='$setting->sticker/tampar.gif' id='img-emot-2' title=\"Tampar\" onClick=\"addemot('[tampar]')\">",
   		"<img src='$setting->sticker/tepuk.gif' id='img-emot-2' title=\"Tepuk\" onClick=\"addemot('[tepuk]')\">",
   		"<img src='$setting->sticker/teriak.gif' id='img-emot-2' title=\"Teriak\" onClick=\"addemot('[teriak]')\">",
   		"<img src='$setting->sticker/waspada.gif' id='img-emot-2' title=\"Waspada\" onClick=\"addemot('[waspada]')\">"
				);
			$pesan = str_replace($kode, $icon, $pesan);

			$pesan = Abuse($pesan);
			$date = $row['date_'];
			$nick = $row['nickname'];
			$as = strtolower(substr($nick, 0,1));
			$red =    array('a','b','m','n','v','y','3','4');
			$blue =   array('d','f','g','h','t','w','2','5');
			$orange = array('j','k','l','p','x','0','1','6');
			if(in_array($as,$red)){
				$color = '#EF2929';
			} else if(in_array($as,$blue)){
				$color = '#2E4CDD';
			} else if(in_array($as,$orange)){
				$color = '#F57900';
			} else {
				$color = '#2E3436';
			}

			if($nick == $username){
				$lol = 'out';
			} else {
				$lol = 'in';
			}

	// this is emoticon's operation bro 
			echo '<div class="msg-time-chat">';
            echo '<a href="#" class="message-img"><img class="avatar" src="'.$setting->avatar.'/'.$row['avatar'].'" alt=""></a>';
            echo '<div class="message-body msg-'.$lol.'">';
            echo '<span class="arrow"></span>';
            echo '<div class="text">';
            echo '<p class="attribution"><a href="#">'.ucwords($row['name']).'</a> at '.$date.'</p>';
            echo '<p>'.ucwords($pesan).'</p>';
            echo '</div>';
            echo '</div>';
            echo '</div>';

		}
	}
}
?>

