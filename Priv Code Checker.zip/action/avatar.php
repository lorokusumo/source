<?php

require'../lib/config.php';
include'../inc/auth.php';
$path = $root.'/misc/avatar/';

$valid_formats = array('jpg', 'jpeg', 'png', 'bmp', 'gif', 'ico');

if (isset($_POST) and $_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_FILES['photoimg']['name'];
    $size = $_FILES['photoimg']['size'];

    if (strlen($name)) {
        $ext = getExtension($name);

        if (in_array(strtolower($ext), $valid_formats)) {
            if ($size <= (500 * 1000)) {
                $image_name = $username.'.'.$ext;
                $tmp = $_FILES['photoimg']['tmp_name'];

                $pixel = getimagesize($tmp);
                $width = $pixel[0];
                $height = $pixel[1];
                unlink($path.$avatar);
                if ($width > 1024 || $height > 1024) {
                    Message(2, 'Maksimal ukuran photo 1024 x 1024 pixel');
                } else if (move_uploaded_file($tmp, $path.$image_name)) {
                 	$db->go("UPDATE `users` SET `avatar` = '$image_name'");
                 	Message(1, 'Sukses');
                }
            } else {
            	Message(3, 'Maksimal besar photo 500 kb');
            }
        } else {
        	Message(4, 'File selain photo tidak diperbolehkan');
        }
    }
}
Redirect($setting->url.'/profile.html');