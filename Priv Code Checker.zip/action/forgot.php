<?php
require '../lib/config.php';

if(isset($_POST)){
	// Create recovery code
	if(isset($_POST['forgot']))
		$email = Filter($_POST['email']);
		$db->go("SELECT `email`,`username` FROM `users` WHERE `email` = '$email'");
		$row = $db->fetchArray();
		if($db->numRows() == 0){
			Message(4, $email.' tidak terdaftar.');
		} else {
			$code = strShuffle(25);
			$query = $db->go("UPDATE `users` SET `recoverycode` = '$code' WHERE `email` = '$email'");
			if($query){

				$content = 'Silahkan klik link ini <a href="'.$setting->url.'/'.$code.'.html" target="_blank">'.$setting->url.'/'.$code.'.html</a>';
				$email = mail($email, $setting->title, $content);

				if($email && $query){
					Message(1, 'Berhasil, silahkan cek Recovery Code di Inbox/Spam email anda');
				} else {
					Message(3, 'Gagal');
				}
			}
		}
	}

Redirect($setting->url.'/signin.html');