<?php
require '../lib/config.php';

if(isset($_POST['reset'])){
		$xcsrf = Filter($_POST['xcsrf']);
		if($_SESSION['xcsrf'] != $xcsrf || empty($_SESSION['xcsrf'])) {
			unset($_SESSION['xcsrf']);
			session_destroy();
			session_start();
			Message(3, 'Alasan keamanan');
		} else {
			$code = Filter($_POST['code']);
			$pass = $_POST['passwd'];
			$rety = $_POST['retype'];
			//
			$db->go("SELECT `recoverycode`, `username` FROM `users` WHERE `recoverycode` = '$code'");
			$row = $db->fetchArray();
			if($db->numRows() == 0){
				Message(4, 'Code tidak valid');
			} else if($pass != $rety){
				Message(3, 'Password harus sama');
			} else {
				$newpass = Encrypt($row['username'],$pass);
				$query = $db->go("UPDATE `users` SET `password` = '$newpass', `recoverycode` = '' WHERE `recoverycode` = '$code'");
				if($query){
					Message(1, 'Password berhasil diganti');
				} else {
					Message(4, 'Gagal, tolong hubungi admin');
				}
			}
	}
}
Redirect($setting->url.'/signin.html');