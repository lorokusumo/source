<?php
require '../lib/config.php';
include '../inc/auth.php';
if(isset($_GET['coin'])){
	$db->go("SELECT `priv_coin` FROM `users` WHERE `username` = '$username'");
	$a = $db->fetchArray();
	echo $a['priv_coin'].' ¢';
}