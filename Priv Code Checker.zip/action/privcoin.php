<?php
require '../lib/config.php';
require '../inc/auth.php';
if(isset($_POST)){
	$xcsrf = Filter($_POST['xcsrf']);
	if($_SESSION['xcsrf'] != $xcsrf || empty($_SESSION['xcsrf'])) {
		unset($_SESSION['xcsrf']);
		session_destroy();
		session_start();
		Message(3, 'Alasan keamanan');
		Redirect($setting->url.'/signin.html');
		exit();
	} else {
		$coin = Filter($_POST['balance']);
		$cost = Filter($_POST['cost']);
		list($rate, $payment) = explode('|', (Filter($_POST['payment'])));
		// Filter Inspect Element
		$db->go("SELECT `rate` FROM `payments` WHERE `payment` = '$payment'");
		$lulz = $db->fetchArray();
		$db->go("SELECT `price` FROM `pricing` WHERE `item` = 'Priv Coin'");
		$mom = $db->fetchArray();

		$satu = $coin * $mom['price'];
		$dua = ($satu * $lulz['rate']) + $satu;
		if($dua != $cost){
			Redirect($setting->url.'/logout.html');
			exit();
		}
			// End
		$invoice = Random(5);
		$date = DateTime();
		$a = $db->go("INSERT INTO orders (`id`, `username`, `item`, `count`, `cost`, `payment`, `invoice`, `pending`, `date_`) VALUES (NULL, '$username', 'Priv Coin', '$coin', '$cost', '$payment', '$invoice', '1', '$date')");
		if($a){
			Message(1, 'No. Invoice anda #'.$invoice.' silahkan cek dimenu History > Invoice');
		} else {
			Message(4, 'Tolong hubungi admin.');
		}
	}
}
Redirect($setting->url.'/topup.html');