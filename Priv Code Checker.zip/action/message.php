<?php
require '../lib/config.php';
require '../inc/auth.php';
if(isset($_POST)){
	$xcsrf = Filter($_POST['xcsrf']);
	if($_SESSION['xcsrf'] != $xcsrf || empty($_SESSION['xcsrf']) || empty($xcsrf)) {
		unset($_SESSION['xcsrf']);
		session_destroy();
		session_start();
		Message(3, 'Alasan keamanan');
		Redirect($setting->url.'/message.html');
		exit();
	} else {
		$pesan = Filter($_POST['content']);
		$title = Filter($_POST['title']);
		$date  = DateTime();

		if($db->go("INSERT INTO `messages`(`id`, `from_`, `to_`, `subject`, `message`, `status`, `read_`, `date_`) VALUES (NULL,'$username','supian','$title','$pesan','1','0','$date')")){
			Message(1, 'Pesan anda berhasil dikirim.');
		} else {
			Message(2, 'Pesan anda gagal dikirim.');
		}
	}
}
Redirect($setting->url.'/message.html');