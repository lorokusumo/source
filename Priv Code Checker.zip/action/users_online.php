<?php
require '../lib/config.php';
require '../inc/auth.php';
if(isset($_GET['sidebar'])){
    $db->go("SELECT `name`, `avatar` FROM `users` WHERE `online` = '1'");
    while ($ol = $db->fetchArray()) {  ?>
	<ul class="quick-chat-list">
        <li class="online">
            <div class="media">
                <a href="#" class="pull-left media-thumb">
                    <img alt="<?php echo ucwords($ol['name']);?>" src="<?php echo $setting->avatar.'/'.$ol['avatar'];?>" class="media-object">
                </a>
                <div class="media-body">
                    <strong><?php echo ucwords($ol['name']);?></strong>
             	    <small>Priv Code :)</small>
      	        </div>
            </div>
        </li>
    </ul>
<?php
    }
} else if(isset($_GET['chat'])){
    $db->go("SELECT `name`, `avatar` FROM `users` WHERE `online` = '1'");
    $no = 1;
    while ($ol = $db->fetchArray()) {
            if($no % 2){
                $lol = 'out';
            } else {
                $lol = 'in';
            }
            echo'<div class="msg-time-chat">';
            echo '<a href="#" class="message-img"><img class="avatar" src="'.$setting->avatar.'/'.$ol['avatar'].'" alt=""></a>';
            echo '<div class="message-body msg-'.$lol.'">';
            echo '<span class="arrow"></span>';
            echo '<div class="text">';
            echo '<p class="attribution"><a href="#">'.ucwords($ol['name']).'</a></p>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
    $no++;} 
}

