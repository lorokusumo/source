<?php
require '../lib/config.php';
require '../inc/auth.php';
if(isset($_POST)){
	$xcsrf = Filter($_POST['xcsrf']);
	if($_SESSION['xcsrf'] != $xcsrf || empty($_SESSION['xcsrf']) || empty($xcsrf)) {
		unset($_SESSION['xcsrf']);
		session_destroy();
		session_start();
		Message(3, 'Alasan keamanan');
		Redirect($setting->url.'/signin.html');
		exit();
	} else {
		$jum = Filter($_POST['balance']);
		$cost = Filter($_POST['cost']);
 		list($rate, $payment) = explode('|', (Filter($_POST['payment'])));
		if($payment == 'PrivCoin'){
			$db->go("SELECT `priv_coin` FROM `users` WHERE `username` = '$username'");
			$pcon = $db->fetchArray();
			if(($jum * 300) != $cost){
				Redirect($setting->url.'/logout.html');
				exit();
			}
			if($pcon['priv_coin'] < $cost){
				Message(3, 'Priv Coin anda tidak cukup.');
				Redirect($setting->url.'/icode.html');
				exit();
			}
	  		$costAkhir = $cost/$jum;
	  		for ($i=0; $i < $jum ; $i++) { 
	  			$icode = ICode();
	  			$invoice = Random(5);
	  			$date = DateTime();
				$b = $db->go("INSERT INTO `invitecodes`(`id`,`code`,`createdby`,`usedby`,`type`,`status`,`date_`) VALUES (NULL,'$icode','$username','None','Reguler','1','$date')");
				$c = $db->go("UPDATE `users` SET `priv_coin` = `priv_coin` - '$costAkhir' WHERE `username` = '$username'");
				if($b && $c){
					Message(1, 'Pembelian Invite Code berhasil, Invite Code anda adalah '.$icode.' atau cek dimenu History > Invite Code');
	  			} else {
					Message(4, 'Tolong hubungi admin.');
	  			}
	  		}
			$d = $db->go("INSERT INTO orders (`id`,`username`,`item`,`count`,`cost`,`payment`,`invoice`,`pending`,`date_`) VALUES (NULL, '$username','Invite Code','$jum','$cost','Priv Coin','$invoice','0','$date')");
		} else {
			// Filter Inspect Element
			$db->go("SELECT `rate` FROM `payments` WHERE `payment` = '$payment'");
			$lulz = $db->fetchArray();
			$db->go("SELECT `price` FROM `pricing` WHERE `item` = 'Invite Code'");
			$mom = $db->fetchArray();

			$satu = $jum * $mom['price'];
			$dua = ($satu * $lulz['rate']) + $satu;
			if($dua != $cost){
				Redirect($setting->url.'/logout.html');
				exit();
			}
			// End
			$icode = ICode();
			$invoice = Random(5);
			$date = DateTime();
			$a = $db->go("INSERT INTO orders (`id`,`username`,`item`,`count`,`cost`,`payment`,`invoice`,`pending`,`date_`) VALUES (NULL, '$username','Invite Code','$jum','$cost','$payment','$invoice','1','$date')");
			if($a){
				Message(1, 'No. Invoice anda #'.$invoice.' silahkan cek dimenu History > Invoice');
			} else {
				Message(4, 'Tolong hubungi admin.');
			}
		}
	}
}
Redirect($setting->url.'/icode.html');