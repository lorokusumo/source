<?php
require '../lib/config.php';
require '../inc/auth.php';
$db->go("UPDATE users SET `online` = '0' WHERE `username` = '$username'");
session_destroy();
Redirect($setting->url.'/signin.html');