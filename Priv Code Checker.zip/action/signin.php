<?php
require '../lib/config.php';
if(isset($_POST)){
	if($setting->security == 1) {
		$captcha = isset($_POST['g-recaptcha-response']) ? $_POST['g-recaptcha-response']:'';
    	$secret_key = $setting->private_key; // Secret keyprivate_key
    	$url = 'https://www.google.com/recaptcha/api/siteverify?secret=' . urlencode($secret_key) . '&response=' . $captcha;   
    	$recaptcha = file_get_contents($url);
    	$recaptcha = json_decode($recaptcha, true);
    	if(!$recaptcha['success']) {
    		Message(3, 'Captcha salah.');
        	Redirect($setting->url.'/signin.html');
        	exit();
    	}
	} 
	$uname  = StrToLower(Filter($_POST['uname']));
	$_SESSION['xcsrf'] = trim($_POST['xcsrf']);

	if(empty($_SESSION['xcsrf']) || strlen($_SESSION['xcsrf']) < 32 || strlen($_SESSION['xcsrf']) > 32) {
		unset($_SESSION['xcsrf']);
		Redirect($setting->url.'/signin.html');
		exit();
	}
	if(!filter_var($uname, FILTER_VALIDATE_EMAIL)){
		$db->go("SELECT `username`, `password`, `suspend` FROM `users` WHERE `username` = '$uname'");
		$passwd = Encrypt($uname, $_POST['passwd']);
		$row = $db->fetchArray();
	} else if(filter_var($uname, FILTER_VALIDATE_EMAIL)){
		$db->go("SELECT `username`, `email`, `password`, `suspend` FROM `users` WHERE `email` = '$uname'");
		$row = $db->fetchArray();
		$passwd = Encrypt($row['username'], $_POST['passwd']);
	}

	if($db->numRows() == 0) {
		Message(2, 'Akun belum terdaftar');
	} else if($row['password'] != $passwd) {
		Message(3, 'Password salah');
	} else if($row['suspend'] == 1) {
		Message(4, 'Akun disuspend, silahkan hubungi admin');
	} else {
		$username = $row['username'];
		$date = DateTime();
		$ip = Ip();
		$a = $db->go("UPDATE `users` SET `last_logged` = '$date', `ip` = '$ip', `online` = '1' WHERE `username` = '$username'");
		$b = $_SESSION['username'] = $username;
		$_SESSION['lockscreen'] = true;
		//$c = $_SESSION['token'] = base64_encode($ip);
		if($a && $b){
			Redirect($setting->url.'/home.html');
			exit();
		} else {
			Message(4, 'Tolong hubungi admin');
		}
	}
}
Redirect($setting->url.'/signin.html');